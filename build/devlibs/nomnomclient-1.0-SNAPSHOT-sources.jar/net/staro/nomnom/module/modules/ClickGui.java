package net.staro.nomnom.module.modules;

import net.staro.nomnom.Nomnom;
import net.staro.nomnom.module.Category;
import net.staro.nomnom.module.NomnomModule;

// TODO: this.
public class ClickGui extends NomnomModule {
    public ClickGui(Nomnom nomnom) {
        super(nomnom, "ClickGui", Category.CLIENT, "A GUI for modules");
    }

}
