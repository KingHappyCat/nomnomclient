package net.staro.nomnom;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.minecraft.client.MinecraftClient;
import net.staro.nomnom.api.injection.Client;
import net.staro.nomnom.command.Chat;
import net.staro.nomnom.events.client.InitEvent;
import net.staro.nomnom.manager.managers.*;

@Slf4j
@NoArgsConstructor(access = AccessLevel.PUBLIC)
public class NomnomClient implements Client {
	@Override
	public void onInitializeClient(MinecraftClient mc) {
		log.info("NOMNOM_LAUNCH_START");

		// _______________ Create a nomnom instance  _______________ //
		var configManager = new ConfigManager();
		var moduleManager = new ModuleManager();
		var nomnom = new Nomnom(
				mc,
				Nomnom.EVENT_BUS,
				new Chat(mc),
				moduleManager,
				new CommandManager(),
				new FriendManager(),
				new ServiceManager(),
				new JsonableManager(),
				configManager
		);

		// _____________ Initialize managers stuff  _____________ //
		Nomnom.MANAGERS.forEach(manager -> manager.initialize(nomnom));

		// _________________ Load up configs  __________________ //
		configManager.loadEverything(nomnom);

		Nomnom.EVENT_BUS.post(new InitEvent(nomnom));

		log.info("NOMNOM_LAUNCH_FINISH");
	}

}