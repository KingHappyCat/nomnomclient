package net.staro.nomnom.mixin.network;

import net.minecraft.class_2535;
import net.minecraft.class_2547;
import net.minecraft.class_2596;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.events.PacketEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2535.class)
public class MixinClientConnection {
    @Inject(method = "handlePacket", at = @At("HEAD"), cancellable = true)
    private static <T extends class_2547> void onHandlePacket(class_2596<T> packet, class_2547 listener, CallbackInfo info) {
        var event = PacketEvent.Receive.INSTANCE;
        event.setPacket(packet);
        Nomnom.EVENT_BUS.post(event);
        if (event.isCancelled()) {
            info.cancel();
        }
    }

    @Inject(method = "send(Lnet/minecraft/network/packet/Packet;)V", at = @At("HEAD"),cancellable = true)
    private void onSendPacketPre(class_2596<?> packet, CallbackInfo info) {
        var event = PacketEvent.Send.INSTANCE;
        event.setPacket(packet);
        Nomnom.EVENT_BUS.post(event);
        if (event.isCancelled()) {
            info.cancel();
        }
    }


}
