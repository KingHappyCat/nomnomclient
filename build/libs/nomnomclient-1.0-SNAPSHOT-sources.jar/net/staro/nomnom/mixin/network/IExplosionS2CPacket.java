package net.staro.nomnom.mixin.network;

import net.minecraft.class_2664;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_2664.class})
public interface IExplosionS2CPacket {
    @Mutable
    @Accessor("playerVelocityX")
    void setMotionX(float velocityX);

    @Mutable
    @Accessor("playerVelocityY")
    void setMotionY(float velocityY);

    @Mutable
    @Accessor("playerVelocityZ")
    void setMotionZ(float velocityZ);
}
