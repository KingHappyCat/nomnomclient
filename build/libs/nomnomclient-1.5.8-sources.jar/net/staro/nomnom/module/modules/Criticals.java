package net.staro.nomnom.module.modules;

import net.minecraft.class_1268;
import net.minecraft.class_243;
import net.minecraft.class_2824;
import net.minecraft.class_2828;
import net.minecraft.class_746;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.api.Setting;
import net.staro.nomnom.api.event.listener.Listener;
import net.staro.nomnom.events.PacketEvent;
import net.staro.nomnom.module.Category;
import net.staro.nomnom.module.NomnomModule;

/**
 * Makes every melee hit a critical hit without jumping, by telling the server you were
 * briefly in the air right before the attack.
 *
 * <p>Two small hops are sent as position packets just before the attack packet leaves.
 * Your real position never changes: the last packet puts you back where you were.
 * Servers with a movement anticheat may flag the fake hop, so {@code Strict} uses smaller
 * steps that look more like a real fall.
 */
@SuppressWarnings("unused")
public class Criticals extends NomnomModule {
    public enum Mode {
        /** Two hops: 0.0625 up, then back down. Fast and works on vanilla servers. */
        PACKET(new double[]{0.0625, 0.0}),
        /** Three smaller hops that stay under what most anticheats consider a jump. */
        STRICT(new double[]{0.11, 0.1100013579, 0.0000013579});

        private final double[] offsets;

        Mode(double[] offsets) {
            this.offsets = offsets;
        }
    }

    private final Setting<Mode> mode = enumSetting("Mode", Mode.PACKET);
    // Only fake it when the target would not already be a crit, so a real jump hit is untouched.
    private final Setting<Boolean> onlyOnGround = bool("OnlyOnGround", true);

    public Criticals(Nomnom nomnom) {
        super(nomnom, "Criticals", Category.COMBAT, "Every hit is a critical hit");
    }

    @Listener
    public void onPacketSend(PacketEvent.Send event) {
        if (!(event.getPacket() instanceof class_2824 packet)) {
            return;
        }

        class_746 player = mc.field_1724;
        if (player == null || mc.method_1562() == null || !isAttack(packet)) {
            return;
        }

        // A hit that is already a crit (falling) or that cannot be one (water, ladder, riding,
        // gliding, blindness) gains nothing from the fake hop.
        if (player.method_5799() || player.method_5771() || player.method_6101()
                || player.method_5765() || player.method_6128()
                || player.method_6059(net.minecraft.class_1294.field_5919)) {
            return;
        }
        if (onlyOnGround.getValue() && !player.method_24828()) {
            return;
        }

        class_243 pos = player.method_73189();
        boolean collision = player.field_5976;

        for (double offset : mode.getValue().offsets) {
            mc.method_1562().method_52787(new class_2828.class_2829(
                    pos.field_1352, pos.field_1351 + offset, pos.field_1350, false, collision));
        }
    }

    /** True when the packet is an attack, not a right click on an entity. */
    private static boolean isAttack(class_2824 packet) {
        boolean[] attack = {false};

        packet.method_34209(new class_2824.class_5908() {
            @Override
            public void method_34219(class_1268 hand) {
            }

            @Override
            public void method_34220(class_1268 hand, class_243 pos) {
            }

            @Override
            public void method_34218() {
                attack[0] = true;
            }
        });

        return attack[0];
    }
}