package net.staro.nomnom.module.modules;

import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_304;
import net.minecraft.class_4174;
import net.minecraft.class_9334;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.api.Setting;
import net.staro.nomnom.api.event.listener.Listener;
import net.staro.nomnom.events.tick.TickEvent;
import net.staro.nomnom.module.Category;
import net.staro.nomnom.module.NomnomModule;

import java.util.Set;

@SuppressWarnings("unused")
public class AutoEat extends NomnomModule {
    private static final Set<class_1792> AVOID = Set.of(
            class_1802.field_8511,
            class_1802.field_8680,
            class_1802.field_8323,
            class_1802.field_8635,
            class_1802.field_8233,
            class_1802.field_8766
    );
    private static final Set<class_1792> GAPPLES = Set.of(
            class_1802.field_8463,
            class_1802.field_8367
    );
    // Eating takes 32 ticks. Give up if nothing starts within a second or so.
    private static final int START_TIMEOUT = 24;

    // Eat when the hunger bar is at this many points or lower (20 = full).
    private final Setting<Integer> hunger = integer("Hunger", 14, 1, 19);
    private final Setting<Boolean> gapples = bool("Gapples", false);
    private final Setting<Boolean> switchBack = bool("SwitchBack", true);

    private boolean eating;
    private boolean holdingKey;
    private int previousSlot = -1;
    private int ticksWaiting;

    public AutoEat(Nomnom nomnom) {
        super(nomnom, "AutoEat", Category.MISC, "Eats food when you are hungry");
    }

    @Override
    protected void onEnable() {
        reset();
    }

    @Override
    protected void onDisable() {
        stop();
    }

    @Listener
    public void onTick(TickEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) {
            reset();
            return;
        }

        if (mc.field_1755 != null) {
            if (eating) {
                stop();
            }
            return;
        }

        if (eating) {
            continueEating();
            return;
        }

        if (mc.field_1724.method_6115()
                || mc.field_1724.method_7344().method_7586() > hunger.getValue()) {
            return;
        }

        start();
    }

    private void start() {
        int slot = bestHotbarSlot();
        boolean offhand = false;

        if (slot == -1 && mc.field_1724.method_6047().method_7960()
                && isEdible(mc.field_1724.method_6079())) {
            offhand = true;
        } else if (slot == -1) {
            return;
        }

        previousSlot = mc.field_1724.method_31548().method_67532();
        if (!offhand) {
            mc.field_1724.method_31548().method_61496(slot);
        }

        eating = true;
        ticksWaiting = 0;
        press();
    }

    private void continueEating() {
        boolean hungry = mc.field_1724.method_7344().method_7586() < 20;

        if (mc.field_1724.method_6115()) {
            ticksWaiting = 0;
            press();
            return;
        }

        // Not eating (yet, or any more). Right after a bite finished we may want another one.
        if (!hungry || mc.field_1724.method_7344().method_7586() > hunger.getValue()
                || ++ticksWaiting > START_TIMEOUT) {
            stop();
            return;
        }

        press();
    }

    private void press() {
        mc.field_1690.field_1904.method_23481(true);
        holdingKey = true;
    }

    private void stop() {
        if (holdingKey) {
            holdingKey = false;
            class_304.method_1424();
        }

        if (eating && switchBack.getValue() && previousSlot != -1 && mc.field_1724 != null) {
            mc.field_1724.method_31548().method_61496(previousSlot);
        }

        reset();
    }

    private void reset() {
        eating = false;
        previousSlot = -1;
        ticksWaiting = 0;
        if (mc.field_1724 == null) {
            holdingKey = false;
        }
    }

    /** The hotbar slot holding the best food, or -1. */
    private int bestHotbarSlot() {
        int best = -1;
        float bestSaturation = -1.0f;
        int bestNutrition = -1;

        for (int slot = 0; slot < 9; slot++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(slot);
            if (!isEdible(stack)) {
                continue;
            }

            class_4174 food = stack.method_58694(class_9334.field_50075);
            if (food.comp_2492() > bestSaturation
                    || (food.comp_2492() == bestSaturation && food.comp_2491() > bestNutrition)) {
                best = slot;
                bestSaturation = food.comp_2492();
                bestNutrition = food.comp_2491();
            }
        }

        return best;
    }

    private boolean isEdible(class_1799 stack) {
        if (stack.method_7960() || !stack.method_57826(class_9334.field_50075)) {
            return false;
        }
        if (AVOID.contains(stack.method_7909())) {
            return false;
        }

        return gapples.getValue() || !GAPPLES.contains(stack.method_7909());
    }
}