package net.staro.nomnom.module.modules;

import com.mojang.authlib.GameProfile;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_638;
import net.minecraft.class_745;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.api.Setting;
import net.staro.nomnom.api.event.listener.Listener;
import net.staro.nomnom.events.tick.TickEvent;
import net.staro.nomnom.module.Category;
import net.staro.nomnom.module.NomnomModule;

import java.util.UUID;

@SuppressWarnings("unused")
public class FakePlayer extends NomnomModule {
    private static final class_1304[] COPIED = {
            class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166,
            class_1304.field_6173, class_1304.field_6171
    };
    // Negative, so it can never clash with an id the server hands out.
    private static final int ENTITY_ID = -133742;

    private final Setting<String> name = string("Name", "Nomnom");
    private final Setting<Float> health = floating("Health", 20f, 1f, 20f);
    private final Setting<Boolean> copyGear = bool("CopyGear", true);

    private class_745 dummy;
    private class_638 dummyWorld;

    public FakePlayer(Nomnom nomnom) {
        super(nomnom, "FakePlayer", Category.MISC, "A dummy player to test on");
    }

    @Override
    protected void onEnable() {
        spawn();
    }

    @Override
    protected void onDisable() {
        despawn();
    }

    @Listener
    public void onTick(TickEvent event) {
        if (dummy == null) {
            return;
        }

        // The world changed under us (disconnect, dimension change): the dummy went with it.
        if (mc.field_1687 == null || mc.field_1687 != dummyWorld) {
            dummy = null;
            dummyWorld = null;
            disable();
            return;
        }

        // Keep it topped up so it behaves like a target that never runs out of health.
        if (dummy.method_6032() < health.getValue()) {
            dummy.method_6033(health.getValue());
        }
    }

    private void spawn() {
        despawn();

        if (mc.field_1724 == null || mc.field_1687 == null) {
            disable();
            return;
        }

        String label = name.getValue().isBlank() ? "Nomnom" : name.getValue();
        GameProfile profile = new GameProfile(UUID.randomUUID(), label);

        class_745 entity = new class_745(mc.field_1687, profile);
        entity.method_5719(mc.field_1724);
        entity.method_5847(mc.field_1724.method_5791());
        entity.method_6033(health.getValue());
        entity.method_5838(ENTITY_ID);

        if (copyGear.getValue()) {
            for (class_1304 slot : COPIED) {
                entity.method_5673(slot, mc.field_1724.method_6118(slot).method_7972());
            }
        }

        mc.field_1687.method_53875(entity);
        dummy = entity;
        dummyWorld = mc.field_1687;
    }

    private void despawn() {
        if (dummy != null && mc.field_1687 != null && mc.field_1687 == dummyWorld) {
            mc.field_1687.method_2945(dummy.method_5628(), class_1297.class_5529.field_26999);
        }

        dummy = null;
        dummyWorld = null;
    }
}