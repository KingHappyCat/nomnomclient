package net.staro.nomnom.module.modules;

import net.minecraft.class_304;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.api.Setting;
import net.staro.nomnom.api.event.listener.Listener;
import net.staro.nomnom.events.tick.TickEvent;
import net.staro.nomnom.module.Category;
import net.staro.nomnom.module.NomnomModule;

@SuppressWarnings("unused")
public class AutoWalk extends NomnomModule {
    private final Setting<Boolean> sprint = bool("Sprint", true);

    private boolean holding;

    public AutoWalk(Nomnom nomnom) {
        super(nomnom, "AutoWalk", Category.MOVEMENT, "Walks forward by itself");
    }

    @Override
    protected void onDisable() {
        release();
    }

    @Listener
    public void onTick(TickEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null) {
            holding = false;
            return;
        }

        if (mc.field_1755 != null) {
            release();
            return;
        }

        mc.field_1690.field_1894.method_23481(true);
        if (sprint.getValue()) {
            mc.field_1690.field_1867.method_23481(true);
        }
        holding = true;
    }

    /** Gives the keys back to the keyboard: pressed if you are really holding them, else not. */
    private void release() {
        if (!holding) {
            return;
        }

        holding = false;
        class_304.method_1424();
    }
}