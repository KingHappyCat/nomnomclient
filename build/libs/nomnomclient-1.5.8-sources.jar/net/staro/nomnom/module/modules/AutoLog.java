package net.staro.nomnom.module.modules;

import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.api.Module;
import net.staro.nomnom.api.Setting;
import net.staro.nomnom.api.event.listener.Listener;
import net.staro.nomnom.events.tick.TickEvent;
import net.staro.nomnom.module.Category;
import net.staro.nomnom.module.NomnomModule;

@SuppressWarnings("unused")
public class AutoLog extends NomnomModule {
    private final Setting<Float> health = floating("Health", 6f, 1f, 20f);
    // Leave once you hold this many totems or fewer. 0 turns this check off.
    private final Setting<Integer> minTotems = integer("MinTotems", 0, 0, 36);
    // A totem in your offhand will save you from a lethal hit, so low health alone is not an emergency.
    private final Setting<Boolean> totemSafe = bool("TotemSafe", false);
    private final Setting<Boolean> players = bool("Players", false);
    private final Setting<Double> range = precise("Range", 16.0, 2.0, 64.0);
    private final Setting<Boolean> disableReconnect = bool("DisableReconnect", true);
    private final Setting<Boolean> disableSelf = bool("DisableSelf", true);

    public AutoLog(Nomnom nomnom) {
        super(nomnom, "AutoLog", Category.COMBAT, "Disconnects when you are in danger");
    }

    @Listener
    public void onTick(TickEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.method_1542()
                || mc.method_1562() == null) {
            return;
        }

        String reason = danger();
        if (reason == null) {
            return;
        }

        if (disableReconnect.getValue()) {
            Module reconnect = nomnom.moduleManager().getModuleByName("AutoReconnect");
            if (reconnect != null && reconnect.isEnabled()) {
                reconnect.disable();
            }
        }

        if (disableSelf.getValue()) {
            disable();
        }

        mc.field_1687.method_8525(class_2561.method_43470("[AutoLog] " + reason));
    }

    /** Why we should leave right now, or null if all is well. */
    private String danger() {
        float current = mc.field_1724.method_6032() + mc.field_1724.method_6067();

        if (current <= health.getValue()
                && !(totemSafe.getValue() && mc.field_1724.method_6079().method_31574(class_1802.field_8288))) {
            return String.format("Health was %.1f", current);
        }

        int limit = minTotems.getValue();
        if (limit > 0) {
            int totems = countTotems();
            if (totems <= limit) {
                return "Down to " + totems + " totem" + (totems == 1 ? "" : "s");
            }
        }

        if (players.getValue()) {
            for (class_1657 other : mc.field_1687.method_18456()) {
                if (other == mc.field_1724 || other.method_7325() || !other.method_5805()
                        || nomnom.friendManager().isFriend(other)) {
                    continue;
                }

                if (mc.field_1724.method_5739(other) <= range.getValue()) {
                    return other.method_5477().getString() + " came within " + range.getValue().intValue() + " blocks";
                }
            }
        }

        return null;
    }

    private int countTotems() {
        int total = 0;

        for (int slot = 0; slot < 36; slot++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(slot);
            if (stack.method_31574(class_1802.field_8288)) {
                total += stack.method_7947();
            }
        }

        class_1799 offhand = mc.field_1724.method_6079();
        if (offhand.method_31574(class_1802.field_8288)) {
            total += offhand.method_7947();
        }

        return total;
    }
}