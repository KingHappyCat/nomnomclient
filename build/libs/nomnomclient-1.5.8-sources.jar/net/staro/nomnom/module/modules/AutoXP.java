package net.staro.nomnom.module.modules;

import net.minecraft.class_1268;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_7924;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.api.Setting;
import net.staro.nomnom.api.event.listener.Listener;
import net.staro.nomnom.events.tick.TickEvent;
import net.staro.nomnom.module.Category;
import net.staro.nomnom.module.NomnomModule;

@SuppressWarnings("unused")
public class AutoXP extends NomnomModule {
    private static final class_1304[] ARMOR = {
            class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166
    };

    // Keep throwing while any Mending armor is below this much durability (percent).
    private final Setting<Integer> repair = integer("Repair", 100, 1, 100);
    private final Setting<Integer> delay = integer("Delay", 2, 0, 20);
    private final Setting<Boolean> onlyOnGround = bool("OnlyOnGround", true);

    private int timer;

    public AutoXP(Nomnom nomnom) {
        super(nomnom, "AutoXP", Category.COMBAT, "Mends armor with experience bottles");
    }

    @Override
    protected void onEnable() {
        timer = 0;
    }

    @Listener
    public void onTick(TickEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) {
            return;
        }

        if (timer > 0) {
            timer--;
            return;
        }

        if (mc.field_1755 != null || mc.field_1724.method_6115()
                || (onlyOnGround.getValue() && !mc.field_1724.method_24828())) {
            return;
        }

        int slot = findBottleSlot();
        if (slot == -1 || !needsMending()) {
            return;
        }

        throwBottle(slot);
        timer = delay.getValue();
    }

    private void throwBottle(int slot) {
        var inventory = mc.field_1724.method_31548();
        int previousSlot = inventory.method_67532();
        float previousPitch = mc.field_1724.method_36455();

        // The throw packet carries our view, so look straight down for just this call.
        inventory.method_61496(slot);
        mc.field_1724.method_36457(90.0f);

        try {
            mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
            mc.field_1724.method_6104(class_1268.field_5808);
        } finally {
            mc.field_1724.method_36457(previousPitch);
            inventory.method_61496(previousSlot);
        }
    }

    private int findBottleSlot() {
        for (int slot = 0; slot < 9; slot++) {
            if (mc.field_1724.method_31548().method_5438(slot).method_31574(class_1802.field_8287)) {
                return slot;
            }
        }

        return -1;
    }

    /** True when a worn armor piece has Mending and is below the Repair durability. */
    private boolean needsMending() {
        try {
            var registry = mc.field_1687.method_30349().method_30530(class_7924.field_41265);
            var mending = registry.method_46747(class_1893.field_9101);

            for (class_1304 slot : ARMOR) {
                class_1799 stack = mc.field_1724.method_6118(slot);

                if (stack.method_7960() || !stack.method_7986()
                        || class_1890.method_8225(mending, stack) <= 0) {
                    continue;
                }

                double durability = 100.0 * (stack.method_7936() - stack.method_7919()) / stack.method_7936();
                if (durability < repair.getValue()) {
                    return true;
                }
            }
        } catch (RuntimeException ignored) {
            // No enchantment registry yet (loading the world): nothing to mend.
        }

        return false;
    }
}