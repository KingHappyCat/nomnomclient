package net.staro.nomnom.mixin.entity;

import net.minecraft.class_1309;
import net.minecraft.class_746;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.module.modules.Step;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1309.class)
public class MixinLivingEntity {
    @SuppressWarnings("ConstantValue")
    @Inject(method = "getStepHeight", at = @At("RETURN"), cancellable = true)
    private void getStepHeightHook(CallbackInfoReturnable<Float> cir) {
        if (class_746.class.isInstance(this)) {
            var event = new Step.StepHeightEvent(class_746.class.cast(this), cir.getReturnValueF());
            Nomnom.EVENT_BUS.post(event);
            if (event.isCancelled()) {
                cir.setReturnValue(event.getHeight());
            }
        }
    }

}
