package net.staro.nomnom.module.modules;

import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2604;
import net.minecraft.class_2828;
import net.minecraft.class_2868;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_5134;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.api.Setting;
import net.staro.nomnom.api.event.listener.Listener;
import net.staro.nomnom.events.PacketEvent;
import net.staro.nomnom.events.tick.TickEvent;
import net.staro.nomnom.module.Category;
import net.staro.nomnom.module.NomnomModule;
import net.staro.nomnom.utility.CrystalDamage;
import net.staro.nomnom.utility.HitWindow;
import net.staro.nomnom.utility.MotionPredictor;
import net.staro.nomnom.utility.PopTracker;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Crystal PvP.
 *
 * <p>What it does each tick:
 * <ol>
 *   <li>Picks targets and works out where they will be when the crystal goes off (measured
 *       velocity, run through the world collision).</li>
 *   <li>Breaks crystals that hurt the target enough and hurt you little enough, with up to
 *       MaxBreaks hits per tick, and also the moment a crystal spawns (SpawnBreak), not on the
 *       next tick.</li>
 *   <li>Places crystals on the best spots. The search sorts every spot by a cheap upper bound
 *       of its damage and only does the expensive raycasts for the most promising ones, then
 *       stops as soon as nothing left can beat what it has.</li>
 * </ol>
 *
 * <p>Scoring: damage to the target, plus a share of the damage to the other targets, minus
 * SelfWeight times the damage to you. Spots that would hurt you more than your limit, would
 * leave you under SafeHealth, or would hurt a friend are dropped, and a spot that kills the
 * target is allowed to cost you more (LethalSelfDamage).
 *
 * <p>Timing: after a hit a player ignores damage up to that hit for half a second, and after a
 * totem pop for a bit longer. Breaks wait until a crystal would do real damage again (HitWindow,
 * DoublePop) while placing carries on, so fresh crystals are ready the moment the window ends.
 */
@SuppressWarnings("unused")
public class AutoCrystal extends NomnomModule {

    public enum TargetMode {NEAREST, LOWEST_HEALTH, WEAKEST_ARMOR}

    // --- General ---
    private final Setting<Boolean> autoPlace = bool("AutoPlace", true);
    private final Setting<Boolean> autoBreak = bool("AutoBreak", true);
    private final Setting<Integer> placeRange = integer("PlaceRange", 4, 1, 6);
    private final Setting<Integer> breakRange = integer("BreakRange", 5, 1, 6);
    // Beyond these distances a target spot / crystal must be in plain sight. Anticheats are much
    // stricter about reaching through walls.
    private final Setting<Double> placeWallRange = precise("PlaceWallRange", 3.5, 1.0, 6.0);
    private final Setting<Double> breakWallRange = precise("BreakWallRange", 3.5, 1.0, 6.0);
    private final Setting<Integer> targetRange = integer("TargetRange", 8, 2, 12);
    private final Setting<Integer> maxPlacementsPerTick = integer("MaxPlacementsPerTick", 3, 1, 8);
    private final Setting<Integer> maxBreaks = integer("MaxBreaks", 2, 1, 4);
    private final Setting<Boolean> players = bool("Players", true);
    private final Setting<Boolean> mobs = bool("Mobs", true);
    private final Setting<TargetMode> targetMode = enumSetting("TargetMode", TargetMode.NEAREST);
    // How many targets are considered. The first one decides what is lethal; the others add to
    // the score of a spot, so crystals that hit two people are preferred.
    private final Setting<Integer> maxTargets = integer("MaxTargets", 3, 1, 5);
    private final Setting<Double> secondaryWeight = precise("SecondaryWeight", 0.4, 0.0, 1.0);

    // --- Speed ---
    // Remove the crystal from the client world as soon as we hit it. This stops us hitting the
    // same ghost crystal every tick and frees the spot so a new crystal can be placed on it in
    // the same tick.
    private final Setting<Boolean> instantRemove = bool("InstantRemove", true);
    // Break a crystal the moment the server tells us it exists, instead of on the next tick.
    private final Setting<Boolean> spawnBreak = bool("SpawnBreak", true);
    // Minimum ticks between two hits on the same crystal (only matters if it is still around).
    private final Setting<Integer> breakDelay = integer("BreakDelay", 2, 0, 5);
    // Send a silent rotation packet to the crystal / block before each action, then restore.
    private final Setting<Boolean> rotate = bool("Rotate", true);

    // --- Damage ---
    private final Setting<Double> minDamage = precise("MinDamage", 4.0, 0.5, 20.0);
    // Ticks of target movement to predict ahead when calculating damage.
    private final Setting<Integer> predict = integer("Predict", 1, 0, 5);
    // Spots that would kill the target (damage >= health + absorption) are used first.
    private final Setting<Boolean> lethalPriority = bool("LethalPriority", true);
    // When the target's health + absorption is at or below this, MinDamage drops to 1 so
    // any spot that hurts them is used (face placing). 0 disables it.
    private final Setting<Integer> facePlaceHealth = integer("FacePlaceHealth", 8, 0, 36);
    // Face place as well when a piece of the target's armor is below this percent durability,
    // so the armor gets broken faster. 0 disables it.
    private final Setting<Integer> armorBreak = integer("ArmorBreak", 20, 0, 100);
    // Read the target's real Protection / Blast Protection enchants from their armor.
    private final Setting<Boolean> readEnchants = bool("ReadEnchants", true);
    // Used when ReadEnchants is off: 16 is Protection IV everywhere, 20 is the cap.
    private final Setting<Integer> assumedProtection = integer("AssumedProtection", 16, 0, 20);

    // --- Safety ---
    private final Setting<Boolean> selfCheck = bool("SelfCheck", true);
    // Most damage a crystal may deal to you.
    private final Setting<Double> maxSelfDamage = precise("MaxSelfDamage", 6.0, 0.5, 20.0);
    // The same limit when the crystal kills the target.
    private final Setting<Double> lethalSelfDamage = precise("LethalSelfDamage", 10.0, 0.5, 30.0);
    // How much each point of self damage costs in the score of a spot.
    private final Setting<Double> selfWeight = precise("SelfWeight", 0.6, 0.0, 3.0);
    // A crystal may never leave you with less than this much health (plus absorption).
    private final Setting<Double> safeHealth = precise("SafeHealth", 3.0, 0.0, 20.0);
    // Without a totem on you, only risk half of what is left.
    private final Setting<Boolean> strictNoTotem = bool("StrictNoTotem", true);
    // Ticks of your own movement to predict ahead.
    private final Setting<Integer> selfPredict = integer("SelfPredict", 1, 0, 3);
    private final Setting<Boolean> friendSafe = bool("FriendSafe", true);
    private final Setting<Double> maxFriendDamage = precise("MaxFriendDamage", 2.0, 0.0, 20.0);

    // --- SurroundBreak ---
    // When SurroundBreak has just sent the packet that finishes a surround block, place a
    // crystal on that spot straight away, in the same tick. The server breaks the block before
    // it reads the placement, so this saves the round trip it takes our client to see the block
    // gone. The spot is checked as if the block were already air (damage to the target, damage
    // to you, friends).
    private final Setting<Boolean> preArm = bool("PreArm", true);

    // --- Obsidian ---
    // When no valid crystal spot exists, place an obsidian base (needs obsidian in the hotbar)
    // on the best spot and crystal it on the following tick.
    private final Setting<Boolean> obsidianBase = bool("ObsidianBase", true);

    // --- Timing ---
    // Hold breaks while the target is inside its post-hit immunity and the crystal wouldn't do
    // real damage yet. See HitWindow.
    private final Setting<Boolean> hitWindow = bool("HitWindow", true);
    // After the target pops a totem the server ignores any damage that doesn't beat their last
    // hit for ~10 ticks, so breaking early is wasted. We hold breaking (but keep placing, so
    // crystals are armed) and release right as that window ends. See PopTracker.
    private final Setting<Boolean> doublePop = bool("DoublePop", true);
    private final Setting<Integer> popDelay = integer("PopDelay", 10, 0, 20);
    private final Setting<Boolean> pingComp = bool("PingComp", true);
    private final Setting<Boolean> debug = bool("Debug", false);

    private static final double REACH = 4.5;
    private static final double EXPLOSION_REACH = 12.0;
    private static final double LETHAL_BONUS = 1000.0;
    private static final int RESTOCK_THRESHOLD = 10;
    private static final int RESTOCK_COOLDOWN_TICKS = 5;
    private static final int MEMORY_SIZE_LIMIT = 64;
    private static final int MEMORY_MAX_AGE_TICKS = 40;
    private static final class_1304[] ARMOR = {
            class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166
    };

    private record Tracked(class_1309 entity, class_243 position) {
    }

    /** Everything a tick works out once and the break / place code then reuses. */
    private record Context(
            long tick,
            class_1309 primary,
            class_243 primaryPosition,
            List<Tracked> secondaries,
            List<class_1657> friends,
            class_243 selfPosition,
            double required,
            double healthTotal,
            double selfLimit,
            double selfLimitLethal,
            int latency
    ) {
    }

    private static final class Spot {
        class_2338 base;
        class_243 centre;
        class_238 box;
        class_3965 support;
        double bound;
        double damage;
        double self;
        double key;
        boolean lethal;
    }

    private record Option(class_1511 crystal, double key) {
    }

    private final PopTracker pops;
    private final CrystalDamage calculator;
    private final MotionPredictor motion;
    private final HitWindow window = new HitWindow();

    private final Map<Integer, Long> lastHitTick = new HashMap<>();
    // Crystal spots we already sent a placement for. The crystal entity only shows up on our
    // client after the server's spawn packet (about one ping later), so without this the same
    // spot looks empty and gets re-placed every tick.
    private final Map<class_2338, Long> recentPlacements = new HashMap<>();

    private Context lastContext;
    private long preArmedSince = -1;
    private long tickCounter;
    private long lastRestockTick = -100;
    private long lastObsidianTick = -100;
    private boolean rotated;

    public AutoCrystal(Nomnom nomnom) {
        super(
                nomnom,
                "AutoCrystal",
                Category.COMBAT,
                "Automatically places and breaks end crystals"
        );

        this.pops = new PopTracker(mc);
        this.calculator = new CrystalDamage(mc);
        this.motion = new MotionPredictor(mc);
    }

    @Override
    public void onDisable() {
        pops.reset();
        calculator.reset();
        motion.reset();
        window.reset();
        lastHitTick.clear();
        recentPlacements.clear();
        lastContext = null;
        rotated = false;
    }

    // ------------------------------------------------------------------ packets

    @Listener
    public void onPacket(PacketEvent.Receive event) {
        // Network thread: nothing here may touch the world directly.
        class_2596<?> packet = event.getPacket();

        if (doublePop.getValue()) {
            pops.onPacket(packet);
        }

        if (spawnBreak.getValue()
                && autoBreak.getValue()
                && packet instanceof class_2604 spawn
                && spawn.method_11169() == class_1299.field_6110) {
            int id = spawn.method_11167();

            // This hook runs before the packet is handled, which happens on the game thread.
            // Queueing from inside a game thread task puts the second task behind the packet's
            // own, so by the time it runs the crystal exists.
            mc.execute(() -> mc.execute(() -> breakSpawned(id)));
        }
    }

    /** Hits a freshly spawned crystal right away, using what the last tick worked out. */
    private void breakSpawned(int id) {
        try {
            Context context = lastContext;

            if (!isEnabled()
                    || context == null
                    || mc.field_1724 == null
                    || mc.field_1687 == null
                    || mc.field_1761 == null
                    || mc.method_1562() == null
                    || tickCounter - context.tick() > 2
                    || !context.primary().method_5805()
                    || pops.holding(tickCounter, doublePop.getValue(), this::debugMessage)) {
                return;
            }

            breakCrystals(context, id);
        } catch (RuntimeException exception) {
            debugMessage("Spawn break failed: " + exception);
        } finally {
            restoreRotation();
        }
    }

    // --------------------------------------------------------------------- tick

    @Listener
    public void onTick(TickEvent event) {
        if (mc.field_1724 == null
                || mc.field_1687 == null
                || mc.field_1761 == null
                || mc.method_1562() == null) {
            return;
        }

        try {
            run();
        } finally {
            restoreRotation();
        }
    }

    private void run() {
        tickCounter++;

        pops.process(tickCounter, popDelay.getValue(), pingComp.getValue(), this::debugMessage);
        boolean holding = pops.holding(tickCounter, doublePop.getValue(), this::debugMessage);

        restockCrystals();

        List<class_1309> targets = findTargets();
        if (targets.isEmpty()) {
            lastContext = null;
            return;
        }

        calculator.update(tickCounter, readEnchants.getValue(), assumedProtection.getValue());

        for (class_1309 target : targets) {
            motion.observe(tickCounter, target);
            window.observe(tickCounter, target);
        }

        class_1309 primary = targets.get(0);

        List<Tracked> secondaries = new ArrayList<>();
        for (int i = 1; i < targets.size(); i++) {
            class_1309 other = targets.get(i);
            secondaries.add(new Tracked(other, motion.predict(other, predict.getValue(), false)));
        }

        double healthTotal = primary.method_6032() + primary.method_6067();
        boolean facePlace = (facePlaceHealth.getValue() > 0 && healthTotal <= facePlaceHealth.getValue())
                || armorLow(primary);

        double ownHealth = mc.field_1724.method_6032() + mc.field_1724.method_6067();
        double budget = ownHealth - safeHealth.getValue();
        if (strictNoTotem.getValue() && !hasTotem()) {
            budget *= 0.5;
        }
        budget = Math.max(0.0, budget);

        boolean checkSelf = selfChecking();

        Context context = new Context(
                tickCounter,
                primary,
                motion.predict(primary, predict.getValue(), false),
                secondaries,
                nearbyFriends(),
                motion.predict(mc.field_1724, selfPredict.getValue(), true),
                facePlace ? 1.0 : minDamage.getValue(),
                healthTotal,
                checkSelf ? Math.min(maxSelfDamage.getValue(), budget) : Double.MAX_VALUE,
                checkSelf ? Math.min(lethalSelfDamage.getValue(), budget) : Double.MAX_VALUE,
                pops.pingTicks()
        );

        lastContext = context;

        if (autoBreak.getValue() && !holding) {
            breakCrystals(context, -1);
        }

        if (autoPlace.getValue()) {
            if (preArm.getValue()) {
                preArm(context);
            }

            placeCrystals(context);
        }
    }

    private void debugMessage(String message) {
        if (debug.getValue() && mc.field_1724 != null) {
            mc.field_1724.method_7353(class_2561.method_43470("[AutoCrystal] " + message), false);
        }
    }

    /** Ticks a sent placement is remembered: about one round trip plus a little slack. */
    private int memoryTicks() {
        return pops.pingTicks() + 2;
    }

    private void pruneMemory(Map<?, Long> memory) {
        if (memory.size() > MEMORY_SIZE_LIMIT) {
            memory.values().removeIf(tick -> tickCounter - tick > MEMORY_MAX_AGE_TICKS);
        }
    }

    // ------------------------------------------------------------------- safety

    /** False when the check is off or you can't be hurt anyway (creative, spectator). */
    private boolean selfChecking() {
        return selfCheck.getValue()
                && !mc.field_1724.method_68878()
                && !mc.field_1724.method_7325()
                && !mc.field_1724.method_31549().field_7480;
    }

    private boolean selfSafe(Context context, double selfDamage, boolean lethal) {
        return selfDamage <= (lethal ? context.selfLimitLethal() : context.selfLimit()) + 1.0E-6;
    }

    /** True if no friend would take more than the limit from an explosion at {@code centre}. */
    private boolean friendsSafe(Context context, class_243 centre) {
        if (!friendSafe.getValue() || context.friends().isEmpty()) {
            return true;
        }

        double limit = maxFriendDamage.getValue();

        for (class_1657 friend : context.friends()) {
            class_243 position = CrystalDamage.positionOf(friend);

            if (calculator.estimate(friend, position, centre) > limit
                    && calculator.damage(friend, position, centre) > limit) {
                return false;
            }
        }

        return true;
    }

    /** Share of the damage the other targets would take, for the score. */
    private double secondaryBonus(Context context, class_243 centre) {
        if (context.secondaries().isEmpty() || secondaryWeight.getValue() <= 0.0) {
            return 0.0;
        }

        double sum = 0.0;

        for (Tracked tracked : context.secondaries()) {
            if (calculator.estimate(tracked.entity(), tracked.position(), centre) >= 1.0) {
                sum += calculator.damage(tracked.entity(), tracked.position(), centre);
            }
        }

        return sum * secondaryWeight.getValue();
    }

    private double secondaryBound(Context context, class_243 centre) {
        if (context.secondaries().isEmpty() || secondaryWeight.getValue() <= 0.0) {
            return 0.0;
        }

        double sum = 0.0;

        for (Tracked tracked : context.secondaries()) {
            sum += calculator.estimate(tracked.entity(), tracked.position(), centre);
        }

        return sum * secondaryWeight.getValue();
    }

    private List<class_1657> nearbyFriends() {
        List<class_1657> friends = new ArrayList<>();

        if (!friendSafe.getValue()) {
            return friends;
        }

        for (class_1657 player : mc.field_1687.method_18456()) {
            if (player != mc.field_1724
                    && player.method_5805()
                    && nomnom.friendManager().isFriend(player)
                    && mc.field_1724.method_5858(player) <= 24.0 * 24.0) {
                friends.add(player);
            }
        }

        return friends;
    }

    private boolean hasTotem() {
        if (mc.field_1724.method_6079().method_31574(class_1802.field_8288)) {
            return true;
        }

        var inventory = mc.field_1724.method_31548();
        for (int slot = 0; slot < 36; slot++) {
            if (inventory.method_5438(slot).method_31574(class_1802.field_8288)) {
                return true;
            }
        }

        return false;
    }

    /** True when one of the target's armor pieces is almost broken. */
    private boolean armorLow(class_1309 target) {
        int percent = armorBreak.getValue();

        if (percent <= 0) {
            return false;
        }

        for (class_1304 slot : ARMOR) {
            class_1799 stack = target.method_6118(slot);

            if (stack.method_7963() && stack.method_7936() > 0) {
                double left = 1.0 - (double) stack.method_7919() / stack.method_7936();

                if (left * 100.0 < percent) {
                    return true;
                }
            }
        }

        return false;
    }

    private boolean visible(class_243 from, class_243 to) {
        return mc.field_1687.method_17742(new class_3959(
                from,
                to,
                class_3959.class_3960.field_17558,
                class_3959.class_242.field_1348,
                mc.field_1724
        )).method_17783() == class_239.class_240.field_1333;
    }

    // ----------------------------------------------------------------- breaking

    private void breakCrystals(Context context, int onlyId) {
        double range = breakRange.getValue();
        class_243 eye = mc.field_1724.method_33571();

        // Damage the target would still ignore from its last hit.
        double ignored = hitWindow.getValue()
                ? window.ignored(context.primary(), context.latency())
                : 0.0;

        List<Option> options = new ArrayList<>();

        for (class_1511 crystal : mc.field_1687.method_8390(
                class_1511.class,
                mc.field_1724.method_5829().method_1014(range),
                entity -> entity.method_5805()
                        && (onlyId < 0 || entity.method_5628() == onlyId)
                        && mc.field_1724.method_5858(entity) <= range * range
        )) {
            Long lastHit = lastHitTick.get(crystal.method_5628());
            if (lastHit != null && tickCounter - lastHit <= breakDelay.getValue()) {
                continue;
            }

            class_243 centre = CrystalDamage.positionOf(crystal);

            // Cheap upper bound first: most crystals can be ruled out without any raycast.
            if (calculator.estimate(context.primary(), context.primaryPosition(), centre) - ignored
                    < context.required()) {
                continue;
            }

            class_243 middle = crystal.method_5829().method_1005();
            if (eye.method_1022(middle) > breakWallRange.getValue() && !visible(eye, middle)) {
                continue;
            }

            double full = calculator.damage(context.primary(), context.primaryPosition(), centre);
            double marginal = Math.max(0.0, full - ignored);

            if (marginal < context.required()) {
                continue;
            }

            boolean lethal = marginal >= context.healthTotal();

            // Inside the immunity window a hit that only adds a sliver is not worth the crystal:
            // wait the few ticks until it does full damage.
            if (ignored > 0.0 && !lethal && marginal < full * 0.5) {
                continue;
            }

            double self = selfChecking()
                    ? calculator.damage(mc.field_1724, context.selfPosition(), centre)
                    : 0.0;

            if (!selfSafe(context, self, lethal) || !friendsSafe(context, centre)) {
                continue;
            }

            double score = marginal + secondaryBonus(context, centre) - selfWeight.getValue() * self;
            options.add(new Option(crystal, score + (lethal && lethalPriority.getValue() ? LETHAL_BONUS : 0.0)));
        }

        if (options.isEmpty()) {
            return;
        }

        options.sort(Comparator.comparingDouble(Option::key).reversed());

        int hits = Math.min(maxBreaks.getValue(), options.size());

        for (int i = 0; i < hits; i++) {
            class_1511 crystal = options.get(i).crystal();

            faceSilently(crystal.method_5829().method_1005());

            mc.field_1761.method_2918(mc.field_1724, crystal);
            mc.field_1724.method_6104(class_1268.field_5808);

            lastHitTick.put(crystal.method_5628(), tickCounter);

            // The spot is free again, so a new crystal may go there straight away.
            recentPlacements.remove(class_2338.method_49637(crystal.method_23317(), crystal.method_23318() - 1.0, crystal.method_23321()));

            if (instantRemove.getValue()) {
                mc.field_1687.method_2945(crystal.method_5628(), class_1297.class_5529.field_26998);
            }
        }

        pruneMemory(lastHitTick);
    }

    // ----------------------------------------------------------------- placing

    private void placeCrystals(Context context) {
        boolean offhandCrystal = mc.field_1724.method_6079().method_31574(class_1802.field_8301);

        int crystalSlot = findHotbarSlot(class_1802.field_8301);

        if (!offhandCrystal && crystalSlot == -1) {
            return;
        }

        int availableCrystals = offhandCrystal
                ? mc.field_1724.method_6079().method_7947()
                : mc.field_1724.method_31548().method_5438(crystalSlot).method_7947();

        int placementLimit = Math.min(maxPlacementsPerTick.getValue(), availableCrystals);

        if (placementLimit <= 0) {
            return;
        }

        List<Spot> chosen = scan(context, false, placementLimit);

        if (chosen.isEmpty()) {
            if (obsidianBase.getValue()) {
                placeObsidianBase(context);
            }
            return;
        }

        placeSpots(chosen, offhandCrystal, crystalSlot);
    }

    /** Sends the placements for {@code chosen}, with one silent slot switch for all of them. */
    private void placeSpots(List<Spot> chosen, boolean offhandCrystal, int crystalSlot) {
        class_1268 hand = offhandCrystal ? class_1268.field_5810 : class_1268.field_5808;

        Runnable placeAll = () -> {
            for (Spot spot : chosen) {
                class_243 hitPoint = class_243.method_24953(spot.base).method_1031(0, 0.5, 0);
                class_3965 hit = new class_3965(hitPoint, class_2350.field_11036, spot.base, false);

                faceSilently(hitPoint);
                mc.field_1761.method_2896(mc.field_1724, hand, hit);
                mc.field_1724.method_6104(hand);

                recentPlacements.put(spot.base, tickCounter);
                debugMessage(String.format("Place %s: %.1f to target, %.1f to you%s",
                        spot.base.method_23854(), spot.damage, spot.self, spot.lethal ? " (lethal)" : ""));
            }
        };

        if (offhandCrystal) {
            placeAll.run();
        } else {
            withSilentSlot(crystalSlot, placeAll);
        }

        pruneMemory(recentPlacements);
    }

    /**
     * Places a crystal on the floor of the surround block SurroundBreak is finishing, once per
     * block. If the server refuses to break the block the placement just fails.
     */
    private void preArm(Context context) {
        SurroundBreak miner = SurroundBreak.INSTANCE;
        class_2338 opening = miner == null ? null : miner.opening();

        if (opening == null || miner.openingSince() == preArmedSince) {
            return;
        }

        class_2338 base = opening.method_10074();
        var floor = mc.field_1687.method_8320(base);

        if (!floor.method_27852(class_2246.field_10540) && !floor.method_27852(class_2246.field_9987)) {
            return;
        }

        boolean offhandCrystal = mc.field_1724.method_6079().method_31574(class_1802.field_8301);
        int crystalSlot = findHotbarSlot(class_1802.field_8301);

        if (!offhandCrystal && crystalSlot == -1) {
            return;
        }

        // Judge the spot as if the block were already gone.
        class_243 centre = new class_243(opening.method_10263() + 0.5, opening.method_10264(), opening.method_10260() + 0.5);
        calculator.setIgnoredBlock(opening);

        try {
            double damage = calculator.damage(context.primary(), context.primaryPosition(), centre);

            if (damage < context.required()) {
                return;
            }

            boolean lethal = damage >= context.healthTotal();
            double self = selfChecking()
                    ? calculator.damage(mc.field_1724, context.selfPosition(), centre)
                    : 0.0;

            if (!selfSafe(context, self, lethal) || !friendsSafe(context, centre)) {
                return;
            }

            Spot spot = new Spot();
            spot.base = base.method_10062();
            spot.centre = centre;
            spot.damage = damage;
            spot.self = self;
            spot.lethal = lethal;

            preArmedSince = miner.openingSince();
            debugMessage("Pre-arming " + opening.method_23854());
            placeSpots(List.of(spot), offhandCrystal, crystalSlot);
        } finally {
            calculator.setIgnoredBlock(null);
        }
    }

    /** Places one obsidian block where a crystal on top of it would be best. */
    private void placeObsidianBase(Context context) {
        // The block only appears on our client after the server's update (about one ping), so
        // wait that long before placing another instead of stacking blocks on every tick.
        if (tickCounter - lastObsidianTick < memoryTicks()) {
            return;
        }

        int obsidianSlot = findHotbarSlot(class_1802.field_8281);
        if (obsidianSlot == -1) {
            return;
        }

        List<Spot> spots = scan(context, true, 1);

        if (spots.isEmpty()) {
            return;
        }

        class_3965 hit = spots.get(0).support;

        withSilentSlot(obsidianSlot, () -> {
            faceSilently(hit.method_17784());
            mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hit);
            mc.field_1724.method_6104(class_1268.field_5808);
        });

        lastObsidianTick = tickCounter;
    }

    /**
     * Finds the best {@code limit} spots for a crystal, or for an obsidian base to put one on.
     *
     * <p>Branch and bound: every candidate gets an upper bound of its score from plain math
     * (full exposure, no self damage). They are sorted by it, and the exact score, which needs
     * raycasts for the target, you and everyone else involved, is only worked out from the top
     * down until the next bound can't beat the worst spot already kept.
     */
    private List<Spot> scan(Context context, boolean obsidianMode, int limit) {
        class_1309 primary = context.primary();
        class_243 targetPosition = context.primaryPosition();
        class_243 eye = mc.field_1724.method_33571();

        int range = placeRange.getValue();
        double rangeSquared = (double) range * range;
        int memory = memoryTicks();
        boolean lethalFirst = lethalPriority.getValue();

        class_2338 origin = primary.method_24515();
        List<Spot> candidates = new ArrayList<>();

        for (class_2338 base : class_2338.method_10097(
                origin.method_10069(-range, -2, -range),
                origin.method_10069(range, 2, range))) {

            if (mc.field_1724.method_5707(class_243.method_24953(base)) > rangeSquared) {
                continue;
            }

            var state = mc.field_1687.method_8320(base);

            if (obsidianMode) {
                if (!state.method_26215()) {
                    continue;
                }
            } else {
                if (!state.method_27852(class_2246.field_10540) && !state.method_27852(class_2246.field_9987)) {
                    continue;
                }

                Long placedAt = recentPlacements.get(base);
                if (placedAt != null && tickCounter - placedAt < memory) {
                    continue;
                }
            }

            class_2338 above = base.method_10084();

            if (!mc.field_1687.method_8320(above).method_26215()) {
                continue;
            }

            class_243 centre = new class_243(above.method_10263() + 0.5, above.method_10264(), above.method_10260() + 0.5);

            if (centre.method_1025(targetPosition) > EXPLOSION_REACH * EXPLOSION_REACH) {
                continue;
            }

            double targetBound = calculator.estimate(primary, targetPosition, centre);

            if (targetBound < context.required()) {
                continue;
            }

            Spot spot = new Spot();
            spot.base = base.method_10062();
            spot.centre = centre;
            spot.box = new class_238(
                    above.method_10263(), above.method_10264(), above.method_10260(),
                    above.method_10263() + 1, above.method_10264() + 2, above.method_10260() + 1
            );
            spot.bound = targetBound + secondaryBound(context, centre)
                    + (lethalFirst && targetBound >= context.healthTotal() ? LETHAL_BONUS : 0.0);

            candidates.add(spot);
        }

        candidates.sort(Comparator.comparingDouble((Spot spot) -> spot.bound).reversed());

        List<Spot> best = new ArrayList<>();

        for (Spot spot : candidates) {
            if (best.size() >= limit && spot.bound <= best.get(best.size() - 1).key) {
                break;
            }

            // Nobody (including the target) may be standing where the crystal goes, or in an
            // obsidian base's way.
            class_238 space = obsidianMode
                    ? new class_238(spot.base.method_10263(), spot.base.method_10264(), spot.base.method_10260(),
                    spot.base.method_10263() + 1, spot.base.method_10264() + 3, spot.base.method_10260() + 1)
                    : spot.box;

            if (!mc.field_1687.method_8335(null, space).isEmpty()) {
                continue;
            }

            class_243 clickPoint;
            if (obsidianMode) {
                spot.support = supportHit(spot.base, eye);

                if (spot.support == null) {
                    continue;
                }

                clickPoint = spot.support.method_17784();
            } else {
                clickPoint = class_243.method_24953(spot.base).method_1031(0, 0.5, 0);
            }

            if (eye.method_1022(clickPoint) > placeWallRange.getValue()
                    && !visible(eye, clickPoint.method_1031(0.0, 0.02, 0.0))) {
                continue;
            }

            double damage = calculator.damage(primary, targetPosition, spot.centre);

            if (damage < context.required()) {
                continue;
            }

            boolean lethal = damage >= context.healthTotal();
            double self = selfChecking()
                    ? calculator.damage(mc.field_1724, context.selfPosition(), spot.centre)
                    : 0.0;

            if (!selfSafe(context, self, lethal) || !friendsSafe(context, spot.centre)) {
                continue;
            }

            spot.damage = damage;
            spot.self = self;
            spot.lethal = lethal;
            spot.key = damage + secondaryBonus(context, spot.centre) - selfWeight.getValue() * self
                    + (lethal && lethalFirst ? LETHAL_BONUS : 0.0);

            insert(best, spot, limit);
        }

        return best;
    }

    /** Adds {@code spot} to {@code best} (highest key first), keeping spots from overlapping. */
    private static void insert(List<Spot> best, Spot spot, int limit) {
        List<Spot> overlapping = new ArrayList<>();

        for (Iterator<Spot> iterator = best.iterator(); iterator.hasNext(); ) {
            Spot other = iterator.next();

            if (other.box.method_994(spot.box)) {
                if (other.key >= spot.key) {
                    return;
                }
                overlapping.add(other);
            }
        }

        best.removeAll(overlapping);
        best.add(spot);
        best.sort(Comparator.comparingDouble((Spot entry) -> entry.key).reversed());

        while (best.size() > limit) {
            best.remove(best.size() - 1);
        }
    }

    /** A click on a neighbouring solid block that places a block at {@code base}. */
    private class_3965 supportHit(class_2338 base, class_243 eye) {
        for (class_2350 direction : class_2350.values()) {
            class_2338 support = base.method_10093(direction);

            if (!mc.field_1687.method_8320(support).method_26212(mc.field_1687, support)) {
                continue;
            }

            class_2350 face = direction.method_10153();
            class_243 point = class_243.method_24953(support).method_1031(
                    face.method_10148() * 0.5,
                    face.method_10164() * 0.5,
                    face.method_10165() * 0.5
            );

            if (eye.method_1025(point) > REACH * REACH) {
                continue;
            }

            return new class_3965(point, face, support, false);
        }

        return null;
    }

    // ------------------------------------------------------------ silent helpers

    /**
     * Silent hotbar switch: one packet to the slot before the action and one back afterwards.
     * The client never actually changes its selected slot.
     */
    private void withSilentSlot(int slot, Runnable action) {
        int previousSlot = mc.field_1724.method_31548().method_67532();
        boolean switched = slot != previousSlot;

        try {
            if (switched) {
                mc.method_1562().method_52787(new class_2868(slot));
            }

            action.run();
        } finally {
            if (switched) {
                mc.method_1562().method_52787(new class_2868(previousSlot));
            }
        }
    }

    /** Tells the server we are looking at {@code point} without moving the player's camera. */
    private void faceSilently(class_243 point) {
        if (!rotate.getValue()) {
            return;
        }

        class_243 eye = mc.field_1724.method_33571();
        double dx = point.field_1352 - eye.field_1352;
        double dy = point.field_1351 - eye.field_1351;
        double dz = point.field_1350 - eye.field_1350;
        double horizontal = Math.hypot(dx, dz);

        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal));

        sendLook(class_3532.method_15393(yaw), class_3532.method_15363(pitch, -90.0f, 90.0f));
        rotated = true;
    }

    /** Puts the server's idea of our rotation back to the real one. */
    private void restoreRotation() {
        if (!rotated || mc.field_1724 == null || mc.method_1562() == null) {
            rotated = false;
            return;
        }

        sendLook(mc.field_1724.method_36454(), mc.field_1724.method_36455());
        rotated = false;
    }

    private void sendLook(float yaw, float pitch) {
        mc.method_1562().method_52787(new class_2828.class_2831(
                yaw, pitch, mc.field_1724.method_24828(), mc.field_1724.field_5976));
    }

    // ---------------------------------------------------------------- inventory

    private int findHotbarSlot(class_1792 item) {
        for (int slot = 0; slot < 9; slot++) {
            if (mc.field_1724.method_31548().method_5438(slot).method_31574(item)) {
                return slot;
            }
        }

        return -1;
    }

    /**
     * Tops the hotbar up with crystals from the main inventory. Shift-click merges into the
     * existing hotbar stack instead of swapping stacks back and forth, and it only runs every
     * few ticks so it can't spam inventory packets.
     */
    private void restockCrystals() {
        if (tickCounter - lastRestockTick < RESTOCK_COOLDOWN_TICKS) {
            return;
        }

        var inventory = mc.field_1724.method_31548();
        int hotbarCrystals = 0;

        for (int slot = 0; slot < 9; slot++) {
            var stack = inventory.method_5438(slot);

            if (stack.method_31574(class_1802.field_8301)) {
                hotbarCrystals += stack.method_7947();
            }
        }

        if (hotbarCrystals > RESTOCK_THRESHOLD) {
            return;
        }

        for (int inventorySlot = 9; inventorySlot < 36; inventorySlot++) {
            if (!inventory.method_5438(inventorySlot).method_31574(class_1802.field_8301)) {
                continue;
            }

            mc.field_1761.method_2906(
                    mc.field_1724.field_7512.field_7763,
                    inventorySlot,
                    0,
                    class_1713.field_7794,
                    mc.field_1724
            );

            lastRestockTick = tickCounter;
            return;
        }
    }

    // ----------------------------------------------------------------- targeting

    private List<class_1309> findTargets() {
        double range = targetRange.getValue();

        var found = mc.field_1687.method_8390(
                class_1309.class,
                mc.field_1724.method_5829().method_1014(range),
                entity -> entity != mc.field_1724
                        && entity.method_5805()
                        && isValidTarget(entity)
                        && mc.field_1724.method_5858(entity) <= range * range
        );

        found.sort(switch (targetMode.getValue()) {
            case NEAREST -> Comparator.comparingDouble((class_1309 entity) -> mc.field_1724.method_5858(entity));
            case LOWEST_HEALTH -> Comparator.comparingDouble(
                    (class_1309 entity) -> entity.method_6032() + entity.method_6067());
            case WEAKEST_ARMOR -> Comparator.comparingDouble(
                    (class_1309 entity) -> entity.method_45325(class_5134.field_23724));
        });

        int count = Math.min(maxTargets.getValue(), found.size());
        return new ArrayList<>(found.subList(0, count));
    }

    private boolean isValidTarget(class_1309 entity) {
        if (entity instanceof class_1657 player) {
            return players.getValue() && !nomnom.friendManager().isFriend(player);
        }
        return mobs.getValue();
    }
}