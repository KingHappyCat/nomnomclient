package net.staro.nomnom.events.render;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import net.minecraft.class_332;

/** Posted every frame while the HUD is drawn. Modules draw 2D overlays with {@link #getContext()}. */
@Getter
@RequiredArgsConstructor
public class Render2DEvent {
    private final class_332 context;
    private final float tickProgress;
}
