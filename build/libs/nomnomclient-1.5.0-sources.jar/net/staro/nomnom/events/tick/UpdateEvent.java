package net.staro.nomnom.events.tick;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import net.minecraft.class_746;
import net.staro.nomnom.events.CancellableEvent;

@Getter
@RequiredArgsConstructor
public class UpdateEvent extends CancellableEvent {
    private final class_746 player;

}
