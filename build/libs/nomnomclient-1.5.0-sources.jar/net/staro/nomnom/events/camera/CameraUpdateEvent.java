package net.staro.nomnom.events.camera;

import lombok.Getter;
import lombok.Setter;
import net.minecraft.class_1297;
import net.minecraft.class_1922;
import net.staro.nomnom.events.CancellableEvent;

@Getter
@Setter
public class CameraUpdateEvent extends CancellableEvent {
    public static final CameraUpdateEvent INSTANCE = new CameraUpdateEvent();

    private class_1922 area;
    private class_1297 focusedEntity;
    private boolean thirdPerson;
    private boolean inverseView;
    private float tickDelta;

}
