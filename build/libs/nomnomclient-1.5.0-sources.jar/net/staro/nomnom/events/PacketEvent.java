package net.staro.nomnom.events;

import lombok.Getter;
import lombok.Setter;
import net.minecraft.class_2596;

public class PacketEvent {
    @Getter
    @Setter
    public static class Receive extends CancellableEvent {
        private class_2596<?> packet;
    }

    @Getter
    @Setter
    public static class Send extends CancellableEvent {
        private class_2596<?> packet;
    }

}

