package net.staro.nomnom.events.chat;

import com.mojang.brigadier.ParseResults;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.suggestion.Suggestions;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import net.minecraft.class_2172;
import net.minecraft.class_342;
import net.minecraft.class_4717;
import net.staro.nomnom.events.CancellableEvent;
import org.jetbrains.annotations.Nullable;

import java.util.concurrent.CompletableFuture;

@Getter
@Setter
@AllArgsConstructor
public class InputSuggestorEvent extends CancellableEvent {
    private final class_342 textField;
    private final StringReader reader;
    private @Nullable ParseResults<class_2172> parse;
    private @Nullable CompletableFuture<Suggestions> pendingSuggestions;
    private @Nullable class_4717.class_464 window;
    private boolean completingSuggestions;

}
