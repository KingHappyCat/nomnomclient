package net.staro.nomnom.ducks;

import net.minecraft.class_303;
import net.minecraft.class_7469;
import org.jetbrains.annotations.Nullable;

public interface IChatHud {
    void nomnom$addMessage(@Nullable class_303 message);

    void nomnom$addVisibleMessage(@Nullable class_303 message);

    void nomnom$deleteMessage(@Nullable class_7469 signature, boolean all);

}
