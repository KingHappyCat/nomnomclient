package net.staro.nomnom.mixin;

import net.minecraft.class_128;
import net.minecraft.class_310;
import net.minecraft.class_542;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.NomnomClient;
import net.staro.nomnom.events.client.ShutdownEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.io.File;

@Mixin(class_310.class)
public abstract class MixinMinecraftClient {
	/**
	 * Client's custom entry point.
	 * Not using fabric's default client initialization due to several reasons which im too lazy to explain.
	 * This is better, trust me bro!
	 */
	@Inject(method = "<init>", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/MinecraftClient;setOverlay(Lnet/minecraft/client/gui/screen/Overlay;)V"))
	public void initializeClientHook(class_542 args, CallbackInfo ci) {
		new NomnomClient().onInitializeClient(class_310.class.cast(this));
	}

	@Inject(method = "stop", at = @At("HEAD"))
	public void stop(CallbackInfo info) {
		Nomnom.EVENT_BUS.post(new ShutdownEvent());
	}

	@Inject(method = "printCrashReport(Lnet/minecraft/client/MinecraftClient;Ljava/io/File;Lnet/minecraft/util/crash/CrashReport;)V", at = @At(value = "HEAD"))
	private static void printCrashReportHook(class_310 client, File runDirectory, class_128 crashReport, CallbackInfo ci) {
		Nomnom.EVENT_BUS.post(new ShutdownEvent());
	}

	@Inject(method = "run", at = @At("RETURN"))
	private void runHook(CallbackInfo ci) {
		Nomnom.EVENT_BUS.post(new ShutdownEvent());
	}

}