package net.staro.nomnom.mixin.render;

import net.minecraft.class_1297;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.staro.nomnom.module.modules.NoRender;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** NoRender: the dark screen-edge vignette. */
@Mixin(class_329.class)
public class MixinInGameHud {
    @Inject(method = "renderVignetteOverlay", at = @At("HEAD"), cancellable = true)
    private void nomnom$hideVignette(class_332 context, class_1297 entity, CallbackInfo ci) {
        NoRender noRender = NoRender.INSTANCE;
        if (noRender != null && noRender.hideVignette()) {
            ci.cancel();
        }
    }
}