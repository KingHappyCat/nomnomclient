package net.staro.nomnom.mixin.render;

import net.minecraft.class_12077;
import net.minecraft.class_243;
import net.minecraft.class_4597;
import net.minecraft.class_9976;
import net.staro.nomnom.module.modules.NoRender;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * NoRender: rain and snow streaks. Rain splash particles and the rain sound still happen,
 * those come from {@code addParticlesAndSound}.
 */
@Mixin(class_9976.class)
public class MixinWeatherRendering {
    @Inject(method = "renderPrecipitation", at = @At("HEAD"), cancellable = true)
    private void nomnom$hideWeather(class_4597 vertexConsumers, class_243 pos,
                                    class_12077 state, CallbackInfo ci) {
        NoRender noRender = NoRender.INSTANCE;
        if (noRender != null && noRender.hideWeather()) {
            ci.cancel();
        }
    }
}