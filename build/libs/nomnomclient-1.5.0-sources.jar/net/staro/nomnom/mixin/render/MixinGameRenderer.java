package net.staro.nomnom.mixin.render;

import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.staro.nomnom.module.modules.NoRender;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** NoRender: the camera tilt when you take damage. */
@Mixin(class_757.class)
public class MixinGameRenderer {
    @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true)
    private void nomnom$hideHurtCamera(class_4587 matrices, float tickProgress, CallbackInfo ci) {
        NoRender noRender = NoRender.INSTANCE;
        if (noRender != null && noRender.hideHurtCamera()) {
            ci.cancel();
        }
    }
}