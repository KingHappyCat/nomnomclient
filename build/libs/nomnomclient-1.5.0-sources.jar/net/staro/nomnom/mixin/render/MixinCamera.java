package net.staro.nomnom.mixin.render;

import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_4184;
import net.staro.nomnom.events.camera.CameraUpdateEvent;
import net.staro.nomnom.utility.MixinHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4184.class)
public abstract class MixinCamera {
    @Inject(method = "update", at = @At("HEAD"), cancellable = true)
    private void onUpdate(class_1937 area,
                          class_1297 focusedEntity,
                          boolean thirdPerson,
                          boolean inverseView,
                          float tickDelta,
                          CallbackInfo ci) {
        var event = CameraUpdateEvent.INSTANCE;
        event.setArea(area);
        event.setFocusedEntity(focusedEntity);
        event.setThirdPerson(thirdPerson);
        event.setInverseView(inverseView);
        event.setTickDelta(tickDelta);
        MixinHelper.hook(event, ci);
    }

}