package net.staro.nomnom.mixin.render;

import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_702;
import net.minecraft.class_703;
import net.staro.nomnom.module.modules.NoRender;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** NoRender: potion swirl particles and explosion particles. */
@Mixin(class_702.class)
public class MixinParticleManager {
    @Inject(
            method = "addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)Lnet/minecraft/client/particle/Particle;",
            at = @At("HEAD"),
            cancellable = true
    )
    private void nomnom$hideParticles(class_2394 parameters, double x, double y, double z,
                                      double velocityX, double velocityY, double velocityZ,
                                      CallbackInfoReturnable<class_703> cir) {
        NoRender noRender = NoRender.INSTANCE;
        if (noRender == null) {
            return;
        }

        var type = parameters.method_10295();

        if ((type == class_2398.field_11236 || type == class_2398.field_11221)
                && noRender.hideExplosionParticles()) {
            cir.setReturnValue(null);
        } else if (type == class_2398.field_11226 && noRender.hidePotionParticles()) {
            cir.setReturnValue(null);
        }
    }
}