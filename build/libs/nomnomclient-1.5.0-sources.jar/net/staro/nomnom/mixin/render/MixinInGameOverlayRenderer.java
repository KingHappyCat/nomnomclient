package net.staro.nomnom.mixin.render;

import net.minecraft.class_1058;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4603;
import net.minecraft.class_5819;
import net.staro.nomnom.module.modules.NoRender;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** NoRender: the first person fire overlay and the totem pop animation. */
@Mixin(class_4603.class)
public class MixinInGameOverlayRenderer {
    @Inject(method = "renderFireOverlay", at = @At("HEAD"), cancellable = true)
    private static void nomnom$hideFire(class_4587 matrices, class_4597 vertexConsumers,
                                        class_1058 sprite, CallbackInfo ci) {
        NoRender noRender = NoRender.INSTANCE;
        if (noRender != null && noRender.hideFire()) {
            ci.cancel();
        }
    }

    // Every way of showing the floating item (GameRenderer.showFloatingItem included) ends here.
    @Inject(method = "setFloatingItem", at = @At("HEAD"), cancellable = true)
    private void nomnom$hideTotemAnimation(class_1799 stack, class_5819 random, CallbackInfo ci) {
        NoRender noRender = NoRender.INSTANCE;
        if (noRender != null && stack.method_31574(class_1802.field_8288) && noRender.hideTotemAnimation()) {
            ci.cancel();
        }
    }
}