package net.staro.nomnom.mixin.chat;

import net.minecraft.class_303;
import net.minecraft.class_338;
import net.minecraft.class_7469;
import net.staro.nomnom.ducks.IChatHud;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.util.List;
import java.util.ListIterator;

@Mixin(class_338.class)
public abstract class MixinChatHud implements IChatHud {
    @Shadow
    @Final
    private List<class_303> messages;

    @Shadow
    protected abstract void refresh();

    @Override
    @Invoker("addMessage")
    public abstract void nomnom$addMessage(@Nullable class_303 message);

    @Override
    @Invoker("addVisibleMessage")
    public abstract void nomnom$addVisibleMessage(@Nullable class_303 message);

    @Override
    public void nomnom$deleteMessage(@Nullable class_7469 signature, boolean all) {
        if (signature == null) {
            return;
        }

        ListIterator<class_303> listIterator = this.messages.listIterator();
        boolean changed = false;
        while (listIterator.hasNext()) {
            var message = listIterator.next();
            if (signature.equals(message.comp_915())) {
                listIterator.remove();
                changed = true;
                if (!all) {
                    break;
                }
            }
        }

        if (changed) {
            this.refresh();
        }
    }

}
