package net.staro.nomnom.mixin.client;

import net.minecraft.class_11908;
import net.minecraft.class_309;
import net.minecraft.class_310;
import net.staro.nomnom.events.client.KeyEvent;
import net.staro.nomnom.utility.MixinHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_309.class)
public abstract class MixinKeyboard {
    @Inject(method = "onKey", at = @At("TAIL"), cancellable = true)
    private void onKey(long windowPointer, int action, class_11908 input, CallbackInfo ci) {
        int key = input.comp_4795();
        int scanCode = input.comp_4796();
        int modifiers = input.comp_4797();

        if (class_310.method_1551().field_1755 == null) {
            var event = KeyEvent.INSTANCE;
            event.setKey(key);
            event.setAction(action);
            MixinHelper.hook(event, ci);
        }
    }

}