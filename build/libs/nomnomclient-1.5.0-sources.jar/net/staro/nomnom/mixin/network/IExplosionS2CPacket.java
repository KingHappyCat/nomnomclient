package net.staro.nomnom.mixin.network;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Optional;
import net.minecraft.class_243;
import net.minecraft.class_2664;

@Mixin(class_2664.class)
public interface IExplosionS2CPacket {
    @Mutable
    @Accessor("playerKnockback")
    void setPlayerKnockback(Optional<class_243> knockback);
}