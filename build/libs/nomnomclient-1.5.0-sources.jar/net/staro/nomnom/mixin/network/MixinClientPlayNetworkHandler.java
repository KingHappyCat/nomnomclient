package net.staro.nomnom.mixin.network;

import net.minecraft.class_310;
import net.minecraft.class_634;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.events.chat.ChatEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public abstract class MixinClientPlayNetworkHandler {
    @Unique
    private boolean acceptMessage = true;

    @Shadow
    public abstract void sendChatMessage(String content);

    @Inject(method = "sendChatMessage", at = @At("HEAD"), cancellable = true)
    private void onSendChatMessage(String message, CallbackInfo ci) {
        if (acceptMessage) {
            var event = new ChatEvent(message);
            Nomnom.EVENT_BUS.post(event);
            if (event.isCancelled()) {
                class_310.method_1551().field_1705.method_1743().method_1803(message);
                ci.cancel();
            } else {
                acceptMessage = false;
                sendChatMessage(event.getMessage());
                acceptMessage = true;
                ci.cancel();
            }
        }
    }

}
