package net.staro.nomnom.mixin.entity;

import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.staro.nomnom.module.modules.Velocity;
import net.staro.nomnom.utility.MixinHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Objects;

@SuppressWarnings({"EqualsBetweenInconvertibleTypes", "DiscouragedShift"})
@Mixin(class_1297.class)
public class MixinEntity {
    @Inject(method = "pushAwayFrom",
            at = @At(value = "INVOKE", target = "Ljava/lang/Math;sqrt(D)D", shift = At.Shift.BEFORE),
            cancellable = true)
    private void entityPushHook(class_1297 entity, CallbackInfo ci) {
        if (Objects.equals(this, class_310.method_1551().field_1724) || Objects.equals(entity, class_310.method_1551().field_1724)) {
            MixinHelper.hook(new Velocity.EntityPush(), ci);
        }
    }

}
