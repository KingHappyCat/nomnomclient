package net.staro.nomnom.command;

import lombok.RequiredArgsConstructor;
import net.minecraft.class_2561;
import net.minecraft.class_303;
import net.minecraft.class_310;
import net.minecraft.class_338;
import net.minecraft.class_746;
import net.minecraft.class_7469;
import net.minecraft.class_7591;
import net.staro.nomnom.ducks.IChatHud;
import org.jetbrains.annotations.Nullable;

import java.nio.charset.StandardCharsets;

// IMPORTANT: THESE ARE NOT NULL SAFE.
@RequiredArgsConstructor
public class Chat {
    private final class_310 mc;

    /**
     * Sends a server-side message in chat.
     * @param message - the string to send in chat.
     * @param player - is a client-side player.
     */
    public void sendPlayerMessage(String message, class_746 player) {
        addToMessageHistory(message);
        player.field_3944.method_45729(message);
    }

    /**
     * Sends a server-side command in chat.
     * @param message - the string to send in chat.
     * @param player - is a client-side player.
     */
    public void sendCommand(String message, class_746 player) {
        addToMessageHistory(message);
        player.field_3944.method_45730(message);    }

    /**
     * Sends a client-side message in chat.
     * @param message is a String to send.
     */
    public void send(String message) {
        send(class_2561.method_43470(message));
    }

    /**
     * Sends a client-side message in chat.
     * @param message is a Text to send.
     */
    public void send(class_2561 message) {
        mc.field_1705.method_1743().method_1812(message);
    }

    public void send(class_2561 message, String identifier) {
        send(mc.field_1705.method_1743(), message, identifier);
    }

    /**
     * Sends a client-side message in chat without leaving it in the log file.
     * @param message is a Text to send.
     */
    public void sendLogless(class_2561 message) {
        sendLogless((IChatHud) mc.field_1705.method_1743(), message, null);
    }

    /**
     * Sends a client-side message in chat without leaving it in the log file.
     * @param message is a Text to send.
     * @param identifier is a String to mark the message. Useful in notifications
     *                  so only the messages with the same module
     *                   get deleted before sending another one.
     */
    public void sendLogless(class_2561 message, String identifier) {
        sendLogless((IChatHud) mc.field_1705.method_1743(), message, identifier);
    }

    /**
     * Deletes an identifier of the message.
     * @param identifier is a String to mark the message. Useful in notifications
     *      *                  so only the messages with the same module
     *      *                   get deleted before sending another one.
     */
    public void delete(String identifier) {
        delete(new class_7469(get256Bytes(identifier)));
    }

    private void send(class_338 chatHud, class_2561 message, @Nullable String identifier) {
        var signature = identifier != null ? new class_7469(get256Bytes(identifier)) : null;
        delete(signature);
        chatHud.method_44811(message, signature, class_7591.method_44751());
    }

    private void sendLogless(IChatHud chatHud, class_2561 message, @Nullable String identifier) {
        var signature = identifier != null ? new class_7469(get256Bytes(identifier)) : null;
        delete(signature);
        var chatHudLine = new class_303(
                mc.field_1705.method_1738(),
                message,
                signature,
                class_7591.method_44751());
        chatHud.nomnom$addVisibleMessage(chatHudLine);
        chatHud.nomnom$addMessage(chatHudLine);
    }

    private void delete(@Nullable class_7469 signature) {
        ((IChatHud) mc.field_1705.method_1743()).nomnom$deleteMessage(signature, true);
    }

    private void addToMessageHistory(String message) {
        mc.field_1705.method_1743().method_1803(message);
    }

    private byte[] get256Bytes(String identifier) {
        byte[] bytes = new byte[256];
        byte[] identifierBytes = identifier.getBytes(StandardCharsets.UTF_8);
        System.arraycopy(identifierBytes, 0, bytes, 0, Math.min(bytes.length, identifierBytes.length));
        return bytes;
    }

}
