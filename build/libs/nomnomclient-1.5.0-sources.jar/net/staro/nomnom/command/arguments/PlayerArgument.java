package net.staro.nomnom.command.arguments;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import lombok.RequiredArgsConstructor;
import net.minecraft.class_2172;
import net.minecraft.class_310;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;

@RequiredArgsConstructor
public class PlayerArgument implements ArgumentType<String> {
    private final class_310 mc;

    @Override
    public String parse(StringReader reader) throws CommandSyntaxException {
        var player = reader.readString();
        return Objects.requireNonNull(mc.method_1562())
                .method_2880()
                .stream()
                .filter(playerInList -> playerInList.method_2966().name().equalsIgnoreCase(player))
                .map(playerInList -> playerInList.method_2966().name())
                .findFirst()
                .orElse(null);
    }

    @Override
    public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
        return class_2172.method_9264(
                Objects.requireNonNull(mc.method_1562()).method_2880()
                        .stream()
                        .map(playerListEntry -> playerListEntry.method_2966().name()), builder
        );
    }

}
