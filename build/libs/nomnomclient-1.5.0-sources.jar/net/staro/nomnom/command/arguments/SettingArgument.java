package net.staro.nomnom.command.arguments;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import net.minecraft.class_124;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.staro.nomnom.api.Module;
import net.staro.nomnom.api.trait.Nameable;
import net.staro.nomnom.setting.GenericSetting;

import java.util.concurrent.CompletableFuture;

public class SettingArgument implements ArgumentType<String> {
    private final Module module;
    private static final DynamicCommandExceptionType NO_SUCH_SETTING =
            new DynamicCommandExceptionType(name -> class_2561.method_43470("A setting called '")
                    .method_27693(name.toString()).method_27692(class_124.field_1061)
                    .method_27693("' doesn't exist."));

    public SettingArgument(Module module) {
        this.module = module;
    }

    public GenericSetting<?> get(CommandContext<?> context) throws CommandSyntaxException {
        var settingName = context.getArgument("setting", String.class);

        GenericSetting<?> setting = module.getSettingByName(settingName);
        if (setting == null) {
            throw NO_SUCH_SETTING.create(settingName);
        }

        return setting;
    }

    @Override
    public String parse(StringReader reader) throws CommandSyntaxException {
        return reader.readString();
    }

    @Override
    public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
        return class_2172.method_9264(module.getSettings().stream().map(Nameable::getName), builder);

    }

}
