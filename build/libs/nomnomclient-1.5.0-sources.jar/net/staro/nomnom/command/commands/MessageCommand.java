package net.staro.nomnom.command.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_2172;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.command.NomnomCommand;
import net.staro.nomnom.command.arguments.StringArgument;

public class MessageCommand extends NomnomCommand {
    public MessageCommand(Nomnom nomnom) {
        super(nomnom, "message", "Sends a server-side message in chat.");
    }

    @Override
    public void build(Nomnom nomnom, LiteralArgumentBuilder<class_2172> builder) {
        builder.then(
                argument("message", StringArgument.greedyString())
                        .executes(context -> {
                            String message = context.getArgument("message", String.class);
                            var player = mc.field_1724;
                            if (player != null) {
                                nomnom.chat().sendPlayerMessage(message, player);
                            }

                            return COMPLETED;
                        }));
    }
}
