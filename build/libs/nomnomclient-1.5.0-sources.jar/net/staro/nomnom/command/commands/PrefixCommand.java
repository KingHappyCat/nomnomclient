package net.staro.nomnom.command.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_124;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.command.NomnomCommand;
import net.staro.nomnom.command.arguments.StringArgument;

public class PrefixCommand extends NomnomCommand {
    public PrefixCommand(Nomnom nomnom) {
        super(nomnom, "prefix", "Sets up the prefix for the client.");
    }

    @Override
    public void build(Nomnom nomnom, LiteralArgumentBuilder<class_2172> builder) {
        builder.then(
                argument("prefix", StringArgument.string())
                        .executes(context -> {
                            var prefix = context.getArgument("prefix", String.class);
                            nomnom.commandManager().setPrefix(prefix);
                            nomnom.chat().send(class_2561.method_43470("The prefix is set to ").method_27692(class_124.field_1067)
                                    .method_10852(class_2561.method_43470(prefix).method_27692(class_124.field_1067).method_27692(class_124.field_1061)));
                            return COMPLETED;
                        }));
    }
}
