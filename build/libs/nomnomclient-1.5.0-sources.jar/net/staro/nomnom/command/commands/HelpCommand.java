
package net.staro.nomnom.command.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.command.NomnomCommand;

public class HelpCommand extends NomnomCommand {

    public HelpCommand(Nomnom nomnom) {
        super(nomnom, "help", "Shows the list of available commands.");
    }

    @Override
    public void build(Nomnom nomnom, LiteralArgumentBuilder<class_2172> builder) {
        builder.executes(context -> {
            nomnom.chat().sendLogless(class_2561.method_43470("Available commands:"));

            nomnom.commandManager().getCommands().forEach(command -> {
                var commandText = class_2561.method_43470(command.getName());

                nomnom.chat().send(
                        commandText.method_27694(style ->
                                style.method_10949(
                                        new class_2568.class_10613(
                                                class_2561.method_43470(command.getDescription())
                                        )
                                )
                        )
                );
            });

            return COMPLETED;
        });
    }
}
