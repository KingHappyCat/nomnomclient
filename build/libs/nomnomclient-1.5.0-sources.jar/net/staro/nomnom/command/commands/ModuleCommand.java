package net.staro.nomnom.command.commands;

import com.google.gson.JsonParser;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import lombok.extern.slf4j.Slf4j;
import net.minecraft.class_124;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.api.Module;
import net.staro.nomnom.command.NomnomCommand;
import net.staro.nomnom.command.arguments.SettingArgument;
import net.staro.nomnom.command.arguments.SettingValueArgument;
import net.staro.nomnom.setting.GenericSetting;
import net.staro.nomnom.utility.SettingUtil;

import java.util.List;
import java.util.function.Predicate;

@Slf4j
public class ModuleCommand extends NomnomCommand {
    private final Module module;
    private final SettingArgument settingArgument;
    private final SettingValueArgument settingValueArgument;

    public ModuleCommand(Module module, Nomnom nomnom, String name, String description) {
        super(nomnom, name, description);
        this.module = module;
        this.settingArgument = new SettingArgument(module);
        this.settingValueArgument = new SettingValueArgument(settingArgument);
    }

    @Override
    @SuppressWarnings({"rawtypes"})
    public void build(Nomnom nomnom, LiteralArgumentBuilder<class_2172> builder) {
        builder.then(argument("setting", settingArgument)
                .executes(context -> {
                    try {
                        nomnom.chat().send("nope");
                    } catch (Exception e) {
                        log.debug(e.toString());
                        return COMPLETED;
                    }

                    return COMPLETED;
                })
                .then(argument("value", settingValueArgument)
                        .executes(context -> {
                            GenericSetting setting = settingArgument.get(context);
                            var settingValue = context.getArgument("value", String.class);
                            if (setting.getName().equalsIgnoreCase("Bind")) {
                                try {
                                    module.setBind(SettingUtil.convertToBind(settingValue).getKey());
                                } catch (Exception e) {
                                    nomnom.chat().send(class_2561.method_43470("")
                                            .method_10852(class_2561.method_43470("Bad value! There's no key "))
                                            .method_10852(class_2561.method_43470(settingValue).method_27692(class_124.field_1061)));
                                    return COMPLETED;
                                }
                            } else {
                                try {
                                    if (setting.getName().equalsIgnoreCase("Enabled")) {
                                        if (settingValue.equalsIgnoreCase("true")) {
                                            module.enable();
                                        } else if (settingValue.equalsIgnoreCase("false")) {
                                            module.disable();
                                        }
                                    }

                                    SettingUtil.setCommandValue(module, setting, JsonParser.parseString(settingValue));
                                } catch (Exception e) {
                                    nomnom.chat().send(class_2561.method_43470("Bad Value! This setting requires a: "
                                            + setting.getType() + " value."));
                                    return COMPLETED;
                                }
                            }

                            nomnom.chat().send(class_2561.method_43470("")
                                    .method_10852(class_2561.method_43470(module.getName()).method_27692(class_124.field_1067))
                                    .method_10852(class_2561.method_43470(" " + setting.getName() + " has been set to ").method_27692(class_124.field_1080))
                                    .method_10852(class_2561.method_43470(settingValue)));
                            return COMPLETED;
                        })));
        builder.executes(context -> {
            nomnom.chat().send((module.isEnabled() ? class_124.field_1075 : class_124.field_1061) + module.getName() + ": ");
            nomnom.chat().send(class_124.field_1063 + module.getDescription());
            List<GenericSetting<?>> filteredSettings = module.getSettings().stream()
                    .filter(setting -> {
                        Predicate<String> settingName = name -> setting.getName().equalsIgnoreCase(name);
                        return !(settingName.test("Bind") || settingName.test("Drawn"));
                    }).toList();
            filteredSettings.forEach(setting -> {
                String value = setting.getValue().toString();
                class_124 valueColor = class_124.field_1068;
                if (setting.getType().equalsIgnoreCase("Boolean") && value.equalsIgnoreCase("false")) {
                    valueColor = class_124.field_1051;
                }

                nomnom.chat().send(class_2561.method_30163(class_124.field_1080 + setting.getName() + ": " + valueColor + value));
            });
            return COMPLETED;
        });
    }

}
