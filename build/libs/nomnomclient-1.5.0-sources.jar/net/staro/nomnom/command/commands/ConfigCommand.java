package net.staro.nomnom.command.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_124;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.command.NomnomCommand;
import net.staro.nomnom.command.arguments.ConfigArgument;
import net.staro.nomnom.command.arguments.StringArgument;

public class ConfigCommand extends NomnomCommand {
    private final ConfigArgument configArgument;

    public ConfigCommand(Nomnom nomnom) {
        super(nomnom, "config", "Manage configs");
        this.configArgument = new ConfigArgument(nomnom);
    }

    @Override
    public void build(Nomnom nomnom, LiteralArgumentBuilder<class_2172> builder) {
        builder.executes(context -> {
            nomnom.chat().sendLogless(class_2561.method_43470("The command usage is: config <save, load, del, list> <name>"));
            return COMPLETED;
        }).then(
                literal("save")
                        .then(argument("name", StringArgument.string())
                                .executes(context -> {
                                    String name = context.getArgument("name", String.class);
                                    nomnom.configManager().saveConfig(name, nomnom);
                                    nomnom.chat().sendLogless(class_2561.method_43470("")
                                            .method_10852(class_2561.method_43470("Config by the name "))
                                            .method_10852(class_2561.method_43470(name).method_27692(class_124.field_1075))
                                            .method_10852(class_2561.method_43470(" has been created successfully")).method_27692(class_124.field_1067));
                                    return COMPLETED;
                                }))
        ).then(
                literal("load")
                        .then(argument("config", configArgument)
                                .executes(context -> {
                                    String config = context.getArgument("config", String.class);
                                    nomnom.configManager().loadConfig(config, nomnom);
                                    nomnom.chat().sendLogless(class_2561.method_43470("")
                                            .method_10852(class_2561.method_43470("Config by the name "))
                                            .method_10852(class_2561.method_43470(config).method_27692(class_124.field_1075))
                                            .method_10852(class_2561.method_43470(" has been loaded successfully")).method_27692(class_124.field_1067));
                                    return COMPLETED;
                                }))
        )
                .then(
                        literal("del")
                                .then(argument("config", configArgument)
                                        .executes(context -> {
                                            String config = context.getArgument("config", String.class);
                                            nomnom.configManager().deleteConfig(config);
                                            nomnom.chat().sendLogless(class_2561.method_43470("")
                                                    .method_10852(class_2561.method_43470("Config by the name "))
                                                    .method_10852(class_2561.method_43470(config).method_27692(class_124.field_1061))
                                                    .method_10852(class_2561.method_43470(" has been deleted successfully")).method_27692(class_124.field_1067));
                                            return COMPLETED;
                                        }))
                )
                .then(
                        literal("list")
                                .executes(context -> {
                                    var text = new StringBuilder();
                                    var configs = nomnom.configManager().getModuleConfigs();
                                    for (int i = 0; i < configs.size(); i++) {
                                        text.append(configs.get(i));
                                        if (i < configs.size() - 1) {
                                            text.append(", ");
                                        }
                                    }

                                    nomnom.chat().send(class_2561.method_43470("")
                                            .method_10852(class_2561.method_43470("Config list: ").method_27692(class_124.field_1067).method_27692(class_124.field_1075))
                                            .method_10852(class_2561.method_43470(text.toString()).method_27692(class_124.field_1068)));

                                    return COMPLETED;
                                })
                );
    }
}
