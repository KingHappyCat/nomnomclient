
package net.staro.nomnom.command.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_124;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.command.NomnomCommand;

public class ModulesCommand extends NomnomCommand {

    public ModulesCommand(Nomnom nomnom) {
        super(nomnom, "modules", "Shows available modules");
    }

    @Override
    public void build(Nomnom nomnom, LiteralArgumentBuilder<class_2172> builder) {
        builder.executes(context -> {
            nomnom.chat().sendLogless(
                    class_2561.method_30163(class_124.field_1080 + "Modules:")
            );

            nomnom.moduleManager().getCategories().forEach(category ->
                    nomnom.moduleManager().getModulesByCategory(category).forEach(module -> {
                        var moduleText = class_2561.method_43470(
                                (module.isEnabled() ? class_124.field_1075 : class_124.field_1061)
                                        + module.getName()
                                        + class_124.field_1068
                        );

                        nomnom.chat().send(
                                moduleText.method_27694(style ->
                                        style.method_10949(
                                                new class_2568.class_10613(
                                                        class_2561.method_43470(module.getName())
                                                )
                                        )
                                )
                        );
                    })
            );

            return COMPLETED;
        });
    }
}
