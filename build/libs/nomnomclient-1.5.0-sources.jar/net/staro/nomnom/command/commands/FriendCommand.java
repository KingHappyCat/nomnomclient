package net.staro.nomnom.command.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_124;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.command.NomnomCommand;
import net.staro.nomnom.command.arguments.FriendArgument;
import net.staro.nomnom.command.arguments.PlayerArgument;

public class FriendCommand extends NomnomCommand {
    private final PlayerArgument playerArgument;

    public FriendCommand(Nomnom nomnom) {
        super(nomnom, "friend", "Manage friends");
        playerArgument = new PlayerArgument(nomnom.mc());
    }

    @Override
    public void build(Nomnom nomnom, LiteralArgumentBuilder<class_2172> builder) {
        builder.executes(
                context -> {
                    nomnom.chat().send("Please enter the correct sequence: +player <add/del/list/clear> <nickname>");
                    return COMPLETED;
                }).then(
                literal("add")
                        .then(argument("player", playerArgument)
                                .executes(context -> {
                                    var nickname = context.getArgument("player", String.class);
                                    if (!nomnom.friendManager().getFriends().contains(nickname)) {
                                        nomnom.friendManager().addFriend(nickname);
                                        nomnom.chat().send(class_2561.method_43470("")
                                                .method_10852(class_2561.method_43470(nickname).method_27692(class_124.field_1067).method_27692(class_124.field_1075))
                                                .method_10852(class_2561.method_43470(" is a friend now").method_27692(class_124.field_1068)));
                                    } else {
                                        nomnom.chat().send(class_2561.method_43470("")
                                                .method_10852(class_2561.method_43470(nickname).method_27692(class_124.field_1067).method_27692(class_124.field_1075))
                                                .method_10852(class_2561.method_43470(" is already a friend").method_27692(class_124.field_1068)));
                                    }

                                    return COMPLETED;
                                }))
        ).then(
                literal("del")
                        .then(argument("player", new FriendArgument(nomnom))
                                .executes(context -> {
                                    var nickname = context.getArgument("player", String.class);
                                    nomnom.friendManager().removeFriend(nickname);
                                    nomnom.chat().send(class_2561.method_43470("")
                                            .method_10852(class_2561.method_43470(nickname).method_27692(class_124.field_1067).method_27692(class_124.field_1061))
                                            .method_10852(class_2561.method_43470(" is not a friend anymore").method_27692(class_124.field_1068)));
                                    return COMPLETED;
                                }))
        ).then(
                literal("list")
                        .executes(context -> {
                            var friendList = new StringBuilder();
                            var friends = nomnom.friendManager().getFriends();
                            for (int i = 0; i < friends.size(); i++) {
                                friendList.append(friends.get(i));
                                if (i < friends.size() - 1) {
                                    friendList.append(", ");
                                }
                            }

                            nomnom.chat().send(class_2561.method_43470("")
                                    .method_10852(class_2561.method_43470("Friend list: ").method_27692(class_124.field_1067).method_27692(class_124.field_1075))
                                    .method_10852(class_2561.method_43470(friendList.toString()).method_27692(class_124.field_1068)));

                            return COMPLETED;
                        })
        ).then(
                literal("clear")
                        .executes(context -> {
                            nomnom.friendManager().getFriends().clear();
                            return COMPLETED;
                        })
        );
    }

}
