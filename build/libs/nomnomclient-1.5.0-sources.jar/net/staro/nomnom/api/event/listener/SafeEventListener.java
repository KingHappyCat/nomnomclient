package net.staro.nomnom.api.event.listener;

import java.lang.reflect.Method;
import net.minecraft.class_310;
import net.minecraft.class_636;
import net.minecraft.class_638;
import net.minecraft.class_746;

/**
 * An extent of Listener to assert {@code mc.player} and {@code mc.world} != null
 */
public class SafeEventListener extends EventListener {
    private final class_310 mc;

    public SafeEventListener(Object instance, Method method, int priority) {
        super(instance, method, priority);
        this.mc = class_310.method_1551();
    }

    @Override
    public void invoke(Object event) {
        safe(mc, (player, world, interactionManager) -> super.invoke(event));
    }

    private void safe(class_310 mc, PlayerAndWorldConsumer action) {
        safeOr(mc, action, () -> {});
    }

    private void safeOr(class_310 mc, PlayerAndWorldConsumer action, Runnable or) {
        class_638 world = mc.field_1687;
        class_746 player = mc.field_1724;
        class_636 interactionManager = mc.field_1761;
        if (world != null && player != null && interactionManager != null) {
            action.accept(player, world, interactionManager);
        } else {
            or.run();
        }
    }

    @FunctionalInterface
    public interface PlayerAndWorldConsumer {
        /**
         *
         * @param player {@link class_310#field_1724}
         * @param world {@link class_310#field_1687}
         * @param interactionManager {@link class_310#field_1761}
         */
        void accept(class_746 player, class_638 world, class_636 interactionManager);
    }

}
