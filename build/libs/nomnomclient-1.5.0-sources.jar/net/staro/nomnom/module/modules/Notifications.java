package net.staro.nomnom.module.modules;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.api.event.listener.SafeListener;
import net.staro.nomnom.events.client.ToggleEvent;
import net.staro.nomnom.module.Category;
import net.staro.nomnom.module.NomnomModule;

public class Notifications extends NomnomModule {
    public Notifications(Nomnom nomnom) {
        super(nomnom, "Notifications", Category.CLIENT, "Shows selected notifications in chat.");
    }

    @SafeListener
    @SuppressWarnings("unused")
    public void onSettingChanged(ToggleEvent event) {
        var module = event.module();
        String message = event.state() ? " enabled." : " disabled.";
        class_124 formatting = event.state() ? class_124.field_1075 : class_124.field_1061;
        nomnom.chat().sendLogless(class_2561.method_43470("")
                .method_10852(class_2561.method_43470(module.getName()).method_27692(class_124.field_1067))
                .method_10852(class_2561.method_43470(message).method_27692(formatting)), module.getName());
    }

}
