package net.staro.nomnom.module.modules;

import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2848;
import net.minecraft.class_746;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.api.Setting;
import net.staro.nomnom.api.event.listener.Listener;
import net.staro.nomnom.events.tick.UpdateEvent;
import net.staro.nomnom.module.Category;
import net.staro.nomnom.module.NomnomModule;

/**
 * Elytra flight.
 *
 * <p>CONTROL: vanilla elytra physics (gravity, drag, lift) are switched off and you steer
 * directly. Forward/back/strafe move you at Speed, jump goes up and sneak goes down at
 * Vertical Speed, and with no keys held you hover on the spot.
 *
 * <p>BOOST: normal elytra physics, but holding forward pushes you along your look direction
 * towards Speed, the way a firework rocket does, without using any.
 *
 * <p>Auto Takeoff starts gliding as soon as you are falling with an elytra on, so you never
 * have to double jump.
 */
@SuppressWarnings("unused")
public class ElytraFly extends NomnomModule {
    public enum Mode {CONTROL, BOOST}

    /** Handle for MixinLivingEntity, which can't get module instances injected. */
    public static ElytraFly INSTANCE;

    private final Setting<Mode> mode = enumSetting("Mode", Mode.CONTROL);
    private final Setting<Double> speed = precise("Speed", 1.8, 0.5, 6.0);
    private final Setting<Double> verticalSpeed = precise("Vertical Speed", 0.8, 0.1, 3.0);
    private final Setting<Boolean> hover = bool("Hover", true);
    private final Setting<Boolean> lookVertical = bool("Look Vertical", false);
    private final Setting<Boolean> autoTakeoff = bool("Auto Takeoff", true);
    private final Setting<Boolean> antiKinetic = bool("Anti Kinetic", true);

    // Flying into a wall deals (speed lost - ...) * 10 - 3 damage, so a drop of 0.3 blocks per
    // tick or less is harmless. Above that, a collision hurts.
    private static final double KINETIC_SAFE_SPEED = 0.3;

    public ElytraFly(Nomnom nomnom) {
        super(nomnom, "ElytraFly", Category.MOVEMENT, "Controlled elytra flight");
        INSTANCE = this;
    }

    /**
     * True while vanilla elytra physics should be skipped for {@code entity}. Used by the
     * {@code calcGlidingVelocity} hook in MixinLivingEntity.
     */
    public static boolean overridesPhysics(class_1297 entity) {
        ElytraFly module = INSTANCE;
        return module != null
                && module.isEnabled()
                && module.mode.getValue() == Mode.CONTROL
                && entity == module.mc.field_1724
                && module.mc.field_1724.method_6128();
    }

    @Listener
    public void onUpdate(UpdateEvent event) {
        class_746 player = event.getPlayer();

        if (!player.method_6128()) {
            takeOff(player);
            return;
        }

        if (mode.getValue() == Mode.CONTROL) {
            control(player);
        } else {
            boost(player);
        }

        if (antiKinetic.getValue()) {
            preventImpact(player);
        }
    }

    /**
     * Looks one tick ahead. If the move we are about to make would run into a wall fast enough
     * to hurt, it is shortened to the largest move that doesn't touch anything, so you stop
     * right at the wall instead of hitting it.
     */
    private void preventImpact(class_746 player) {
        class_243 velocity = player.method_18798();

        if (Math.hypot(velocity.field_1352, velocity.field_1350) <= KINETIC_SAFE_SPEED) {
            return;
        }

        class_238 box = player.method_5829();

        if (mc.field_1687.method_8587(player, box.method_1012(velocity.field_1352, 0.0, velocity.field_1350))) {
            return;
        }

        // Binary search for the longest fraction of the move that stays clear.
        double clear = 0.0;
        double blocked = 1.0;

        for (int i = 0; i < 8; i++) {
            double middle = (clear + blocked) / 2.0;

            if (mc.field_1687.method_8587(player, box.method_1012(velocity.field_1352 * middle, 0.0, velocity.field_1350 * middle))) {
                clear = middle;
            } else {
                blocked = middle;
            }
        }

        // BOOST still gets vanilla physics applied on top, which can add a little speed, so
        // keep a bit of distance there. CONTROL moves exactly the velocity we set.
        if (mode.getValue() == Mode.BOOST) {
            clear *= 0.9;
        }

        player.method_18800(velocity.field_1352 * clear, velocity.field_1351, velocity.field_1350 * clear);
    }

    private void takeOff(class_746 player) {
        if (!autoTakeoff.getValue()
                || player.method_24828()
                || player.method_18798().field_1351 >= 0.0
                || !class_1309.method_63624(player.method_6118(class_1304.field_6174), class_1304.field_6174)) {
            return;
        }

        // Same thing vanilla does when you press jump in the air: start gliding on the client
        // and tell the server.
        if (player.method_23668()) {
            player.field_3944.method_52787(
                    new class_2848(player, class_2848.class_2849.field_12982));
        }
    }

    private void control(class_746 player) {
        double forward = (mc.field_1690.field_1894.method_1434() ? 1 : 0) - (mc.field_1690.field_1881.method_1434() ? 1 : 0);
        double strafe = (mc.field_1690.field_1913.method_1434() ? 1 : 0) - (mc.field_1690.field_1849.method_1434() ? 1 : 0);

        double x = 0.0;
        double y = player.method_18798().field_1351;
        double z = 0.0;

        if (forward != 0 || strafe != 0) {
            double length = Math.hypot(forward, strafe);
            forward /= length;
            strafe /= length;

            double yaw = Math.toRadians(player.method_36454());
            double flat = speed.getValue();

            if (lookVertical.getValue() && forward != 0) {
                // Move along the full look direction, pitch included.
                double pitch = Math.toRadians(player.method_36455());
                double cos = Math.cos(pitch);
                y = -Math.sin(pitch) * flat * forward;
                flat *= cos;
            } else if (hover.getValue()) {
                y = 0.0;
            }

            x = (-Math.sin(yaw) * forward + Math.cos(yaw) * strafe) * flat;
            z = (Math.cos(yaw) * forward + Math.sin(yaw) * strafe) * flat;
        } else if (hover.getValue()) {
            y = 0.0;
        }

        boolean up = mc.field_1690.field_1903.method_1434();
        boolean down = mc.field_1690.field_1832.method_1434();

        if (up && !down) {
            y = verticalSpeed.getValue();
        } else if (down && !up) {
            y = -verticalSpeed.getValue();
        }

        player.method_18800(x, y, z);
    }

    private void boost(class_746 player) {
        if (!mc.field_1690.field_1894.method_1434()) {
            return;
        }

        // The same acceleration a firework rocket applies, with Speed as the target speed.
        class_243 look = player.method_5720();
        class_243 velocity = player.method_18798();
        double target = speed.getValue();

        player.method_18799(velocity.method_1031(
                look.field_1352 * 0.1 + (look.field_1352 * target - velocity.field_1352) * 0.5,
                look.field_1351 * 0.1 + (look.field_1351 * target - velocity.field_1351) * 0.5,
                look.field_1350 * 0.1 + (look.field_1350 * target - velocity.field_1350) * 0.5
        ));
    }
}