package net.staro.nomnom.module.modules;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.api.Setting;
import net.staro.nomnom.api.event.listener.Listener;
import net.staro.nomnom.events.render.Render2DEvent;
import net.staro.nomnom.module.Category;
import net.staro.nomnom.module.NomnomModule;
import net.staro.nomnom.utility.EspUtil;
import net.staro.nomnom.utility.ProjectionUtil;

/** Draws a 2D box around entities, visible through walls. Friends are cyan. */
@SuppressWarnings("unused")
public class ESP extends NomnomModule {
    private final Setting<Boolean> players = bool("Players", true);
    private final Setting<Boolean> hostiles = bool("Hostiles", true);
    private final Setting<Boolean> passives = bool("Passives", false);
    private final Setting<Boolean> fill = bool("Fill", true);
    private final Setting<Integer> range = integer("Range", 128, 8, 256);

    public ESP(Nomnom nomnom) {
        super(nomnom, "ESP", Category.RENDER, "Boxes around entities");
    }

    @Listener
    public void onRender(Render2DEvent event) {
        if (mc.field_1687 == null || mc.field_1724 == null) {
            return;
        }
        var ctx = event.getContext();
        float tickProgress = event.getTickProgress();

        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (entity == mc.field_1724 || !(entity instanceof class_1309) || !entity.method_5805()) continue;
            if (!EspUtil.wanted(entity, players.getValue(), hostiles.getValue(), passives.getValue())) continue;
            if (mc.field_1724.method_5739(entity) > range.getValue()) continue;

            class_243 pos = entity.method_30950(tickProgress);
            double halfWidth = entity.method_17681() / 2.0;
            double height = entity.method_17682();

            double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE;
            double maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
            boolean visible = true;

            for (int i = 0; i < 8 && visible; i++) {
                double dx = (i & 1) == 0 ? -halfWidth : halfWidth;
                double dy = (i & 2) == 0 ? 0 : height;
                double dz = (i & 4) == 0 ? -halfWidth : halfWidth;
                class_243 screen = ProjectionUtil.toScreen(mc, pos.method_1031(dx, dy, dz), tickProgress);
                if (screen == null) {
                    visible = false;
                    break;
                }
                minX = Math.min(minX, screen.field_1352);
                minY = Math.min(minY, screen.field_1351);
                maxX = Math.max(maxX, screen.field_1352);
                maxY = Math.max(maxY, screen.field_1351);
            }
            if (!visible) continue;

            int color = EspUtil.color(nomnom, entity);
            int x1 = (int) minX, y1 = (int) minY, x2 = (int) maxX, y2 = (int) maxY;
            if (fill.getValue()) {
                ctx.fill(x1, y1, x2, y2, (color & 0x00FFFFFF) | 0x30000000);
            }
            EspUtil.outline(ctx, x1, y1, x2, y2, color);
        }
    }
}
