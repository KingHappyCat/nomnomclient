package net.staro.nomnom.module.modules;

import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.api.Setting;
import net.staro.nomnom.api.event.listener.Listener;
import net.staro.nomnom.events.tick.TickEvent;
import net.staro.nomnom.module.Category;
import net.staro.nomnom.module.NomnomModule;

/**
 * Keeps a totem of undying in your offhand.
 * Health 20 = always keep one equipped; lower it to only swap when you are low.
 */
@SuppressWarnings("unused")
public class AutoTotem extends NomnomModule {
    private final Setting<Float> health = floating("Health", 20f, 1f, 20f);
    private final Setting<Integer> delay = integer("Delay", 1, 0, 10);

    private int timer;

    public AutoTotem(Nomnom nomnom) {
        super(nomnom, "AutoTotem", Category.COMBAT, "Keeps a totem in your offhand");
    }

    @Override
    protected void onEnable() {
        timer = 0;
    }

    @Listener
    public void onTick(TickEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) {
            return;
        }
        if (timer > 0) {
            timer--;
            return;
        }
        if (mc.field_1724.method_6079().method_31574(class_1802.field_8288)) {
            return;
        }
        if (mc.field_1724.method_6032() + mc.field_1724.method_6067() > health.getValue()) {
            return;
        }

        int slot = findTotemSlot();
        if (slot == -1) {
            return;
        }

        // Button 40 on a SWAP click means "swap with the offhand".
        mc.field_1761.method_2906(
                mc.field_1724.field_7498.field_7763,
                slot,
                40,
                class_1713.field_7791,
                mc.field_1724);
        timer = delay.getValue();
    }

    /** Returns a slot id of the player screen handler (main inventory 9-35, hotbar 36-44). */
    private int findTotemSlot() {
        var inventory = mc.field_1724.method_31548();
        for (int i = 9; i < 36; i++) {
            if (inventory.method_5438(i).method_31574(class_1802.field_8288)) {
                return i;
            }
        }
        for (int i = 0; i < 9; i++) {
            if (inventory.method_5438(i).method_31574(class_1802.field_8288)) {
                return 36 + i;
            }
        }
        return -1;
    }
}
