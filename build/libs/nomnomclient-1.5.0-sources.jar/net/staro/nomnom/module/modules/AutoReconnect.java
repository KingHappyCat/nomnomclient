package net.staro.nomnom.module.modules;

import net.minecraft.class_412;
import net.minecraft.class_419;
import net.minecraft.class_442;
import net.minecraft.class_500;
import net.minecraft.class_639;
import net.minecraft.class_642;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.api.Setting;
import net.staro.nomnom.api.event.listener.Listener;
import net.staro.nomnom.events.tick.TickEvent;
import net.staro.nomnom.module.Category;
import net.staro.nomnom.module.NomnomModule;

/** Rejoins the last server a few seconds after you get kicked or disconnected. */
@SuppressWarnings("unused")
public class AutoReconnect extends NomnomModule {
    private final Setting<Integer> delay = integer("Delay", 5, 1, 60);

    private class_642 lastServer;
    private int countdown = -1;

    public AutoReconnect(Nomnom nomnom) {
        super(nomnom, "AutoReconnect", Category.MISC, "Reconnects after a disconnect");
    }

    @Override
    protected void onEnable() {
        countdown = -1;
    }

    @Listener
    public void onTick(TickEvent event) {
        class_642 current = mc.method_1558();
        if (current != null && mc.field_1687 != null) {
            lastServer = current; // remember where we are, for when we get kicked
            countdown = -1;
            return;
        }

        if (!(mc.field_1755 instanceof class_419) || lastServer == null) {
            countdown = -1;
            return;
        }

        if (countdown < 0) {
            countdown = delay.getValue() * 20;
        }
        if (--countdown <= 0) {
            countdown = -1;
            class_412.method_36877(
                    new class_500(new class_442()),
                    mc,
                    class_639.method_2950(lastServer.field_3761),
                    lastServer,
                    false,
                    null);
        }
    }
}
