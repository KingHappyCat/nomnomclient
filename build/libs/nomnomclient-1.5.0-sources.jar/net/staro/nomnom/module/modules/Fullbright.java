package net.staro.nomnom.module.modules;

import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_310;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.module.Category;
import net.staro.nomnom.module.NomnomModule;

public class Fullbright extends NomnomModule {
    public Fullbright(Nomnom nomnom) {
        super(nomnom, "Fullbright", Category.RENDER, "Makes the world bright.");
    }

    @Override
    public void onEnable() {
        var player = class_310.method_1551().field_1724;
        if (player != null) {
            player.method_6092(new class_1293(
                    class_1294.field_5925, class_1293.field_42106, 0, false, false, false));
        }
    }

    @Override
    public void onDisable() {
        var player = class_310.method_1551().field_1724;
        if (player != null) {
            player.method_6016(class_1294.field_5925);
        }
    }
}