package net.staro.nomnom.module.modules;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.api.Module;
import net.staro.nomnom.api.Setting;
import net.staro.nomnom.api.event.listener.Listener;
import net.staro.nomnom.events.render.Render2DEvent;
import net.staro.nomnom.module.Category;
import net.staro.nomnom.module.NomnomModule;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * On-screen info.
 *
 * <ul>
 *   <li>Watermark: client name and version, top left.</li>
 *   <li>Module List: enabled modules, longest name first, top right.</li>
 *   <li>Info: coordinates (with the Nether / Overworld conversion), speed, ping, FPS and
 *       how many totems and crystals you carry, bottom right.</li>
 * </ul>
 */
@SuppressWarnings("unused")
public class HUD extends NomnomModule {
    private static final int WHITE = 0xFFFFFFFF;
    private static final int GREY = 0xFFAAAAAA;
    private static final int MARGIN = 2;

    private final Setting<Boolean> watermark = bool("Watermark", true);
    private final Setting<Boolean> moduleList = bool("Module List", true);
    private final Setting<Boolean> hideRender = bool("Hide Render Modules", true);
    private final Setting<Boolean> coordinates = bool("Coordinates", true);
    private final Setting<Boolean> speed = bool("Speed", true);
    private final Setting<Boolean> ping = bool("Ping", true);
    private final Setting<Boolean> fps = bool("FPS", true);
    private final Setting<Boolean> counters = bool("Totems and Crystals", true);
    private final Setting<Boolean> rainbow = bool("Rainbow", true);

    private final String version;

    public HUD(Nomnom nomnom) {
        super(nomnom, "HUD", Category.CLIENT, "On-screen info: watermark, module list and stats");

        this.version = FabricLoader.getInstance()
                .getModContainer("nomnomclient")
                .map(container -> container.getMetadata().getVersion().getFriendlyString())
                .orElse("");
    }

    @Listener
    public void onRender(Render2DEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1690.field_1842) {
            return;
        }

        class_332 context = event.getContext();
        class_327 font = mc.field_1772;
        int width = mc.method_22683().method_4486();
        int height = mc.method_22683().method_4502();

        if (watermark.getValue()) {
            String text = version.isEmpty() ? "nomnomclient" : "nomnomclient " + version;
            context.method_25303(font, text, MARGIN, MARGIN, accent(0));
        }

        if (moduleList.getValue()) {
            drawModuleList(context, font, width);
        }

        drawInfo(context, font, width, height);
    }

    private void drawModuleList(class_332 context, class_327 font, int width) {
        List<String> names = new ArrayList<>();

        for (Module module : nomnom.moduleManager().getEnabledModules()) {
            if (module == this) {
                continue;
            }
            if (hideRender.getValue() && module.getCategory() == Category.RENDER) {
                continue;
            }
            names.add(module.getName());
        }

        names.sort(Comparator.comparingInt((String name) -> font.method_1727(name)).reversed());

        int y = MARGIN;
        for (int i = 0; i < names.size(); i++) {
            String name = names.get(i);
            context.method_25303(font, name, width - font.method_1727(name) - MARGIN, y, accent(i));
            y += font.field_2000 + 1;
        }
    }

    private void drawInfo(class_332 context, class_327 font, int width, int height) {
        List<String> lines = new ArrayList<>();

        if (coordinates.getValue()) {
            double x = mc.field_1724.method_23317();
            double y = mc.field_1724.method_23318();
            double z = mc.field_1724.method_23321();

            String xyz = String.format("XYZ %.1f %.1f %.1f", x, y, z);

            // Overworld coordinates divide by 8 in the Nether and the other way round.
            if (mc.field_1687.method_27983() == class_1937.field_25179) {
                xyz += String.format(" (%.1f, %.1f)", x / 8.0, z / 8.0);
            } else if (mc.field_1687.method_27983() == class_1937.field_25180) {
                xyz += String.format(" (%.1f, %.1f)", x * 8.0, z * 8.0);
            }

            lines.add(xyz);
        }

        if (speed.getValue()) {
            var velocity = mc.field_1724.method_18798();
            lines.add(String.format("Speed %.1f b/s", Math.hypot(velocity.field_1352, velocity.field_1350) * 20.0));
        }

        if (ping.getValue()) {
            lines.add("Ping " + pingMillis() + " ms");
        }

        if (fps.getValue()) {
            lines.add("FPS " + mc.method_47599());
        }

        if (counters.getValue()) {
            lines.add("Totems " + count(class_1802.field_8288) + "  Crystals " + count(class_1802.field_8301));
        }

        int y = height - MARGIN - font.field_2000;
        for (int i = lines.size() - 1; i >= 0; i--) {
            String line = lines.get(i);
            context.method_25303(font, line, width - font.method_1727(line) - MARGIN, y, i == 0 && coordinates.getValue() ? WHITE : GREY);
            y -= font.field_2000 + 1;
        }
    }

    private int pingMillis() {
        if (mc.method_1562() == null) {
            return 0;
        }

        var entry = mc.method_1562().method_2871(mc.field_1724.method_5667());
        return entry == null ? 0 : entry.method_2959();
    }

    /** How many of {@code item} you carry in your inventory and offhand. */
    private int count(class_1792 item) {
        int total = 0;

        for (int slot = 0; slot < 36; slot++) {
            var stack = mc.field_1724.method_31548().method_5438(slot);

            if (stack.method_31574(item)) {
                total += stack.method_7947();
            }
        }

        var offhand = mc.field_1724.method_6079();
        if (offhand.method_31574(item)) {
            total += offhand.method_7947();
        }

        return total;
    }

    /** Rainbow colour that shifts over time (and per line), or white when Rainbow is off. */
    private int accent(int index) {
        if (!rainbow.getValue()) {
            return WHITE;
        }

        float hue = ((System.currentTimeMillis() / 20L + index * 12L) % 360L) / 360.0f;
        return 0xFF000000 | class_3532.method_15369(hue, 0.6f, 1.0f);
    }
}