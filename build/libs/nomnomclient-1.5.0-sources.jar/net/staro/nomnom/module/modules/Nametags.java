package net.staro.nomnom.module.modules;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.api.Setting;
import net.staro.nomnom.api.event.listener.Listener;
import net.staro.nomnom.events.render.Render2DEvent;
import net.staro.nomnom.module.Category;
import net.staro.nomnom.module.NomnomModule;
import net.staro.nomnom.utility.EspUtil;
import net.staro.nomnom.utility.ProjectionUtil;

/**
 * Name, health and distance above entities, visible through walls.
 * Note: vanilla nametags are still drawn too; they can be hidden with a mixin later.
 */
@SuppressWarnings("unused")
public class Nametags extends NomnomModule {
    private final Setting<Boolean> players = bool("Players", true);
    private final Setting<Boolean> hostiles = bool("Hostiles", false);
    private final Setting<Boolean> passives = bool("Passives", false);
    private final Setting<Boolean> health = bool("Health", true);
    private final Setting<Boolean> distance = bool("Distance", true);
    private final Setting<Integer> range = integer("Range", 128, 8, 256);

    public Nametags(Nomnom nomnom) {
        super(nomnom, "Nametags", Category.RENDER, "Name, health and distance above entities");
    }

    @Listener
    public void onRender(Render2DEvent event) {
        if (mc.field_1687 == null || mc.field_1724 == null) {
            return;
        }
        var ctx = event.getContext();
        float tickProgress = event.getTickProgress();
        var font = mc.field_1772;

        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (entity == mc.field_1724 || !(entity instanceof class_1309 living) || !entity.method_5805()) continue;
            if (!EspUtil.wanted(entity, players.getValue(), hostiles.getValue(), passives.getValue())) continue;
            if (mc.field_1724.method_5739(entity) > range.getValue()) continue;

            class_243 head = entity.method_30950(tickProgress).method_1031(0, entity.method_17682() + 0.35, 0);
            class_243 screen = ProjectionUtil.toScreen(mc, head, tickProgress);
            if (screen == null) continue;

            String name = entity.method_5477().getString();
            String hp = "";
            if (health.getValue()) {
                hp = String.format(" %.1f", living.method_6032() + living.method_6067());
            }
            String dist = distance.getValue() ? String.format(" %dm", (int) mc.field_1724.method_5739(entity)) : "";

            int nameWidth = font.method_1727(name);
            int hpWidth = font.method_1727(hp);
            int distWidth = font.method_1727(dist);
            int total = nameWidth + hpWidth + distWidth;
            int x = (int) screen.field_1352 - total / 2;
            int y = (int) screen.field_1351 - font.field_2000;

            ctx.fill(x - 2, y - 1, x + total + 2, y + font.field_2000, 0x90000000);
            ctx.drawTextWithShadow(font, name, x, y, EspUtil.color(nomnom, entity));
            if (!hp.isEmpty()) {
                float fraction = Math.max(0f, Math.min(1f, (living.method_6032() + living.method_6067()) / living.method_6063()));
                int red = (int) (255 * (1 - fraction));
                int green = (int) (255 * fraction);
                ctx.drawTextWithShadow(font, hp, x + nameWidth, y, 0xFF000000 | (red << 16) | (green << 8) | 0x40);
            }
            if (!dist.isEmpty()) {
                ctx.drawTextWithShadow(font, dist, x + nameWidth + hpWidth, y, 0xFFAAAAAA);
            }
        }
    }
}
