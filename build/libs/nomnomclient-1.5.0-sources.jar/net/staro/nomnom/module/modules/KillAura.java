package net.staro.nomnom.module.modules;

import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_746;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.api.Setting;
import net.staro.nomnom.api.event.listener.Listener;
import net.staro.nomnom.events.tick.UpdateEvent;
import net.staro.nomnom.module.Category;
import net.staro.nomnom.module.NomnomModule;
import net.staro.nomnom.utility.EspUtil;

/** Attacks the closest valid target in range. Friends are never targeted. */
@SuppressWarnings("unused")
public class KillAura extends NomnomModule {
    private final Setting<Double> range = precise("Range", 3.8, 1.0, 6.0);
    private final Setting<Boolean> players = bool("Players", true);
    private final Setting<Boolean> hostiles = bool("Hostiles", true);
    private final Setting<Boolean> passives = bool("Passives", false);
    private final Setting<Boolean> rotate = bool("Rotate", true);
    private final Setting<Boolean> cooldown = bool("Cooldown", true);

    public KillAura(Nomnom nomnom) {
        super(nomnom, "KillAura", Category.COMBAT, "Attacks nearby entities");
    }

    @Listener
    public void onUpdate(UpdateEvent event) {
        class_746 player = event.getPlayer();
        if (mc.field_1687 == null || mc.field_1761 == null) {
            return;
        }

        class_1309 target = findTarget(player);
        if (target == null) {
            return;
        }

        if (rotate.getValue()) {
            face(player, target);
        }
        if (cooldown.getValue() && player.method_7261(0.5f) < 1.0f) {
            return;
        }

        mc.field_1761.method_2918(player, target);
        player.method_6104(class_1268.field_5808);
    }

    private class_1309 findTarget(class_746 player) {
        class_1309 best = null;
        double bestDistance = Double.MAX_VALUE;

        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (!(entity instanceof class_1309 living) || entity == player || !living.method_5805()
                    || living.method_7325()) {
                continue;
            }
            if (!EspUtil.wanted(entity, players.getValue(), hostiles.getValue(), passives.getValue())) {
                continue;
            }
            if (entity instanceof class_1657 other && nomnom.friendManager().isFriend(other)) {
                continue;
            }
            double distance = player.method_5739(entity);
            if (distance <= range.getValue() && distance < bestDistance) {
                best = living;
                bestDistance = distance;
            }
        }
        return best;
    }

    private void face(class_746 player, class_1309 target) {
        class_243 from = player.method_33571();
        class_243 to = target.method_5829().method_1005();
        double dx = to.field_1352 - from.field_1352;
        double dy = to.field_1351 - from.field_1351;
        double dz = to.field_1350 - from.field_1350;
        double horizontal = Math.hypot(dx, dz);

        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal));
        player.method_36456(class_3532.method_15393(yaw));
        player.method_36457(class_3532.method_15363(pitch, -90.0f, 90.0f));
    }
}
