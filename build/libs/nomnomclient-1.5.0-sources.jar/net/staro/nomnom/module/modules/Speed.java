package net.staro.nomnom.module.modules;

import net.minecraft.class_1294;
import net.minecraft.class_746;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.api.Setting;
import net.staro.nomnom.api.event.listener.Listener;
import net.staro.nomnom.events.tick.UpdateEvent;
import net.staro.nomnom.module.Category;
import net.staro.nomnom.module.NomnomModule;

/**
 * Horizontal speed.
 * STRAFE: sets your horizontal velocity to (sprint speed * Speed) in the direction you are pressing.
 * BHOP:   same, but also auto-jumps while you are moving.
 */
@SuppressWarnings("unused")
public class Speed extends NomnomModule {
    public enum Mode {STRAFE, BHOP}

    private static final double BASE_SPEED = 0.2873; // vanilla sprint speed, blocks per tick

    private final Setting<Mode> mode = enumSetting("Mode", Mode.STRAFE);
    private final Setting<Float> speed = floating("Speed", 1.5f, 1.0f, 5.0f);
    private final Setting<Boolean> groundCheck = bool("Ground Check", true);

    public Speed(Nomnom nomnom) {
        super(nomnom, "Speed", Category.MOVEMENT, "Configurable movement speed");
    }

    @Listener
    public void onUpdate(UpdateEvent event) {
        class_746 player = event.getPlayer();
        if (player.method_6128() || player.method_5799() || player.method_5771()
                || player.method_6101() || player.method_31549().field_7479) {
            return;
        }

        double forward = (mc.field_1690.field_1894.method_1434() ? 1 : 0) - (mc.field_1690.field_1881.method_1434() ? 1 : 0);
        double strafe = (mc.field_1690.field_1913.method_1434() ? 1 : 0) - (mc.field_1690.field_1849.method_1434() ? 1 : 0);
        if (forward == 0 && strafe == 0) {
            return;
        }

        boolean onGround = player.method_24828();
        if (mode.getValue() == Mode.BHOP) {
            if (onGround) player.method_6043();
        } else if (groundCheck.getValue() && !onGround) {
            return; // STRAFE with Ground Check only boosts while on the ground
        }

        double base = BASE_SPEED;
        var effect = player.method_6112(class_1294.field_5904);
        if (effect != null) {
            base *= 1.0 + 0.2 * (effect.method_5578() + 1);
        }
        double velocity = base * speed.getValue();

        double length = Math.hypot(forward, strafe);
        forward /= length;
        strafe /= length;

        double yaw = Math.toRadians(player.method_36454());
        double x = (-Math.sin(yaw) * forward + Math.cos(yaw) * strafe) * velocity;
        double z = (Math.cos(yaw) * forward + Math.sin(yaw) * strafe) * velocity;
        player.method_18800(x, player.method_18798().field_1351, z);
    }
}
