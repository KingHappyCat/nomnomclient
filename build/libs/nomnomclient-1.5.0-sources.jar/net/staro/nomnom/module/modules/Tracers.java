package net.staro.nomnom.module.modules;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.api.Setting;
import net.staro.nomnom.api.event.listener.Listener;
import net.staro.nomnom.events.render.Render2DEvent;
import net.staro.nomnom.module.Category;
import net.staro.nomnom.module.NomnomModule;
import net.staro.nomnom.utility.EspUtil;
import net.staro.nomnom.utility.ProjectionUtil;

/** Draws a line from the bottom centre of your screen to entities. Friends are cyan. */
@SuppressWarnings("unused")
public class Tracers extends NomnomModule {
    private final Setting<Boolean> players = bool("Players", true);
    private final Setting<Boolean> hostiles = bool("Hostiles", false);
    private final Setting<Boolean> passives = bool("Passives", false);
    private final Setting<Integer> range = integer("Range", 128, 8, 256);

    public Tracers(Nomnom nomnom) {
        super(nomnom, "Tracers", Category.RENDER, "Lines pointing to entities");
    }

    @Listener
    public void onRender(Render2DEvent event) {
        if (mc.field_1687 == null || mc.field_1724 == null) {
            return;
        }
        var ctx = event.getContext();
        float tickProgress = event.getTickProgress();
        int width = mc.method_22683().method_4486();
        int height = mc.method_22683().method_4502();

        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (entity == mc.field_1724 || !(entity instanceof class_1309) || !entity.method_5805()) continue;
            if (!EspUtil.wanted(entity, players.getValue(), hostiles.getValue(), passives.getValue())) continue;
            if (mc.field_1724.method_5739(entity) > range.getValue()) continue;

            class_243 centre = entity.method_30950(tickProgress).method_1031(0, entity.method_17682() / 2.0, 0);
            class_243 screen = ProjectionUtil.toScreen(mc, centre, tickProgress);
            if (screen == null) continue;

            EspUtil.line(ctx, width / 2, height, (int) screen.field_1352, (int) screen.field_1351,
                    EspUtil.color(nomnom, entity), width, height);
        }
    }
}
