package net.staro.nomnom.module.modules;

import net.minecraft.class_2828;
import net.minecraft.class_746;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.api.Setting;
import net.staro.nomnom.api.event.listener.Listener;
import net.staro.nomnom.events.tick.UpdateEvent;
import net.staro.nomnom.module.Category;
import net.staro.nomnom.module.NomnomModule;

/**
 * Tells the server you are on the ground once you have fallen far enough,
 * which makes it reset your fall damage.
 */
@SuppressWarnings("unused")
public class NoFall extends NomnomModule {
    private final Setting<Double> distance = precise("Distance", 2.5, 1.0, 10.0);

    public NoFall(Nomnom nomnom) {
        super(nomnom, "NoFall", Category.MOVEMENT, "Prevents fall damage");
    }

    @Listener
    public void onUpdate(UpdateEvent event) {
        class_746 player = event.getPlayer();
        if (mc.method_1562() == null
                || player.method_6128()
                || player.method_24828()
                || player.method_31549().field_7478) {
            return;
        }

        if (player.field_6017 > distance.getValue()) {
            mc.method_1562().method_52787(
                    new class_2828.class_5911(true, player.field_5976));
            player.field_6017 = 0;
        }
    }
}
