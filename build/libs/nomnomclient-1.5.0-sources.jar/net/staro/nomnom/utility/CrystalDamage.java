package net.staro.nomnom.utility;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_5134;
import net.minecraft.class_7924;

/**
 * End crystal damage, following the vanilla explosion formula: distance falloff, exposure,
 * difficulty, armor, resistance and enchantment protection. Absorption is ignored.
 *
 * <p>Exposure needs about 45 raycasts per call, so results are cached for a few ticks. A
 * target that stands still (common while crystalling) then costs almost nothing after the
 * first tick. Client tick thread only.
 */
public class CrystalDamage {
    private static final double CRYSTAL_POWER = 6.0;
    private static final int CACHE_TICKS = 5;
    private static final int MAX_CACHE_ENTRIES = 4096;
    private static final class_1304[] ARMOR_SLOTS = {
            class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166
    };

    private record ExposureKey(double cx, double cy, double cz, double tx, double ty, double tz) {
    }

    private final class_310 mc;
    private final Map<ExposureKey, Float> exposureCache = new HashMap<>();
    private long cacheStartTick = -1;
    private int cacheTargetId = -1;
    private double protectionReduction;

    public CrystalDamage(class_310 mc) {
        this.mc = mc;
    }

    /** Call once per tick before asking for damage values for {@code target}. */
    public void update(long tick, class_1309 target, boolean readEnchants, int assumedProtection) {
        if (target.method_5628() != cacheTargetId
                || tick - cacheStartTick >= CACHE_TICKS
                || exposureCache.size() > MAX_CACHE_ENTRIES) {
            exposureCache.clear();
            cacheStartTick = tick;
            cacheTargetId = target.method_5628();
        }

        protectionReduction = protectionReductionOf(target, readEnchants, assumedProtection);
    }

    public void reset() {
        exposureCache.clear();
        cacheTargetId = -1;
        cacheStartTick = -1;
    }

    /**
     * Damage a crystal exploding at {@code centre} deals to {@code target} standing at
     * {@code targetPos}.
     */
    public double damage(class_1309 target, class_243 targetPos, class_243 centre) {
        double diameter = CRYSTAL_POWER * 2.0;
        double distance = targetPos.method_1022(centre) / diameter;

        if (distance > 1.0) {
            return 0.0;
        }

        ExposureKey key = new ExposureKey(
                centre.field_1352, centre.field_1351, centre.field_1350, targetPos.field_1352, targetPos.field_1351, targetPos.field_1350);
        float exposure = exposureCache.computeIfAbsent(key, k -> exposure(centre, target, targetPos));

        double impact = (1.0 - distance) * exposure;
        double damage = (int) ((impact * impact + impact) / 2.0 * 7.0 * diameter + 1.0);

        if (target instanceof class_1657) {
            damage = switch (mc.field_1687.method_8407()) {
                case field_5801 -> 0.0;
                case field_5805 -> Math.min(damage / 2.0 + 1.0, damage);
                case field_5802 -> damage;
                case field_5807 -> damage * 1.5;
            };
        }

        // Armor and toughness.
        double armor = target.method_45325(class_5134.field_23724);
        double toughness = target.method_45325(class_5134.field_23725);
        double reduction = class_3532.method_15350(
                armor - damage / (2.0 + toughness / 4.0),
                armor * 0.2,
                20.0
        );
        damage *= 1.0 - reduction / 25.0;

        // Resistance effect.
        class_1293 resistance = target.method_6112(class_1294.field_5907);
        if (resistance != null) {
            damage *= Math.max(0, 25 - (resistance.method_5578() + 1) * 5) / 25.0;
        }

        // Enchantment protection (computed once per tick for the target).
        damage *= 1.0 - protectionReduction;

        return Math.max(0.0, damage);
    }

    /**
     * Fraction (0..1) of the damage removed by the target's Protection / Blast Protection.
     * Protection counts 1 per level and Blast Protection 2 per level, capped at 20 points.
     */
    private double protectionReductionOf(class_1309 target, boolean readEnchants, int assumed) {
        if (!(target instanceof class_1657)) {
            return 0.0;
        }

        if (readEnchants) {
            try {
                var registry = mc.field_1687.method_30349().method_30530(class_7924.field_41265);
                var protection = registry.method_46747(class_1893.field_9111);
                var blastProtection = registry.method_46747(class_1893.field_9107);

                int points = 0;
                for (class_1304 slot : ARMOR_SLOTS) {
                    class_1799 stack = target.method_6118(slot);

                    if (stack.method_7960()) {
                        continue;
                    }

                    points += class_1890.method_8225(protection, stack);
                    points += 2 * class_1890.method_8225(blastProtection, stack);
                }

                return Math.min(20, points) / 25.0;
            } catch (RuntimeException ignored) {
                // Fall through to the assumed value.
            }
        }

        return Math.min(20, assumed) / 25.0;
    }

    /** Fraction of sample points on the target's hitbox that the explosion can reach. */
    private float exposure(class_243 source, class_1297 entity, class_243 entityPos) {
        class_238 box = entity.method_5829().method_997(entityPos.method_1020(positionOf(entity)));

        double stepX = 1.0 / ((box.field_1320 - box.field_1323) * 2.0 + 1.0);
        double stepY = 1.0 / ((box.field_1325 - box.field_1322) * 2.0 + 1.0);
        double stepZ = 1.0 / ((box.field_1324 - box.field_1321) * 2.0 + 1.0);

        if (stepX < 0.0 || stepY < 0.0 || stepZ < 0.0) {
            return 0.0f;
        }

        double offsetX = (1.0 - Math.floor(1.0 / stepX) * stepX) / 2.0;
        double offsetZ = (1.0 - Math.floor(1.0 / stepZ) * stepZ) / 2.0;

        int reached = 0;
        int total = 0;

        for (double x = 0.0; x <= 1.0; x += stepX) {
            for (double y = 0.0; y <= 1.0; y += stepY) {
                for (double z = 0.0; z <= 1.0; z += stepZ) {
                    class_243 point = new class_243(
                            class_3532.method_16436(x, box.field_1323, box.field_1320) + offsetX,
                            class_3532.method_16436(y, box.field_1322, box.field_1325),
                            class_3532.method_16436(z, box.field_1321, box.field_1324) + offsetZ
                    );

                    class_239 hit = mc.field_1687.method_17742(new class_3959(
                            point,
                            source,
                            class_3959.class_3960.field_17558,
                            class_3959.class_242.field_1348,
                            entity
                    ));

                    if (hit.method_17783() == class_239.class_240.field_1333) {
                        reached++;
                    }

                    total++;
                }
            }
        }

        return total == 0 ? 0.0f : (float) reached / total;
    }

    public static class_243 positionOf(class_1297 entity) {
        return new class_243(entity.method_23317(), entity.method_23318(), entity.method_23321());
    }
}