package net.staro.nomnom.utility;

import java.util.HashMap;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.function.Consumer;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1802;
import net.minecraft.class_2596;
import net.minecraft.class_2663;
import net.minecraft.class_2744;
import net.minecraft.class_310;

/**
 * Tracks totem pops of nearby players for the double pop timing.
 *
 * <p>After a pop the server ignores any damage that doesn't beat the player's last hit for
 * about 10 ticks, so breaking crystals early is wasted. {@link #holding} tells the caller to
 * wait, and the wait shrinks by the ping so the hit lands right as the window ends. It also
 * measures how long each player takes to put a new totem in their offhand.
 *
 * <p>{@link #onPacket} may be called from the network thread, everything else from the
 * client tick.
 */
public class PopTracker {
    private static final int TOTEM_POP_STATUS = 35;
    private static final double TRACK_RANGE = 12.0;
    private static final long FORGET_NANOS = 5_000_000_000L;
    private static final int MAX_PENDING = 512;

    private record Received(class_2596<?> packet, long nanos) {
    }

    private final class_310 mc;

    // Filled on the network thread, drained on the client tick.
    private final Queue<Received> pending = new ConcurrentLinkedQueue<>();
    // Client tick thread only.
    private final Map<Integer, Long> popNanos = new HashMap<>();
    private final Map<Integer, Double> swapAverageMs = new HashMap<>();
    private long holdUntilTick = -1;

    public PopTracker(class_310 mc) {
        this.mc = mc;
    }

    /** Queues pop and equipment packets. Safe to call from the network thread. */
    public void onPacket(class_2596<?> packet) {
        boolean pop = packet instanceof class_2663 status
                && status.method_11470() == TOTEM_POP_STATUS;

        if (pop || packet instanceof class_2744) {
            pending.add(new Received(packet, System.nanoTime()));

            if (pending.size() > MAX_PENDING) {
                pending.poll();
            }
        }
    }

    /** Resolves queued packets. Call once per client tick. */
    public void process(long tick, int popDelay, boolean pingComp, Consumer<String> log) {
        long now = System.nanoTime();
        Received received;

        while ((received = pending.poll()) != null) {
            if (received.packet() instanceof class_2663 status) {
                handlePop(status, received.nanos(), tick, popDelay, pingComp, log);
            } else if (received.packet() instanceof class_2744 equipment) {
                handleEquipment(equipment, received.nanos(), log);
            }
        }

        popNanos.values().removeIf(time -> now - time > FORGET_NANOS);
    }

    /** True while crystals should not be broken. Logs once when the hold ends. */
    public boolean holding(long tick, boolean enabled, Consumer<String> log) {
        if (holdUntilTick < 0) {
            return false;
        }

        if (enabled && tick < holdUntilTick) {
            return true;
        }

        holdUntilTick = -1;
        log.accept("Hold over, breaking crystals");
        return false;
    }

    public void reset() {
        pending.clear();
        popNanos.clear();
        holdUntilTick = -1;
    }

    /** Round trip time in ticks, rounded down. 0 in singleplayer. */
    public int pingTicks() {
        if (mc.field_1724 == null || mc.method_1562() == null) {
            return 0;
        }

        var entry = mc.method_1562().method_2871(mc.field_1724.method_5667());
        return entry == null ? 0 : entry.method_2959() / 50;
    }

    private void handlePop(class_2663 packet, long arrivedAt, long tick,
                           int popDelay, boolean pingComp, Consumer<String> log) {
        class_1297 entity = packet.method_11469(mc.field_1687);
        if (entity == null
                || entity == mc.field_1724
                || mc.field_1724.method_5858(entity) > TRACK_RANGE * TRACK_RANGE) {
            return;
        }

        popNanos.put(entity.method_5628(), arrivedAt);

        // The pop packet reaches us about half a round trip late and our attack needs the
        // other half to get back, so the wait shrinks by the ping (floored, to stay safe).
        int wait = popDelay;
        if (pingComp) {
            wait -= pingTicks();
        }
        wait = Math.max(0, wait);

        holdUntilTick = tick + wait;
        log.accept("Pop on " + entity.method_5477().getString() + ", holding breaks for " + wait + " ticks");
    }

    /** Measures how long a player takes to put a new totem in their offhand after popping. */
    private void handleEquipment(class_2744 packet, long arrivedAt,
                                 Consumer<String> log) {
        int id = packet.method_11820();
        Long poppedAt = popNanos.get(id);
        if (poppedAt == null) {
            return;
        }

        for (var pair : packet.method_30145()) {
            if (pair.getFirst() == class_1304.field_6171
                    && pair.getSecond().method_31574(class_1802.field_8288)) {
                double delayMs = (arrivedAt - poppedAt) / 1_000_000.0;
                double average = swapAverageMs.merge(id, delayMs, (old, now) -> old * 0.5 + now * 0.5);

                class_1297 entity = mc.field_1687.method_8469(id);
                String name = entity == null ? "player" : entity.method_5477().getString();
                log.accept(String.format("%s re-equipped a totem in %.0f ms (average %.0f ms)",
                        name, delayMs, average));

                popNanos.remove(id);
                return;
            }
        }
    }
}