package net.staro.nomnom.utility;

import lombok.experimental.UtilityClass;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_310;

/**
 * Projects a world position onto the (scaled) screen so we can draw 2D overlays on top of the HUD.
 * Uses the camera entity's position and rotation and the FOV option, so it is accurate in first person.
 * It ignores dynamic FOV effects (sprinting, bows) and third-person camera offset.
 */
@UtilityClass
public class ProjectionUtil {

    /**
     * @return a vector (screenX, screenY, depth) in GUI-scaled pixels, or null if the point is behind the camera.
     */
    public class_243 toScreen(class_310 mc, class_243 point, float tickProgress) {
        class_1297 camera = mc.method_1560();
        if (camera == null) {
            return null;
        }

        class_243 origin = camera.method_5836(tickProgress);
        class_243 forward = class_243.method_1030(camera.method_5695(tickProgress), camera.method_5705(tickProgress));
        class_243 right = forward.method_1036(new class_243(0, 1, 0)).method_1029();
        class_243 up = right.method_1036(forward);

        class_243 relative = point.method_1020(origin);
        double depth = relative.method_1026(forward);
        if (depth < 0.05) {
            return null;
        }

        double tan = Math.tan(Math.toRadians(mc.field_1690.method_41808().method_41753()) / 2.0);
        double aspect = (double) mc.method_22683().method_4489() / mc.method_22683().method_4506();
        double ndcX = relative.method_1026(right) / (depth * tan * aspect);
        double ndcY = relative.method_1026(up) / (depth * tan);

        double x = (ndcX * 0.5 + 0.5) * mc.method_22683().method_4486();
        double y = (0.5 - ndcY * 0.5) * mc.method_22683().method_4502();
        return new class_243(x, y, depth);
    }
}
