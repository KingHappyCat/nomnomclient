package net.staro.nomnom.utility;

import lombok.experimental.UtilityClass;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1569;
import net.minecraft.class_1657;
import net.minecraft.class_332;
import net.staro.nomnom.Nomnom;

/** Shared helpers for ESP, Tracers, Nametags and KillAura. */
@UtilityClass
public class EspUtil {
    public static final int FRIEND = 0xFF55FFFF;
    public static final int PLAYER = 0xFFFF5555;
    public static final int HOSTILE = 0xFFFFAA00;
    public static final int PASSIVE = 0xFF55FF55;

    public boolean wanted(class_1297 entity, boolean players, boolean hostiles, boolean passives) {
        if (entity instanceof class_1657) return players;
        if (entity instanceof class_1569) return hostiles;
        if (entity instanceof class_1296) return passives;
        return false;
    }

    public int color(Nomnom nomnom, class_1297 entity) {
        if (entity instanceof class_1657 player) {
            return nomnom.friendManager().isFriend(player) ? FRIEND : PLAYER;
        }
        return entity instanceof class_1569 ? HOSTILE : PASSIVE;
    }

    /** 1px rectangle outline. */
    public void outline(class_332 ctx, int x1, int y1, int x2, int y2, int color) {
        ctx.method_25294(x1, y1, x2, y1 + 1, color);
        ctx.method_25294(x1, y2 - 1, x2, y2, color);
        ctx.method_25294(x1, y1, x1 + 1, y2, color);
        ctx.method_25294(x2 - 1, y1, x2, y2, color);
    }

    /** 1px line, drawn pixel by pixel; pixels outside the screen are skipped. */
    public void line(class_332 ctx, int x1, int y1, int x2, int y2, int color, int screenW, int screenH) {
        int dx = x2 - x1;
        int dy = y2 - y1;
        int steps = Math.max(Math.abs(dx), Math.abs(dy));
        if (steps == 0) {
            return;
        }
        for (int i = 0; i <= steps; i++) {
            int x = x1 + Math.round((float) dx * i / steps);
            int y = y1 + Math.round((float) dy * i / steps);
            if (x < 0 || y < 0 || x >= screenW || y >= screenH) {
                continue;
            }
            ctx.method_25294(x, y, x + 1, y + 1, color);
        }
    }
}
