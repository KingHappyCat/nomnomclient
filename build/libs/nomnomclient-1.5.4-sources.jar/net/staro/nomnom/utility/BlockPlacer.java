package net.staro.nomnom.utility;

import net.minecraft.class_1268;
import net.minecraft.class_1792;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2828;
import net.minecraft.class_2868;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3965;

/**
 * Silent block placement: switches the server's held slot for the placement and back again
 * without ever changing what the client has selected, and optionally looks at the block
 * with a rotation packet that is undone afterwards. Call {@link #finish()} at the end of
 * every tick that placed something. Client tick thread only.
 */
public class BlockPlacer {
    private final class_310 mc;
    private boolean rotated;

    public BlockPlacer(class_310 mc) {
        this.mc = mc;
    }

    /** Hotbar slot holding {@code item}, or -1. */
    public int findHotbarSlot(class_1792 item) {
        for (int slot = 0; slot < 9; slot++) {
            if (mc.field_1724.method_31548().method_5438(slot).method_31574(item)) {
                return slot;
            }
        }

        return -1;
    }

    /**
     * A click on a neighbouring solid block that places a block at {@code pos}, or null if
     * there is nothing to click on within {@code reach}. Blocks that open something when
     * clicked (chests, furnaces...) are not used, because the click would open them instead.
     */
    public class_3965 findHit(class_2338 pos, class_243 eye, double reach) {
        class_3965 best = null;
        double bestDistance = reach * reach;

        for (class_2350 direction : class_2350.values()) {
            class_2338 support = pos.method_10093(direction);
            var state = mc.field_1687.method_8320(support);

            if (!state.method_26212(mc.field_1687, support)
                    || state.method_31709()
                    || state.method_26196(mc.field_1687, support) != null) {
                continue;
            }

            class_2350 face = direction.method_10153();
            class_243 point = class_243.method_24953(support).method_1031(
                    face.method_10148() * 0.5,
                    face.method_10164() * 0.5,
                    face.method_10165() * 0.5
            );

            double distance = eye.method_1025(point);

            if (distance <= bestDistance) {
                bestDistance = distance;
                best = new class_3965(point, face, support, false);
            }
        }

        return best;
    }

    /**
     * "Air place": a click on the empty position itself, for when there is no neighbouring
     * block to click on. Vanilla servers accept it, but anticheats that look for clicks on air
     * (Grim has one) flag it. Null if {@code pos} is out of reach.
     */
    public class_3965 airHit(class_2338 pos, class_243 eye, double reach) {
        class_243 point = class_243.method_24953(pos);

        if (eye.method_1025(point) > reach * reach) {
            return null;
        }

        return new class_3965(point, class_2350.field_11036, pos, false);
    }

    /** Runs {@code action} with the server's held slot switched to {@code slot}. */
    public void withSilentSlot(int slot, Runnable action) {
        int previousSlot = mc.field_1724.method_31548().method_67532();
        boolean switched = slot != previousSlot;

        try {
            if (switched) {
                mc.method_1562().method_52787(new class_2868(slot));
            }

            action.run();
        } finally {
            if (switched) {
                mc.method_1562().method_52787(new class_2868(previousSlot));
            }
        }
    }

    /** Clicks {@code hit} with the held item (the slot must already be switched). */
    public void place(class_3965 hit, boolean rotate) {
        if (rotate) {
            faceSilently(hit.method_17784());
        }

        mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hit);
        mc.field_1724.method_6104(class_1268.field_5808);
    }

    /** Puts the server's idea of our rotation back to the real one, if it was changed. */
    public void finish() {
        if (!rotated) {
            return;
        }

        rotated = false;

        if (mc.field_1724 != null && mc.method_1562() != null) {
            sendLook(mc.field_1724.method_36454(), mc.field_1724.method_36455());
        }
    }

    private void faceSilently(class_243 point) {
        class_243 eye = mc.field_1724.method_33571();
        double dx = point.field_1352 - eye.field_1352;
        double dy = point.field_1351 - eye.field_1351;
        double dz = point.field_1350 - eye.field_1350;
        double horizontal = Math.hypot(dx, dz);

        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal));

        sendLook(class_3532.method_15393(yaw), class_3532.method_15363(pitch, -90.0f, 90.0f));
        rotated = true;
    }

    private void sendLook(float yaw, float pitch) {
        mc.method_1562().method_52787(new class_2828.class_2831(
                yaw, pitch, mc.field_1724.method_24828(), mc.field_1724.field_5976));
    }
}