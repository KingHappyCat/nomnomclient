package net.staro.nomnom.module.modules;

import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2663;
import net.minecraft.class_2868;
import net.minecraft.class_3965;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.api.Setting;
import net.staro.nomnom.api.event.listener.Listener;
import net.staro.nomnom.events.PacketEvent;
import net.staro.nomnom.events.tick.TickEvent;
import net.staro.nomnom.module.Category;
import net.staro.nomnom.module.NomnomModule;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

import java.util.Locale;

@SuppressWarnings("unused")
public class AutoCrystal extends NomnomModule {

    private final Setting<Boolean> autoPlace = bool("AutoPlace", true);
    private final Setting<Boolean> autoBreak = bool("AutoBreak", true);
    private final Setting<Integer> placeRange = integer("PlaceRange", 4, 1, 6);
    private final Setting<Integer> breakRange = integer("BreakRange", 5, 1, 6);
    private final Setting<Integer> maxPlacementsPerTick = integer("MaxPlacementsPerTick", 3, 1, 8);
    private final Setting<Boolean> players = bool("Players", true);
    private final Setting<Boolean> mobs = bool("Mobs", true);

    // Double pop timing: after the target pops a totem the server ignores any damage that
    // doesn't beat their last hit for ~10 ticks, so breaking early is wasted. We hold breaking
    // (but keep placing, so crystals are armed) and release right as that window ends.
    private final Setting<Boolean> doublePop = bool("DoublePop", true);
    private final Setting<Integer> popDelay = integer("PopDelay", 10, 0, 20);
    private final Setting<Boolean> pingComp = bool("PingComp", true);
    private final Setting<Boolean> debug = bool("Debug", false);

    private static final double POP_TRACK_RANGE = 12.0;
    private static final int TOTEM_POP_STATUS = 35;

    private final Queue<class_2663> pendingStatus = new ConcurrentLinkedQueue<>();
    private long tickCounter;
    private long holdUntilTick = -1;

    private static final int RESTOCK_THRESHOLD = 10;
    private static final long STATS_INTERVAL_NS = 1_000_000_000L;

    // Performance statistics
    private long statsWindowStart = System.nanoTime();
    private int placeAttemptsWindow;
    private int breakAttemptsWindow;

    public AutoCrystal(Nomnom nomnom) {
        super(
                nomnom,
                "AutoCrystal",
                Category.COMBAT,
                "Automatically places and breaks end crystals"
        );
    }

    @Override
    public void onDisable() {
        pendingStatus.clear();
        holdUntilTick = -1;
    }

    @Listener
    public void onPacket(PacketEvent.Receive event) {
        // Network thread: only queue the packet, it is resolved on the client tick.
        if (doublePop.getValue()
                && event.getPacket() instanceof class_2663 packet
                && packet.method_11470() == TOTEM_POP_STATUS) {
            pendingStatus.add(packet);
        }
    }

    @Listener
    public void onTick(TickEvent event) {
        if (mc.field_1724 == null
                || mc.field_1687 == null
                || mc.field_1761 == null
                || mc.method_1562() == null) {
            return;
        }

        tickCounter++;
        processPops();

        boolean holding = false;
        if (holdUntilTick >= 0) {
            if (doublePop.getValue() && tickCounter < holdUntilTick) {
                holding = true;
            } else {
                holdUntilTick = -1;
                debugMessage("Hold over, breaking crystals");
            }
        }

        restockCrystals();

        if (autoBreak.getValue() && !holding) {
            breakCrystals();
        }

        if (autoPlace.getValue()) {
            placeCrystals();
        }
    }

    private void processPops() {
        class_2663 packet;
        while ((packet = pendingStatus.poll()) != null) {
            class_1297 entity = packet.method_11469(mc.field_1687);
            if (entity == null
                    || entity == mc.field_1724
                    || mc.field_1724.method_5858(entity) > POP_TRACK_RANGE * POP_TRACK_RANGE) {
                continue;
            }

            // The pop packet reaches us about half a round trip late and our attack needs the
            // other half to get back, so the wait shrinks by the ping (floored, to stay safe).
            int wait = popDelay.getValue();
            if (pingComp.getValue()) {
                wait -= pingTicks();
            }
            wait = Math.max(0, wait);

            holdUntilTick = tickCounter + wait;
            debugMessage("Pop on " + entity.method_5477().getString() + ", holding breaks for " + wait + " ticks");
        }
    }

    private int pingTicks() {
        var entry = mc.method_1562().method_2871(mc.field_1724.method_5667());
        return entry == null ? 0 : entry.method_2959() / 50;
    }

    private void debugMessage(String message) {
        if (debug.getValue() && mc.field_1724 != null) {
            mc.field_1724.method_7353(class_2561.method_43470("[AutoCrystal] " + message), false);
        }
    }

    private void breakCrystals() {
        double range = breakRange.getValue();

        for (class_1511 crystal : mc.field_1687.method_8390(
                class_1511.class,
                mc.field_1724.method_5829().method_1014(range),
                entity -> entity.method_5805()
                        && mc.field_1724.method_5858(entity) <= range * range
        )) {
            breakAttemptsWindow++;

            mc.field_1761.method_2918(mc.field_1724, crystal);
            mc.field_1724.method_6104(class_1268.field_5808);
            return;
        }
    }

    private void placeCrystals() {
        boolean offhandCrystal =
                mc.field_1724.method_6079().method_31574(class_1802.field_8301);

        int crystalSlot = findCrystalSlot();

        if (!offhandCrystal && crystalSlot == -1) {
            return;
        }

        int availableCrystals = offhandCrystal
                ? mc.field_1724.method_6079().method_7947()
                : mc.field_1724.method_31548().method_5438(crystalSlot).method_7947();

        int placementLimit = Math.min(
                maxPlacementsPerTick.getValue(),
                availableCrystals
        );

        if (placementLimit <= 0) {
            return;
        }

        class_1309 target = findTarget();

        if (target == null) {
            return;
        }

        int range = placeRange.getValue();
        class_2338 targetPos = target.method_24515();

        int placementsThisTick = 0;
        List<class_238> attemptedBoxes = new ArrayList<>();

        for (class_2338 base : class_2338.method_10097(
                targetPos.method_10069(-range, -2, -range),
                targetPos.method_10069(range, 2, range))) {

            if (placementsThisTick >= placementLimit) {
                break;
            }

            if (mc.field_1724.method_5707(class_243.method_24953(base))
                    > range * range) {
                continue;
            }

            if (!mc.field_1687.method_8320(base).method_27852(class_2246.field_10540)
                    && !mc.field_1687.method_8320(base).method_27852(class_2246.field_9987)) {
                continue;
            }

            class_2338 above = base.method_10084();

            // Require space for the crystal.
            if (!mc.field_1687.method_8320(above).method_26215()
                    || !mc.field_1687.method_8320(above.method_10084()).method_26215()) {
                continue;
            }

            class_238 crystalBox = new class_238(
                    above.method_10263(),
                    above.method_10264(),
                    above.method_10260(),
                    above.method_10263() + 1,
                    above.method_10264() + 2,
                    above.method_10260() + 1
            );

            if (!mc.field_1687.method_8335(null, crystalBox).isEmpty()) {
                continue;
            }

            // Avoid requesting placements with overlapping crystal spaces.
            boolean overlapsAttempt = false;

            for (class_238 attemptedBox : attemptedBoxes) {
                if (attemptedBox.method_994(crystalBox)) {
                    overlapsAttempt = true;
                    break;
                }
            }

            if (overlapsAttempt) {
                continue;
            }

            class_3965 hit = new class_3965(
                    class_243.method_24953(base).method_1031(0, 0.5, 0),
                    class_2350.field_11036,
                    base,
                    false
            );

            // Count attempts, not server-confirmed successful placements.
            placeAttemptsWindow++;

            if (offhandCrystal) {
                mc.field_1761.method_2896(
                        mc.field_1724, class_1268.field_5810, hit
                );
                mc.field_1724.method_6104(class_1268.field_5810);
            } else {
                int previousSlot =
                        mc.field_1724.method_31548().method_67532();

                try {
                    mc.method_1562().method_52787(
                            new class_2868(crystalSlot)
                    );

                    mc.field_1761.method_2896(
                            mc.field_1724, class_1268.field_5808, hit
                    );

                    mc.field_1724.method_6104(class_1268.field_5808);
                } finally {
                    mc.method_1562().method_52787(
                            new class_2868(previousSlot)
                    );
                }
            }

            attemptedBoxes.add(crystalBox);
            placementsThisTick++;
        }
    }

    private int findCrystalSlot() {
        for (int slot = 0; slot < 9; slot++) {
            if (mc.field_1724.method_31548().method_5438(slot)
                    .method_31574(class_1802.field_8301)) {
                return slot;
            }
        }

        return -1;
    }

    private void restockCrystals() {
        var inventory = mc.field_1724.method_31548();
        int totalCrystals = 0;

        for (int slot = 0; slot < 36; slot++) {
            var stack = inventory.method_5438(slot);

            if (stack.method_31574(class_1802.field_8301)) {
                totalCrystals += stack.method_7947();
            }
        }

        if (totalCrystals > RESTOCK_THRESHOLD) {
            return;
        }

        for (int hotbarSlot = 0; hotbarSlot < 9; hotbarSlot++) {
            var hotbarStack = inventory.method_5438(hotbarSlot);

            if (!hotbarStack.method_31574(class_1802.field_8301)) {
                continue;
            }

            for (int inventorySlot = 9; inventorySlot < 36; inventorySlot++) {
                var inventoryStack = inventory.method_5438(inventorySlot);

                if (!inventoryStack.method_31574(class_1802.field_8301)) {
                    continue;
                }

                mc.field_1761.method_2906(
                        mc.field_1724.field_7512.field_7763,
                        inventorySlot,
                        hotbarSlot,
                        class_1713.field_7791,
                        mc.field_1724
                );

                return;
            }
        }
    }

    private class_1309 findTarget() {
        double range = placeRange.getValue();

        return mc.field_1687.method_8390(
                class_1309.class,
                mc.field_1724.method_5829().method_1014(range),
                entity -> entity != mc.field_1724
                        && entity.method_5805()
                        && isValidTarget(entity)
                        && mc.field_1724.method_5858(entity) <= range * range
        ).stream().min((a, b) -> Double.compare(
                mc.field_1724.method_5858(a),
                mc.field_1724.method_5858(b)
        )).orElse(null);
    }

    private boolean isValidTarget(class_1309 entity) {
        if (entity instanceof class_1657 player) {
            return players.getValue() && !nomnom.friendManager().isFriend(player);
        }
        return mobs.getValue();
    }
}