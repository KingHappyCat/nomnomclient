package net.staro.nomnom.module.modules;

import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.api.Setting;
import net.staro.nomnom.api.event.listener.Listener;
import net.staro.nomnom.events.tick.TickEvent;
import net.staro.nomnom.module.Category;
import net.staro.nomnom.module.NomnomModule;
import net.staro.nomnom.utility.BlockPlacer;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Walls you in with obsidian: a block on every side of your feet, so crystals and players can't
 * get at you from the side.
 *
 * <p>It works from the blocks your hitbox really covers, so standing on the edge between two
 * blocks (or in a corner of four) still gets a complete ring. Sides facing the nearest enemy
 * are filled first, and anything that can't be placed because nothing is there to click on gets
 * a support block underneath first. Missing blocks are replaced the next tick, so a block that
 * gets mined or blown up is back straight away.
 *
 * <p>Height 2 adds a second layer on top, which stops crystals being placed on top of the ring
 * and exploding beside your upper body (face placing). Roof also covers the block above your
 * head.
 */
@SuppressWarnings("unused")
public class FeetTrap extends NomnomModule {
    private static final class_2350[] SIDES = {
            class_2350.field_11043, class_2350.field_11034, class_2350.field_11035, class_2350.field_11039
    };
    private static final double ENEMY_RANGE = 16.0;

    private final Setting<Integer> blocksPerTick = integer("BlocksPerTick", 4, 1, 8);
    // 2 = a second layer on top of the ring, against crystals placed on top of it.
    private final Setting<Integer> height = integer("Height", 1, 1, 2);
    // Also cover the block above your head.
    private final Setting<Boolean> roof = bool("Roof", false);
    // Place a block underneath first when there is nothing to click on.
    private final Setting<Boolean> support = bool("Support", true);
    // Use ender chests when you have no obsidian in the hotbar.
    private final Setting<Boolean> enderChests = bool("EnderChests", true);
    private final Setting<Boolean> rotate = bool("Rotate", true);
    private final Setting<Double> range = precise("Range", 4.5, 2.0, 6.0);
    // Turn off when you leave the block you enabled it on.
    private final Setting<Boolean> disableOnMove = bool("DisableOnMove", false);

    private final BlockPlacer placer;
    // Positions we sent a placement for. The block only shows up on our client after the
    // server answers, so without this the same position would be placed again every tick.
    private final Map<class_2338, Long> recent = new HashMap<>();
    private class_2338 anchor;
    private long tickCounter;

    public FeetTrap(Nomnom nomnom) {
        super(nomnom, "FeetTrap", Category.COMBAT, "Surrounds your feet with obsidian");
        this.placer = new BlockPlacer(mc);
    }

    @Override
    public void onEnable() {
        anchor = mc.field_1724 == null ? null : mc.field_1724.method_24515();
        recent.clear();
    }

    @Override
    public void onDisable() {
        anchor = null;
        recent.clear();
    }

    @Listener
    public void onTick(TickEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null
                || mc.field_1761 == null || mc.method_1562() == null) {
            return;
        }

        tickCounter++;

        try {
            run();
        } finally {
            placer.finish();
        }
    }

    private void run() {
        class_2338 feet = mc.field_1724.method_24515();

        if (anchor == null) {
            anchor = feet;
        }

        if (disableOnMove.getValue() && !feet.equals(anchor)) {
            disable();
            return;
        }

        // In the air there is no ring to build.
        if (!mc.field_1724.method_24828()) {
            return;
        }

        int slot = placer.findHotbarSlot(class_1802.field_8281);
        if (slot == -1 && enderChests.getValue()) {
            slot = placer.findHotbarSlot(class_1802.field_8466);
        }
        if (slot == -1) {
            return;
        }

        List<class_2338> missing = missingBlocks(feet);
        if (missing.isEmpty()) {
            return;
        }

        class_243 eye = mc.field_1724.method_33571();
        double reach = range.getValue();
        int budget = blocksPerTick.getValue();
        int pending = pingTicks() + 2;

        List<class_2338> positions = new ArrayList<>();
        List<class_3965> hits = new ArrayList<>();

        for (class_2338 pos : missing) {
            if (positions.size() >= budget) {
                break;
            }

            Long placedAt = recent.get(pos);
            if (placedAt != null && tickCounter - placedAt < pending) {
                continue;
            }

            class_3965 hit = placer.findHit(pos, eye, reach);

            if (hit != null) {
                positions.add(pos);
                hits.add(hit);
                continue;
            }

            // Nothing to click on: build the block underneath it instead, then this one next tick.
            if (support.getValue()) {
                class_2338 below = pos.method_10074();
                Long supportedAt = recent.get(below);

                if ((supportedAt == null || tickCounter - supportedAt >= pending)
                        && canPlaceAt(below)) {
                    class_3965 supportHit = placer.findHit(below, eye, reach);

                    if (supportHit != null) {
                        positions.add(below);
                        hits.add(supportHit);
                    }
                }
            }
        }

        if (positions.isEmpty()) {
            return;
        }

        boolean spin = rotate.getValue();

        placer.withSilentSlot(slot, () -> {
            for (int i = 0; i < positions.size(); i++) {
                placer.place(hits.get(i), spin);
                recent.put(positions.get(i), tickCounter);
            }
        });

        if (recent.size() > 64) {
            recent.values().removeIf(tick -> tickCounter - tick > 40);
        }
    }

    /**
     * Blocks that should be solid around you but aren't (and can be filled), nearest to the
     * closest enemy first and lowest layer first.
     */
    private List<class_2338> missingBlocks(class_2338 feet) {
        class_238 box = mc.field_1724.method_5829();
        int y = feet.method_10264();

        // Every block column the hitbox touches. 1 block when you stand in the middle.
        Set<class_2338> occupied = new LinkedHashSet<>();
        for (int x = class_3532.method_15357(box.field_1323 + 1.0E-3); x <= class_3532.method_15357(box.field_1320 - 1.0E-3); x++) {
            for (int z = class_3532.method_15357(box.field_1321 + 1.0E-3); z <= class_3532.method_15357(box.field_1324 - 1.0E-3); z++) {
                occupied.add(new class_2338(x, y, z));
            }
        }

        record Wanted(class_2338 pos, int layer) {
        }

        Set<class_2338> seen = new LinkedHashSet<>();
        List<Wanted> wanted = new ArrayList<>();

        for (int layer = 0; layer < height.getValue(); layer++) {
            for (class_2338 column : occupied) {
                for (class_2350 side : SIDES) {
                    class_2338 pos = column.method_10093(side).method_10086(layer);

                    if (!occupied.contains(column.method_10093(side)) && seen.add(pos)) {
                        wanted.add(new Wanted(pos, layer));
                    }
                }
            }
        }

        if (roof.getValue()) {
            for (class_2338 column : occupied) {
                class_2338 pos = column.method_10086(2);

                if (seen.add(pos)) {
                    wanted.add(new Wanted(pos, height.getValue()));
                }
            }
        }

        class_243 enemy = nearestEnemy();

        wanted.sort(Comparator
                .comparingInt(Wanted::layer)
                .thenComparingDouble(entry -> enemy == null
                        ? 0.0
                        : class_243.method_24953(entry.pos()).method_1025(enemy)));

        List<class_2338> missing = new ArrayList<>();
        for (Wanted entry : wanted) {
            if (canPlaceAt(entry.pos())) {
                missing.add(entry.pos());
            }
        }

        return missing;
    }

    /** True if the block at {@code pos} is open to build in and nobody is standing there. */
    private boolean canPlaceAt(class_2338 pos) {
        if (!mc.field_1687.method_8320(pos).method_45474()) {
            return false;
        }

        // A crystal, player or mob in the way stops the placement.
        return mc.field_1687.method_8333(
                null,
                new class_238(pos),
                entity -> entity.method_5805()
                        && !entity.method_7325()
                        && (entity instanceof class_1309 || entity.method_5864() == class_1299.field_6110)
        ).isEmpty();
    }

    private class_243 nearestEnemy() {
        class_1657 nearest = null;
        double best = ENEMY_RANGE * ENEMY_RANGE;

        for (class_1657 player : mc.field_1687.method_18456()) {
            if (player == mc.field_1724 || !player.method_5805() || nomnom.friendManager().isFriend(player)) {
                continue;
            }

            double distance = mc.field_1724.method_5858(player);

            if (distance < best) {
                best = distance;
                nearest = player;
            }
        }

        return nearest == null ? null : new class_243(nearest.method_23317(), nearest.method_23318(), nearest.method_23321());
    }

    /** Round trip time in ticks, rounded down. 0 in singleplayer. */
    private int pingTicks() {
        var entry = mc.method_1562().method_2871(mc.field_1724.method_5667());
        return entry == null ? 0 : entry.method_2959() / 50;
    }
}