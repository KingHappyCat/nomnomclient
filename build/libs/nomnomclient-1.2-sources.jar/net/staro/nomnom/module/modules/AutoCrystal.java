package net.staro.nomnom.module.modules;

import net.minecraft.class_1268;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2663;
import net.minecraft.class_2744;
import net.minecraft.class_2828;
import net.minecraft.class_2868;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_5134;
import net.minecraft.class_7924;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.api.Setting;
import net.staro.nomnom.api.event.listener.Listener;
import net.staro.nomnom.events.PacketEvent;
import net.staro.nomnom.events.tick.TickEvent;
import net.staro.nomnom.module.Category;
import net.staro.nomnom.module.NomnomModule;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

@SuppressWarnings("unused")
public class AutoCrystal extends NomnomModule {

    public enum TargetMode {NEAREST, LOWEST_HEALTH, WEAKEST_ARMOR}

    // --- General ---
    private final Setting<Boolean> autoPlace = bool("AutoPlace", true);
    private final Setting<Boolean> autoBreak = bool("AutoBreak", true);
    private final Setting<Integer> placeRange = integer("PlaceRange", 4, 1, 6);
    private final Setting<Integer> breakRange = integer("BreakRange", 5, 1, 6);
    private final Setting<Integer> targetRange = integer("TargetRange", 8, 2, 12);
    private final Setting<Integer> maxPlacementsPerTick = integer("MaxPlacementsPerTick", 3, 1, 8);
    private final Setting<Boolean> players = bool("Players", true);
    private final Setting<Boolean> mobs = bool("Mobs", true);
    private final Setting<TargetMode> targetMode = enumSetting("TargetMode", TargetMode.NEAREST);

    // --- Speed ---
    // Remove the crystal from the client world as soon as we hit it. This stops us hitting the
    // same ghost crystal every tick and frees the spot so a new crystal can be placed on it in
    // the same tick.
    private final Setting<Boolean> instantRemove = bool("InstantRemove", true);
    // Minimum ticks between two hits on the same crystal (only matters if it is still around).
    private final Setting<Integer> breakDelay = integer("BreakDelay", 2, 0, 5);
    // Send a silent rotation packet to the crystal / block before each action, then restore.
    private final Setting<Boolean> rotate = bool("Rotate", true);

    // --- Damage ---
    // Only damage dealt to the target is checked, never self damage.
    private final Setting<Double> minDamage = precise("MinDamage", 4.0, 0.5, 20.0);
    // Ticks of target movement to predict ahead when calculating damage.
    private final Setting<Integer> predict = integer("Predict", 1, 0, 5);
    // Spots that would kill the target (damage >= health + absorption) are used first.
    private final Setting<Boolean> lethalPriority = bool("LethalPriority", true);
    // When the target's health + absorption is at or below this, MinDamage drops to 1 so
    // any spot that hurts them is used (face placing). 0 disables it.
    private final Setting<Integer> facePlaceHealth = integer("FacePlaceHealth", 8, 0, 36);
    // Read the target's real Protection / Blast Protection enchants from their armor.
    private final Setting<Boolean> readEnchants = bool("ReadEnchants", true);
    // Used when ReadEnchants is off: 16 is Protection IV everywhere, 20 is the cap.
    private final Setting<Integer> assumedProtection = integer("AssumedProtection", 16, 0, 20);

    // --- Obsidian ---
    // When no valid crystal spot exists, place an obsidian base (needs obsidian in the hotbar)
    // on the best spot and crystal it on the following tick.
    private final Setting<Boolean> obsidianBase = bool("ObsidianBase", true);

    // --- Double pop ---
    // After the target pops a totem the server ignores any damage that doesn't beat their last
    // hit for ~10 ticks, so breaking early is wasted. We hold breaking (but keep placing, so
    // crystals are armed) and release right as that window ends.
    private final Setting<Boolean> doublePop = bool("DoublePop", true);
    private final Setting<Integer> popDelay = integer("PopDelay", 10, 0, 20);
    private final Setting<Boolean> pingComp = bool("PingComp", true);
    private final Setting<Boolean> debug = bool("Debug", false);

    private static final double POP_TRACK_RANGE = 12.0;
    private static final int TOTEM_POP_STATUS = 35;
    private static final double CRYSTAL_POWER = 6.0;
    private static final double REACH = 4.5;
    private static final int RESTOCK_THRESHOLD = 10;
    private static final int RESTOCK_COOLDOWN_TICKS = 5;
    private static final long POP_FORGET_NANOS = 5_000_000_000L;
    private static final class_1304[] ARMOR_SLOTS = {
            class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166
    };

    private record Received(class_2596<?> packet, long nanos) {
    }

    private record Placement(class_2338 base, double damage, boolean lethal, class_238 crystalBox) {
    }

    // Written on the network thread (queue) and drained on the client tick.
    private final Queue<Received> pending = new ConcurrentLinkedQueue<>();
    private final Map<Integer, Long> popNanos = new HashMap<>();
    private final Map<Integer, Double> swapAverageMs = new HashMap<>();
    private final Map<Integer, Long> lastHitTick = new ConcurrentHashMap<>();

    private long tickCounter;
    private long holdUntilTick = -1;
    private long lastRestockTick = -100;
    private int lastTargetId = -1;
    private class_243 lastTargetPos = class_243.field_1353;
    private double protectionReduction;
    private boolean rotated;

    public AutoCrystal(Nomnom nomnom) {
        super(
                nomnom,
                "AutoCrystal",
                Category.COMBAT,
                "Automatically places and breaks end crystals"
        );
    }

    @Override
    public void onDisable() {
        pending.clear();
        popNanos.clear();
        lastHitTick.clear();
        holdUntilTick = -1;
        lastTargetId = -1;
        rotated = false;
    }

    // ------------------------------------------------------------------ packets

    @Listener
    public void onPacket(PacketEvent.Receive event) {
        // Network thread: only queue the packet, it is resolved on the client tick.
        if (!doublePop.getValue()) {
            return;
        }

        class_2596<?> packet = event.getPacket();
        boolean pop = packet instanceof class_2663 status
                && status.method_11470() == TOTEM_POP_STATUS;

        if (pop || packet instanceof class_2744) {
            pending.add(new Received(packet, System.nanoTime()));

            if (pending.size() > 512) {
                pending.poll();
            }
        }
    }

    // --------------------------------------------------------------------- tick

    @Listener
    public void onTick(TickEvent event) {
        if (mc.field_1724 == null
                || mc.field_1687 == null
                || mc.field_1761 == null
                || mc.method_1562() == null) {
            return;
        }

        try {
            run();
        } finally {
            restoreRotation();
        }
    }

    private void run() {
        tickCounter++;
        processPending();

        boolean holding = false;
        if (holdUntilTick >= 0) {
            if (doublePop.getValue() && tickCounter < holdUntilTick) {
                holding = true;
            } else {
                holdUntilTick = -1;
                debugMessage("Hold over, breaking crystals");
            }
        }

        restockCrystals();

        class_1309 target = findTarget();
        if (target == null) {
            lastTargetId = -1;
            return;
        }

        // Where the target will roughly be when our crystal explodes.
        class_243 position = positionOf(target);
        class_243 velocity = target.method_5628() == lastTargetId
                ? position.method_1020(lastTargetPos)
                : class_243.field_1353;
        if (velocity.method_1027() > 1.0) {
            velocity = velocity.method_1029();
        }
        lastTargetId = target.method_5628();
        lastTargetPos = position;
        class_243 predicted = position.method_1019(velocity.method_1021(predict.getValue()));

        protectionReduction = protectionReductionOf(target);

        double healthTotal = target.method_6032() + target.method_6067();
        boolean facePlace = facePlaceHealth.getValue() > 0
                && healthTotal <= facePlaceHealth.getValue();
        double requiredDamage = facePlace ? 1.0 : minDamage.getValue();

        if (autoBreak.getValue() && !holding) {
            breakCrystals(target, predicted, requiredDamage);
        }

        if (autoPlace.getValue()) {
            placeCrystals(target, predicted, requiredDamage, healthTotal);
        }
    }

    // ------------------------------------------------------- pops and swap timing

    private void processPending() {
        long now = System.nanoTime();
        Received received;

        while ((received = pending.poll()) != null) {
            if (received.packet() instanceof class_2663 status) {
                handlePop(status, received.nanos());
            } else if (received.packet() instanceof class_2744 equipment) {
                handleEquipment(equipment, received.nanos());
            }
        }

        popNanos.values().removeIf(time -> now - time > POP_FORGET_NANOS);
    }

    private void handlePop(class_2663 packet, long arrivedAt) {
        class_1297 entity = packet.method_11469(mc.field_1687);
        if (entity == null
                || entity == mc.field_1724
                || mc.field_1724.method_5858(entity) > POP_TRACK_RANGE * POP_TRACK_RANGE) {
            return;
        }

        popNanos.put(entity.method_5628(), arrivedAt);

        // The pop packet reaches us about half a round trip late and our attack needs the
        // other half to get back, so the wait shrinks by the ping (floored, to stay safe).
        int wait = popDelay.getValue();
        if (pingComp.getValue()) {
            wait -= pingTicks();
        }
        wait = Math.max(0, wait);

        holdUntilTick = tickCounter + wait;
        debugMessage("Pop on " + entity.method_5477().getString() + ", holding breaks for " + wait + " ticks");
    }

    /** Measures how long a player takes to put a new totem in their offhand after popping. */
    private void handleEquipment(class_2744 packet, long arrivedAt) {
        int id = packet.method_11820();
        Long poppedAt = popNanos.get(id);
        if (poppedAt == null) {
            return;
        }

        for (var pair : packet.method_30145()) {
            if (pair.getFirst() == class_1304.field_6171
                    && pair.getSecond().method_31574(class_1802.field_8288)) {
                double delayMs = (arrivedAt - poppedAt) / 1_000_000.0;
                double average = swapAverageMs.merge(id, delayMs, (old, now) -> old * 0.5 + now * 0.5);

                class_1297 entity = mc.field_1687.method_8469(id);
                String name = entity == null ? "player" : entity.method_5477().getString();
                debugMessage(String.format("%s re-equipped a totem in %.0f ms (average %.0f ms)",
                        name, delayMs, average));

                popNanos.remove(id);
                return;
            }
        }
    }

    private int pingTicks() {
        var entry = mc.method_1562().method_2871(mc.field_1724.method_5667());
        return entry == null ? 0 : entry.method_2959() / 50;
    }

    private void debugMessage(String message) {
        if (debug.getValue() && mc.field_1724 != null) {
            mc.field_1724.method_7353(class_2561.method_43470("[AutoCrystal] " + message), false);
        }
    }

    // ----------------------------------------------------------------- breaking

    private void breakCrystals(class_1309 target, class_243 predicted, double requiredDamage) {
        double range = breakRange.getValue();

        class_1511 best = null;
        double bestDamage = requiredDamage;

        for (class_1511 crystal : mc.field_1687.method_8390(
                class_1511.class,
                mc.field_1724.method_5829().method_1014(range),
                entity -> entity.method_5805()
                        && mc.field_1724.method_5858(entity) <= range * range
        )) {
            Long lastHit = lastHitTick.get(crystal.method_5628());
            if (lastHit != null && tickCounter - lastHit <= breakDelay.getValue()) {
                continue;
            }

            double damage = crystalDamage(target, predicted, positionOf(crystal));

            if (damage >= bestDamage) {
                best = crystal;
                bestDamage = damage;
            }
        }

        if (best == null) {
            return;
        }

        faceSilently(best.method_5829().method_1005());

        mc.field_1761.method_2918(mc.field_1724, best);
        mc.field_1724.method_6104(class_1268.field_5808);

        lastHitTick.put(best.method_5628(), tickCounter);
        if (lastHitTick.size() > 64) {
            lastHitTick.values().removeIf(tick -> tickCounter - tick > 40);
        }

        if (instantRemove.getValue()) {
            mc.field_1687.method_2945(best.method_5628(), class_1297.class_5529.field_26998);
        }
    }

    // ----------------------------------------------------------------- placing

    private void placeCrystals(class_1309 target, class_243 predicted,
                               double requiredDamage, double healthTotal) {
        boolean offhandCrystal =
                mc.field_1724.method_6079().method_31574(class_1802.field_8301);

        int crystalSlot = findHotbarSlot(class_1802.field_8301);

        if (!offhandCrystal && crystalSlot == -1) {
            return;
        }

        int availableCrystals = offhandCrystal
                ? mc.field_1724.method_6079().method_7947()
                : mc.field_1724.method_31548().method_5438(crystalSlot).method_7947();

        int placementLimit = Math.min(
                maxPlacementsPerTick.getValue(),
                availableCrystals
        );

        if (placementLimit <= 0) {
            return;
        }

        int range = placeRange.getValue();
        class_2338 targetPos = target.method_24515();

        // Collect every valid spot with the damage it would deal, then take the best ones.
        List<Placement> candidates = new ArrayList<>();

        for (class_2338 base : class_2338.method_10097(
                targetPos.method_10069(-range, -2, -range),
                targetPos.method_10069(range, 2, range))) {

            if (mc.field_1724.method_5707(class_243.method_24953(base))
                    > range * range) {
                continue;
            }

            if (!mc.field_1687.method_8320(base).method_27852(class_2246.field_10540)
                    && !mc.field_1687.method_8320(base).method_27852(class_2246.field_9987)) {
                continue;
            }

            class_2338 above = base.method_10084();

            // Require space for the crystal.
            if (!mc.field_1687.method_8320(above).method_26215()
                    || !mc.field_1687.method_8320(above.method_10084()).method_26215()) {
                continue;
            }

            class_238 crystalBox = new class_238(
                    above.method_10263(),
                    above.method_10264(),
                    above.method_10260(),
                    above.method_10263() + 1,
                    above.method_10264() + 2,
                    above.method_10260() + 1
            );

            if (!mc.field_1687.method_8335(null, crystalBox).isEmpty()) {
                continue;
            }

            class_243 explosionCentre = new class_243(
                    above.method_10263() + 0.5,
                    above.method_10264(),
                    above.method_10260() + 0.5
            );

            double damage = crystalDamage(target, predicted, explosionCentre);

            if (damage < requiredDamage) {
                continue;
            }

            candidates.add(new Placement(
                    base.method_10062(), damage, damage >= healthTotal, crystalBox));
        }

        if (candidates.isEmpty()) {
            if (obsidianBase.getValue()) {
                placeObsidianBase(target, predicted, requiredDamage);
            }
            return;
        }

        boolean lethalFirst = lethalPriority.getValue();
        candidates.sort((a, b) -> {
            if (lethalFirst && a.lethal() != b.lethal()) {
                return a.lethal() ? -1 : 1;
            }
            return Double.compare(b.damage(), a.damage());
        });

        // Avoid requesting placements with overlapping crystal spaces.
        List<Placement> chosen = new ArrayList<>();

        for (Placement candidate : candidates) {
            if (chosen.size() >= placementLimit) {
                break;
            }

            boolean overlapsAttempt = false;

            for (Placement other : chosen) {
                if (other.crystalBox().method_994(candidate.crystalBox())) {
                    overlapsAttempt = true;
                    break;
                }
            }

            if (!overlapsAttempt) {
                chosen.add(candidate);
            }
        }

        class_1268 hand = offhandCrystal ? class_1268.field_5810 : class_1268.field_5808;

        Runnable placeAll = () -> {
            for (Placement placement : chosen) {
                class_243 hitPoint = class_243.method_24953(placement.base()).method_1031(0, 0.5, 0);
                class_3965 hit = new class_3965(
                        hitPoint,
                        class_2350.field_11036,
                        placement.base(),
                        false
                );

                faceSilently(hitPoint);
                mc.field_1761.method_2896(mc.field_1724, hand, hit);
                mc.field_1724.method_6104(hand);
            }
        };

        if (offhandCrystal) {
            placeAll.run();
        } else {
            withSilentSlot(crystalSlot, placeAll);
        }
    }

    /** Places one obsidian block where a crystal on top of it would hurt the target most. */
    private void placeObsidianBase(class_1309 target, class_243 predicted, double requiredDamage) {
        int obsidianSlot = findHotbarSlot(class_1802.field_8281);
        if (obsidianSlot == -1) {
            return;
        }

        int range = placeRange.getValue();
        class_2338 targetPos = target.method_24515();
        class_243 eye = mc.field_1724.method_33571();

        class_3965 bestHit = null;
        double bestDamage = requiredDamage;

        for (class_2338 base : class_2338.method_10097(
                targetPos.method_10069(-range, -2, -range),
                targetPos.method_10069(range, 2, range))) {

            if (mc.field_1724.method_5707(class_243.method_24953(base)) > range * range) {
                continue;
            }

            if (!mc.field_1687.method_8320(base).method_26215()) {
                continue;
            }

            class_2338 above = base.method_10084();

            if (!mc.field_1687.method_8320(above).method_26215()
                    || !mc.field_1687.method_8320(above.method_10084()).method_26215()) {
                continue;
            }

            // Nobody (including the target) may be standing where the block or crystal goes.
            class_238 space = new class_238(
                    base.method_10263(), base.method_10264(), base.method_10260(),
                    base.method_10263() + 1, base.method_10264() + 3, base.method_10260() + 1
            );

            if (!mc.field_1687.method_8335(null, space).isEmpty()) {
                continue;
            }

            class_243 explosionCentre = new class_243(
                    above.method_10263() + 0.5,
                    above.method_10264(),
                    above.method_10260() + 0.5
            );

            double damage = crystalDamage(target, predicted, explosionCentre);

            if (damage <= bestDamage) {
                continue;
            }

            class_3965 hit = supportHit(base, eye);

            if (hit == null) {
                continue;
            }

            bestHit = hit;
            bestDamage = damage;
        }

        if (bestHit == null) {
            return;
        }

        class_3965 hit = bestHit;

        withSilentSlot(obsidianSlot, () -> {
            faceSilently(hit.method_17784());
            mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hit);
            mc.field_1724.method_6104(class_1268.field_5808);
        });
    }

    /** A click on a neighbouring solid block that places a block at {@code base}. */
    private class_3965 supportHit(class_2338 base, class_243 eye) {
        for (class_2350 direction : class_2350.values()) {
            class_2338 support = base.method_10093(direction);

            if (!mc.field_1687.method_8320(support).method_26212(mc.field_1687, support)) {
                continue;
            }

            class_2350 face = direction.method_10153();
            class_243 point = class_243.method_24953(support).method_1031(
                    face.method_10148() * 0.5,
                    face.method_10164() * 0.5,
                    face.method_10165() * 0.5
            );

            if (eye.method_1025(point) > REACH * REACH) {
                continue;
            }

            return new class_3965(point, face, support, false);
        }

        return null;
    }

    // ------------------------------------------------------------ silent helpers

    /**
     * Silent hotbar switch: one packet to the slot before the action and one back afterwards.
     * The client never actually changes its selected slot.
     */
    private void withSilentSlot(int slot, Runnable action) {
        int previousSlot = mc.field_1724.method_31548().method_67532();
        boolean switched = slot != previousSlot;

        try {
            if (switched) {
                mc.method_1562().method_52787(new class_2868(slot));
            }

            action.run();
        } finally {
            if (switched) {
                mc.method_1562().method_52787(new class_2868(previousSlot));
            }
        }
    }

    /** Tells the server we are looking at {@code point} without moving the player's camera. */
    private void faceSilently(class_243 point) {
        if (!rotate.getValue()) {
            return;
        }

        class_243 eye = mc.field_1724.method_33571();
        double dx = point.field_1352 - eye.field_1352;
        double dy = point.field_1351 - eye.field_1351;
        double dz = point.field_1350 - eye.field_1350;
        double horizontal = Math.hypot(dx, dz);

        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal));

        sendLook(class_3532.method_15393(yaw), class_3532.method_15363(pitch, -90.0f, 90.0f));
        rotated = true;
    }

    /** Puts the server's idea of our rotation back to the real one. */
    private void restoreRotation() {
        if (!rotated || mc.field_1724 == null || mc.method_1562() == null) {
            rotated = false;
            return;
        }

        sendLook(mc.field_1724.method_36454(), mc.field_1724.method_36455());
        rotated = false;
    }

    private void sendLook(float yaw, float pitch) {
        mc.method_1562().method_52787(new class_2828.class_2831(
                yaw, pitch, mc.field_1724.method_24828(), mc.field_1724.field_5976));
    }

    // ------------------------------------------------------------------- damage

    /**
     * Damage a crystal exploding at {@code centre} deals to {@code target} standing at
     * {@code targetPos}, following the vanilla explosion formula: distance falloff, exposure,
     * difficulty, armor, resistance and enchantment protection. Absorption is ignored.
     */
    private double crystalDamage(class_1309 target, class_243 targetPos, class_243 centre) {
        double diameter = CRYSTAL_POWER * 2.0;
        double distance = targetPos.method_1022(centre) / diameter;

        if (distance > 1.0) {
            return 0.0;
        }

        double impact = (1.0 - distance) * exposure(centre, target, targetPos);
        double damage = (int) ((impact * impact + impact) / 2.0 * 7.0 * diameter + 1.0);

        if (target instanceof class_1657) {
            damage = switch (mc.field_1687.method_8407()) {
                case field_5801 -> 0.0;
                case field_5805 -> Math.min(damage / 2.0 + 1.0, damage);
                case field_5802 -> damage;
                case field_5807 -> damage * 1.5;
            };
        }

        // Armor and toughness.
        double armor = target.method_45325(class_5134.field_23724);
        double toughness = target.method_45325(class_5134.field_23725);
        double reduction = class_3532.method_15350(
                armor - damage / (2.0 + toughness / 4.0),
                armor * 0.2,
                20.0
        );
        damage *= 1.0 - reduction / 25.0;

        // Resistance effect.
        class_1293 resistance = target.method_6112(class_1294.field_5907);
        if (resistance != null) {
            damage *= Math.max(0, 25 - (resistance.method_5578() + 1) * 5) / 25.0;
        }

        // Enchantment protection (computed once per tick for the target).
        damage *= 1.0 - protectionReduction;

        return Math.max(0.0, damage);
    }

    /**
     * Fraction (0..1) of the damage removed by the target's Protection / Blast Protection.
     * Protection counts 1 per level and Blast Protection 2 per level, capped at 20 points.
     */
    private double protectionReductionOf(class_1309 target) {
        if (!(target instanceof class_1657)) {
            return 0.0;
        }

        if (readEnchants.getValue()) {
            try {
                var registry = mc.field_1687.method_30349().method_30530(class_7924.field_41265);
                var protection = registry.method_46747(class_1893.field_9111);
                var blastProtection = registry.method_46747(class_1893.field_9107);

                int points = 0;
                for (class_1304 slot : ARMOR_SLOTS) {
                    class_1799 stack = target.method_6118(slot);

                    if (stack.method_7960()) {
                        continue;
                    }

                    points += class_1890.method_8225(protection, stack);
                    points += 2 * class_1890.method_8225(blastProtection, stack);
                }

                return Math.min(20, points) / 25.0;
            } catch (RuntimeException ignored) {
                // Fall through to the assumed value.
            }
        }

        return Math.min(20, assumedProtection.getValue()) / 25.0;
    }

    /** Fraction of sample points on the target's hitbox that the explosion can reach. */
    private float exposure(class_243 source, class_1297 entity, class_243 entityPos) {
        class_238 box = entity.method_5829().method_997(entityPos.method_1020(positionOf(entity)));

        double stepX = 1.0 / ((box.field_1320 - box.field_1323) * 2.0 + 1.0);
        double stepY = 1.0 / ((box.field_1325 - box.field_1322) * 2.0 + 1.0);
        double stepZ = 1.0 / ((box.field_1324 - box.field_1321) * 2.0 + 1.0);

        if (stepX < 0.0 || stepY < 0.0 || stepZ < 0.0) {
            return 0.0f;
        }

        double offsetX = (1.0 - Math.floor(1.0 / stepX) * stepX) / 2.0;
        double offsetZ = (1.0 - Math.floor(1.0 / stepZ) * stepZ) / 2.0;

        int reached = 0;
        int total = 0;

        for (double x = 0.0; x <= 1.0; x += stepX) {
            for (double y = 0.0; y <= 1.0; y += stepY) {
                for (double z = 0.0; z <= 1.0; z += stepZ) {
                    class_243 point = new class_243(
                            class_3532.method_16436(x, box.field_1323, box.field_1320) + offsetX,
                            class_3532.method_16436(y, box.field_1322, box.field_1325),
                            class_3532.method_16436(z, box.field_1321, box.field_1324) + offsetZ
                    );

                    class_239 hit = mc.field_1687.method_17742(new class_3959(
                            point,
                            source,
                            class_3959.class_3960.field_17558,
                            class_3959.class_242.field_1348,
                            entity
                    ));

                    if (hit.method_17783() == class_239.class_240.field_1333) {
                        reached++;
                    }

                    total++;
                }
            }
        }

        return total == 0 ? 0.0f : (float) reached / total;
    }

    private static class_243 positionOf(class_1297 entity) {
        return new class_243(entity.method_23317(), entity.method_23318(), entity.method_23321());
    }

    // ---------------------------------------------------------------- inventory

    private int findHotbarSlot(class_1792 item) {
        for (int slot = 0; slot < 9; slot++) {
            if (mc.field_1724.method_31548().method_5438(slot).method_31574(item)) {
                return slot;
            }
        }

        return -1;
    }

    /**
     * Tops the hotbar up with crystals from the main inventory. Shift-click merges into the
     * existing hotbar stack instead of swapping stacks back and forth, and it only runs every
     * few ticks so it can't spam inventory packets.
     */
    private void restockCrystals() {
        if (tickCounter - lastRestockTick < RESTOCK_COOLDOWN_TICKS) {
            return;
        }

        var inventory = mc.field_1724.method_31548();
        int hotbarCrystals = 0;

        for (int slot = 0; slot < 9; slot++) {
            var stack = inventory.method_5438(slot);

            if (stack.method_31574(class_1802.field_8301)) {
                hotbarCrystals += stack.method_7947();
            }
        }

        if (hotbarCrystals > RESTOCK_THRESHOLD) {
            return;
        }

        for (int inventorySlot = 9; inventorySlot < 36; inventorySlot++) {
            if (!inventory.method_5438(inventorySlot).method_31574(class_1802.field_8301)) {
                continue;
            }

            mc.field_1761.method_2906(
                    mc.field_1724.field_7512.field_7763,
                    inventorySlot,
                    0,
                    class_1713.field_7794,
                    mc.field_1724
            );

            lastRestockTick = tickCounter;
            return;
        }
    }

    // ----------------------------------------------------------------- targeting

    private class_1309 findTarget() {
        double range = targetRange.getValue();

        var candidates = mc.field_1687.method_8390(
                class_1309.class,
                mc.field_1724.method_5829().method_1014(range),
                entity -> entity != mc.field_1724
                        && entity.method_5805()
                        && isValidTarget(entity)
                        && mc.field_1724.method_5858(entity) <= range * range
        );

        return candidates.stream().min((a, b) -> switch (targetMode.getValue()) {
            case NEAREST -> Double.compare(
                    mc.field_1724.method_5858(a),
                    mc.field_1724.method_5858(b));
            case LOWEST_HEALTH -> Double.compare(
                    a.method_6032() + a.method_6067(),
                    b.method_6032() + b.method_6067());
            case WEAKEST_ARMOR -> Double.compare(
                    a.method_45325(class_5134.field_23724),
                    b.method_45325(class_5134.field_23724));
        }).orElse(null);
    }

    private boolean isValidTarget(class_1309 entity) {
        if (entity instanceof class_1657 player) {
            return players.getValue() && !nomnom.friendManager().isFriend(player);
        }
        return mobs.getValue();
    }
}