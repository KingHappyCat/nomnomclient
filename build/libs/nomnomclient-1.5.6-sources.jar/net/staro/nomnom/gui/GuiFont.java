package net.staro.nomnom.gui;

import net.minecraft.class_11719;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;

/**
 * The client's custom font, used by the ClickGUI and the HUD (Huninn, see {@code assets/nomnom/font/huninn.json}).
 *
 * <p>Minecraft picks a font per piece of text through its style, so text drawn with this font is
 * just text whose style names it. Characters the font doesn't have fall back to the vanilla
 * font (the font definition ends with a reference to it).
 */
public final class GuiFont {
    public static final class_2960 ID = class_2960.method_60655("nomnom", "huninn");

    private static final class_2583 STYLE = class_2583.field_24360.method_27704(new class_11719.class_11721(ID));

    private GuiFont() {
    }

    /** {@code value} as text in the custom font, or in the normal font if {@code custom} is false. */
    public static class_2561 of(String value, boolean custom) {
        class_2561 text = class_2561.method_43470(value);
        return custom ? text.method_27661().method_10862(STYLE) : text;
    }
}