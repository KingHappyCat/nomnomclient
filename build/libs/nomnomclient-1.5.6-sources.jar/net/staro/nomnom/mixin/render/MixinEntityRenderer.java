package net.staro.nomnom.mixin.render;

import net.minecraft.class_10017;
import net.minecraft.class_1297;
import net.minecraft.class_897;
import net.staro.nomnom.module.modules.Nametags;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_897.class)
public class MixinEntityRenderer {
    // The vanilla nametag is drawn from state.displayName, which is filled in at the end of the
    // base updateRenderState (player and living renderers call it through super). Clearing it
    // there removes the vanilla tag for every entity type.
    @Inject(
            method = "updateRenderState(Lnet/minecraft/entity/Entity;Lnet/minecraft/client/render/entity/state/EntityRenderState;F)V",
            at = @At("RETURN")
    )
    private void hideVanillaNametag(class_1297 entity, class_10017 state, float tickProgress, CallbackInfo ci) {
        Nametags nametags = Nametags.INSTANCE;
        if (nametags != null && nametags.hidesVanillaTag(entity)) {
            state.field_53337 = null;
        }
    }
}