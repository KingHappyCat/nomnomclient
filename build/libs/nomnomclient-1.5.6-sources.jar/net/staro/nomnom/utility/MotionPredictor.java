package net.staro.nomnom.utility;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;

/**
 * Where an entity will be a few ticks from now.
 *
 * <p>Other players' real velocity isn't known on the client, so it is measured from how far
 * they moved between ticks and smoothed. The predicted path then runs through the world
 * collision, so someone running at a wall is predicted to stop at it instead of inside it, and
 * someone in the air keeps falling. Client tick thread only.
 */
public class MotionPredictor {
    private static final double SMOOTHING = 0.6;
    private static final double MAX_STEP = 3.0;
    private static final long FORGET_TICKS = 100;

    private final class_310 mc;
    private final Map<Integer, class_243> lastPosition = new HashMap<>();
    private final Map<Integer, class_243> velocity = new HashMap<>();
    private final Map<Integer, Long> lastTick = new HashMap<>();

    public MotionPredictor(class_310 mc) {
        this.mc = mc;
    }

    public void reset() {
        lastPosition.clear();
        velocity.clear();
        lastTick.clear();
    }

    /** Measures the entity's movement. Call once per tick for every entity you predict. */
    public void observe(long tick, class_1297 entity) {
        int id = entity.method_5628();
        Long previousTick = lastTick.get(id);

        if (previousTick != null && previousTick == tick) {
            return;
        }

        class_243 position = CrystalDamage.positionOf(entity);
        class_243 previous = lastPosition.get(id);

        class_243 measured = class_243.field_1353;
        if (previous != null && previousTick != null && tick - previousTick <= 3) {
            long elapsed = tick - previousTick;
            class_243 step = position.method_1020(previous).method_1021(1.0 / elapsed);

            // A teleport is not movement.
            if (step.method_1033() <= MAX_STEP) {
                measured = step;
            }
        }

        class_243 old = velocity.getOrDefault(id, class_243.field_1353);
        velocity.put(id, old.method_1021(1.0 - SMOOTHING).method_1019(measured.method_1021(SMOOTHING)));
        lastPosition.put(id, position);
        lastTick.put(id, tick);

        if (lastTick.size() > 64) {
            lastTick.values().removeIf(seen -> tick - seen > FORGET_TICKS);
            lastPosition.keySet().retainAll(lastTick.keySet());
            velocity.keySet().retainAll(lastTick.keySet());
        }
    }

    /**
     * Position of {@code entity} in {@code ticks} ticks. {@code exact} uses the entity's own
     * velocity (accurate for the local player) instead of the measured one.
     */
    public class_243 predict(class_1297 entity, int ticks, boolean exact) {
        class_243 position = CrystalDamage.positionOf(entity);

        if (ticks <= 0) {
            return position;
        }

        class_243 v = exact ? entity.method_18798() : velocity.getOrDefault(entity.method_5628(), class_243.field_1353);
        boolean grounded = entity.method_24828();

        double vx = v.field_1352;
        double vy = grounded ? Math.min(0.0, v.field_1351) : v.field_1351;
        double vz = v.field_1350;

        class_238 box = entity.method_5829();

        for (int i = 0; i < ticks; i++) {
            double dx = vx;
            double dy = vy;
            double dz = vz;

            if (dx != 0.0 && !free(entity, box.method_989(dx, 0.0, 0.0))) {
                dx = 0.0;
                vx = 0.0;
            }
            box = box.method_989(dx, 0.0, 0.0);

            if (dy != 0.0 && !free(entity, box.method_989(0.0, dy, 0.0))) {
                dy = 0.0;
                vy = 0.0;
            }
            box = box.method_989(0.0, dy, 0.0);

            if (dz != 0.0 && !free(entity, box.method_989(0.0, 0.0, dz))) {
                dz = 0.0;
                vz = 0.0;
            }
            box = box.method_989(0.0, 0.0, dz);

            position = position.method_1031(dx, dy, dz);

            // Gravity and drag, unless something solid is right underneath.
            boolean supported = !free(entity, box.method_989(0.0, -0.05, 0.0));
            vy = supported && vy <= 0.0 ? 0.0 : (vy - 0.08) * 0.98;
        }

        return position;
    }

    private boolean free(class_1297 entity, class_238 box) {
        return mc.field_1687.method_8587(entity, box);
    }
}