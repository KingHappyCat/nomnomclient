package net.staro.nomnom.module.modules;

import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2846;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.api.Setting;
import net.staro.nomnom.api.event.listener.Listener;
import net.staro.nomnom.events.tick.TickEvent;
import net.staro.nomnom.module.Category;
import net.staro.nomnom.module.NomnomModule;
import net.staro.nomnom.utility.BlockPlacer;

import java.util.LinkedHashSet;
import java.util.Set;

/**
 * Mines a block out of an enemy's surround so a crystal can reach their feet.
 *
 * <p>While the target stands in a closed ring of blocks, crystals can only hurt them through
 * the gaps above. This picks the side block that breaks fastest, and whose floor can still hold
 * a crystal, and mines it with packets: it tells the server we started digging, counts up the
 * same break progress the game would, and sends the finish packet the moment it is enough. The
 * block is gone one round trip later and AutoCrystal places on the freed spot by itself, so keep
 * AutoCrystal on.
 *
 * <p>The best pickaxe in the hotbar is used without the client ever switching to it: the server
 * is told to hold it only for the finish packet. Both packets are preceded by a silent rotation
 * to the block, because anticheats check that you are looking at what you mine.
 *
 * <p>LEGIT finishes at full progress, exactly like the normal client. FAST finishes at the point
 * where the server still accepts the block as mined (it allows a little early), which is about
 * a quarter quicker, but a server with a stricter check will refuse it and the mining restarts.
 */
@SuppressWarnings("unused")
public class SurroundBreak extends NomnomModule {
    public enum Mode {LEGIT, FAST}

    private static final class_2350[] SIDES = {
            class_2350.field_11043, class_2350.field_11034, class_2350.field_11035, class_2350.field_11039
    };
    // Server break check: delta * ticks must reach 0.7. Our own count is one tick behind it, and
    // the extra margin covers one tick of timing jitter between our two packets.
    private static final double FAST_PROGRESS = 0.75;
    private static final double LEGIT_PROGRESS = 1.0;
    private static final int COOLDOWN_TICKS = 4;

    private final Setting<Mode> mode = enumSetting("Mode", Mode.LEGIT);
    private final Setting<Double> range = precise("Range", 4.5, 2.0, 6.0);
    private final Setting<Integer> targetRange = integer("TargetRange", 8, 2, 12);
    // Use the best pickaxe in the hotbar (silently).
    private final Setting<Boolean> pickaxe = bool("Pickaxe", true);
    private final Setting<Boolean> rotate = bool("Rotate", true);
    // Mine blocks you can't see (through walls). The server only checks reach, but anticheats
    // like Grim check that you are looking at the block. Off = only blocks with a visible face.
    private final Setting<Boolean> walls = bool("Walls", true);
    // Only mine when the target is fully walled in. With an open side AutoCrystal can already
    // place there.
    private final Setting<Boolean> onlyEnclosed = bool("OnlyEnclosed", true);
    // Only mine blocks that have obsidian or bedrock under them, so a crystal can go there.
    private final Setting<Boolean> requireBase = bool("RequireBase", true);
    // Don't open spots closer than this to you (the crystal would hurt you too).
    private final Setting<Double> minDistance = precise("MinDistance", 2.5, 1.0, 6.0);
    private final Setting<Boolean> debug = bool("Debug", false);

    private final BlockPlacer placer;

    private class_2338 miningPos;
    private class_2350 miningFace;
    private int pickSlot;
    private double progress;
    private boolean finishSent;
    private long finishTick;
    private long tickCounter;
    private long cooldownUntil;

    public SurroundBreak(Nomnom nomnom) {
        super(nomnom, "SurroundBreak", Category.COMBAT, "Mines a block out of the target's surround");
        this.placer = new BlockPlacer(mc);
    }

    @Override
    public void onDisable() {
        abort();
    }

    @Listener
    public void onTick(TickEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.method_1562() == null) {
            return;
        }

        tickCounter++;

        try {
            run();
        } finally {
            placer.finish();
        }
    }

    private void run() {
        class_1657 target = findTarget();

        if (miningPos != null) {
            continueMining(target);
            return;
        }

        if (target == null || tickCounter < cooldownUntil) {
            return;
        }

        startMining(target);
    }

    // ------------------------------------------------------------------ mining

    private void startMining(class_1657 target) {
        Plan plan = plan(target);

        if (plan == null) {
            return;
        }

        miningPos = plan.pos();
        miningFace = plan.face();
        pickSlot = plan.slot();
        progress = 0.0;
        finishSent = false;

        if (rotate.getValue()) {
            placer.faceSilently(faceCentre(miningPos, miningFace));
        }

        send(class_2846.class_2847.field_12968, miningPos, miningFace);
        mc.field_1724.method_6104(class_1268.field_5808);

        debugMessage(String.format("Mining %s, about %d ticks", miningPos.method_23854(), plan.ticks()));
    }

    private void continueMining(class_1657 target) {
        var state = mc.field_1687.method_8320(miningPos);

        // The block is gone: done. AutoCrystal takes it from here.
        if (state.method_26215() || state.method_45474()) {
            debugMessage("Block " + miningPos.method_23854() + " is open");
            miningPos = null;
            cooldownUntil = tickCounter + COOLDOWN_TICKS;
            return;
        }

        boolean stillWanted = target != null
                && isSideOf(target, miningPos)
                && eyeDistance(faceCentre(miningPos, miningFace)) <= range.getValue() + 0.5;

        if (!stillWanted) {
            abort();
            return;
        }

        if (finishSent) {
            // The server should have broken it by now. If it didn't, start over.
            if (tickCounter - finishTick > pingTicks() + 8) {
                debugMessage("Server refused " + miningPos.method_23854() + ", restarting");
                miningPos = null;
                cooldownUntil = tickCounter + COOLDOWN_TICKS;
            }
            return;
        }

        progress += delta(miningPos, pickSlot);

        double needed = mode.getValue() == Mode.FAST ? FAST_PROGRESS : LEGIT_PROGRESS;
        if (progress < needed) {
            return;
        }

        class_2338 pos = miningPos;
        class_2350 face = miningFace;

        placer.withSilentSlot(pickSlot, () -> {
            if (rotate.getValue()) {
                placer.faceSilently(faceCentre(pos, face));
            }

            send(class_2846.class_2847.field_12973, pos, face);
            mc.field_1724.method_6104(class_1268.field_5808);
        });

        finishSent = true;
        finishTick = tickCounter;
    }

    /** Stops mining and tells the server, if a block was being dug. */
    private void abort() {
        if (miningPos != null && !finishSent && mc.method_1562() != null) {
            send(class_2846.class_2847.field_12971, miningPos, miningFace);
        }

        miningPos = null;
        finishSent = false;
    }

    private void send(class_2846.class_2847 action, class_2338 pos, class_2350 face) {
        mc.method_1562().method_52787(new class_2846(action, pos, face));
    }

    // ---------------------------------------------------------------- planning

    private record Plan(class_2338 pos, class_2350 face, int slot, int ticks) {
    }

    /** The side block of {@code target}'s surround that opens fastest, or null. */
    private Plan plan(class_1657 target) {
        Set<class_2338> occupied = occupiedColumns(target);

        if (onlyEnclosed.getValue() && !enclosed(occupied)) {
            return null;
        }

        double needed = mode.getValue() == Mode.FAST ? FAST_PROGRESS : LEGIT_PROGRESS;
        Plan best = null;

        for (class_2338 column : occupied) {
            for (class_2350 side : SIDES) {
                class_2338 pos = column.method_10093(side);

                if (occupied.contains(pos)) {
                    continue;
                }

                var state = mc.field_1687.method_8320(pos);

                // Nothing to mine, or it can't be mined (bedrock).
                if (state.method_26215() || state.method_45474() || state.method_26214(mc.field_1687, pos) < 0.0f) {
                    continue;
                }

                if (requireBase.getValue()) {
                    var floor = mc.field_1687.method_8320(pos.method_10074());

                    if (!floor.method_27852(class_2246.field_10540) && !floor.method_27852(class_2246.field_9987)) {
                        continue;
                    }
                }

                if (mc.field_1724.method_73189().method_1022(class_243.method_24953(pos)) < minDistance.getValue()) {
                    continue;
                }

                class_2350 face = visibleFace(pos);
                if (face == null) {
                    continue;
                }

                int slot = bestSlot(pos);
                double delta = delta(pos, slot);

                if (delta <= 0.0) {
                    continue;
                }

                int ticks = (int) Math.ceil(needed / delta);

                if (best == null || ticks < best.ticks()) {
                    best = new Plan(pos.method_10062(), face, slot, ticks);
                }
            }
        }

        return best;
    }

    /** Every block column the target's hitbox touches, at feet height. */
    private Set<class_2338> occupiedColumns(class_1657 target) {
        class_238 box = target.method_5829();
        int y = class_3532.method_15357(box.field_1322 + 1.0E-3);
        Set<class_2338> occupied = new LinkedHashSet<>();

        for (int x = class_3532.method_15357(box.field_1323 + 1.0E-3); x <= class_3532.method_15357(box.field_1320 - 1.0E-3); x++) {
            for (int z = class_3532.method_15357(box.field_1321 + 1.0E-3); z <= class_3532.method_15357(box.field_1324 - 1.0E-3); z++) {
                occupied.add(new class_2338(x, y, z));
            }
        }

        return occupied;
    }

    /** True if every block next to the target at feet height is solid. */
    private boolean enclosed(Set<class_2338> occupied) {
        for (class_2338 column : occupied) {
            for (class_2350 side : SIDES) {
                class_2338 pos = column.method_10093(side);

                if (!occupied.contains(pos) && mc.field_1687.method_8320(pos).method_45474()) {
                    return false;
                }
            }
        }

        return true;
    }

    private boolean isSideOf(class_1657 target, class_2338 pos) {
        for (class_2338 column : occupiedColumns(target)) {
            for (class_2350 side : SIDES) {
                if (column.method_10093(side).equals(pos)) {
                    return true;
                }
            }
        }

        return false;
    }

    // ---------------------------------------------------------------- the block

    /**
     * The nearest face of {@code pos} in reach that we can see from here (any face in reach
     * with Walls on), or null.
     */
    private class_2350 visibleFace(class_2338 pos) {
        class_243 eye = mc.field_1724.method_33571();
        class_2350 best = null;
        double bestDistance = range.getValue() * range.getValue();

        for (class_2350 direction : class_2350.values()) {
            class_243 point = faceCentre(pos, direction);
            double distance = eye.method_1025(point);

            if (distance > bestDistance) {
                continue;
            }

            // Through walls the nearest face in reach will do.
            if (walls.getValue()) {
                bestDistance = distance;
                best = direction;
                continue;
            }

            // A ray that ends just inside the face must hit this block and nothing before it.
            class_243 inside = class_243.method_24953(pos).method_1031(
                    direction.method_10148() * 0.49,
                    direction.method_10164() * 0.49,
                    direction.method_10165() * 0.49);

            var hit = mc.field_1687.method_17742(new class_3959(
                    eye, inside,
                    class_3959.class_3960.field_17558,
                    class_3959.class_242.field_1348,
                    mc.field_1724));

            if (hit.method_17783() == class_239.class_240.field_1332 && hit.method_17777().equals(pos)) {
                bestDistance = distance;
                best = direction;
            }
        }

        return best;
    }

    private static class_243 faceCentre(class_2338 pos, class_2350 face) {
        return class_243.method_24953(pos).method_1031(face.method_10148() * 0.5, face.method_10164() * 0.5, face.method_10165() * 0.5);
    }

    private double eyeDistance(class_243 point) {
        return mc.field_1724.method_33571().method_1022(point);
    }

    /** Hotbar slot with the fastest tool for {@code pos}, or the held slot. */
    private int bestSlot(class_2338 pos) {
        int held = mc.field_1724.method_31548().method_67532();

        if (!pickaxe.getValue()) {
            return held;
        }

        int best = held;
        float bestDelta = delta(pos, held);

        for (int slot = 0; slot < 9; slot++) {
            float delta = delta(pos, slot);

            // Only switch for a clear gain, otherwise there is no point in sending packets.
            if (delta > bestDelta * 1.05f) {
                bestDelta = delta;
                best = slot;
            }
        }

        return best;
    }

    /**
     * Break progress per tick for {@code pos} with the item in {@code slot}. The game works it
     * out from the selected slot, so it is selected for the calculation and put straight back.
     */
    private float delta(class_2338 pos, int slot) {
        var inventory = mc.field_1724.method_31548();
        int held = inventory.method_67532();

        try {
            inventory.method_61496(slot);
            return mc.field_1687.method_8320(pos).method_26165(mc.field_1724, mc.field_1687, pos);
        } finally {
            inventory.method_61496(held);
        }
    }

    // ---------------------------------------------------------------- targeting

    private class_1657 findTarget() {
        class_1657 best = null;
        double bestDistance = targetRange.getValue() * (double) targetRange.getValue();

        for (class_1657 player : mc.field_1687.method_18456()) {
            if (player == mc.field_1724 || !player.method_5805() || nomnom.friendManager().isFriend(player)) {
                continue;
            }

            double distance = mc.field_1724.method_5858(player);

            if (distance < bestDistance) {
                bestDistance = distance;
                best = player;
            }
        }

        return best;
    }

    /** Round trip time in ticks, rounded down. 0 in singleplayer. */
    private int pingTicks() {
        var entry = mc.method_1562().method_2871(mc.field_1724.method_5667());
        return entry == null ? 0 : entry.method_2959() / 50;
    }

    private void debugMessage(String message) {
        if (debug.getValue() && mc.field_1724 != null) {
            mc.field_1724.method_7353(net.minecraft.class_2561.method_43470("[SurroundBreak] " + message), false);
        }
    }
}