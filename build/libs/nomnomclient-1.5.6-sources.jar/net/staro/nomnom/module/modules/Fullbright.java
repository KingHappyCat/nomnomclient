package net.staro.nomnom.module.modules;

import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_746;
import net.staro.nomnom.Nomnom;
import net.staro.nomnom.api.event.listener.Listener;
import net.staro.nomnom.events.tick.UpdateEvent;
import net.staro.nomnom.module.Category;
import net.staro.nomnom.module.NomnomModule;

/**
 * Keeps an infinite, hidden Night Vision effect on the player. It is re-applied every tick, so
 * it survives relogging, dying, changing dimension and servers that clear your effects.
 */
public class Fullbright extends NomnomModule {
    public Fullbright(Nomnom nomnom) {
        super(nomnom, "Fullbright", Category.RENDER, "Makes the world bright.");
    }

    @Listener
    public void onUpdate(UpdateEvent event) {
        class_746 player = event.getPlayer();
        class_1293 current = player.method_6112(class_1294.field_5925);

        if (current == null || !current.method_48559()) {
            player.method_6092(new class_1293(
                    class_1294.field_5925, class_1293.field_42106, 0, false, false, false));
        }
    }

    @Override
    public void onEnable() {
        // Applied on the next tick by onUpdate; nothing to do here (the player may not exist yet).
    }

    @Override
    public void onDisable() {
        var player = mc.field_1724;
        if (player == null) {
            return;
        }

        // Only remove our own effect, not a real Night Vision from a potion or beacon.
        class_1293 current = player.method_6112(class_1294.field_5925);
        if (current != null && current.method_48559()) {
            player.method_6016(class_1294.field_5925);
        }
    }
}